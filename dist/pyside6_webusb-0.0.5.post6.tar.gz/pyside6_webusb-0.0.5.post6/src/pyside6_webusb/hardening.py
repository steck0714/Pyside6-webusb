# -*- coding: utf-8 -*-
"""
hardening.py
============
WebUSBBridge (bridge.py) / WEBUSB_POLYFILL_JS (polyfill.py) をWebUSB仕様(WICG Draft)に
より近づけ、かつセキュリティキー等の「保護対象インターフェースクラス」への
到達を構造的に遮断するための追加コンポーネント群。

このファイル単体では何も起動しない。bridge.py 側から import して、
WebUSBBridge の各 @Slot メソッド内から判定関数・記述子ビルダーを呼び出し、
UsbHotplugWatcher をアプリ起動時に起動する、という使い方を想定する
(pyside6-webusbパッケージの内部モジュール。単体でのimportも可能)。

--------------------------------------------------------------------------
なぜこれが必要か(2026年7月時点で確認した一次情報の要約)
--------------------------------------------------------------------------
* WebUSBはWICG(W3C Web Incubator Community Group)のDraftであり、正式なW3C
  勧告ではない。実装しているのはChromium系ブラウザ(Chrome/Edge/Opera/Samsung
  Internet等)のみ。
* Firefoxは公式スタンダードポジションでWebUSBを「harmful」(fingerprinting・
  セキュリティ上のリスクが大きい)と明記しており、実装する予定がない。
  Safari/WebKitも同様に反対の立場を表明しており、iOS/iPadOS/macOS Safariの
  いずれにも実装されていない。
  → WebUSBはWeb系APIの中でも最も慎重な扱いが必要なものの一つ、というのが
    ブラウザベンダー間でのおおむね共通した認識である。
* Chromium自身は上記のリスクを軽減するため、単なる「サイトへの許可」以外に
  少なくとも次の多層防御を実装している:
    (1) 「保護対象インターフェースクラス」: Audio / HID / Mass Storage / Hub /
        Smart Card / Video / Audio-Video / Wireless Controller の8クラスは
        claimInterface自体をブラウザ側で拒否する(これらは別の専用API
        [WebHID・WebMIDI等]や高レベルOS機能が既にあり、WebUSBで生アクセス
        させる必要が無いため)。
    (2) 既知の脆弱/セキュリティ上重要なデバイスを列挙した明示的な
        ブロックリスト(vendor_id, product_id単位)。主にFIDO/U2Fの
        セキュリティキー各種。
    (3) セキュアコンテキスト(https/localhostのみ)。
    (4) requestDevice()はユーザー操作(トラステッドイベント)からのみ呼び出し可能。
  本モジュールはこの(1)(2)をpyusb経由で再現し、(3)(4)はJS側
  (WEBUSB_POLYFILL_JS)側での追加チェックと合わせて実現する。

出典:
  - WebUSB仕様: https://wicg.github.io/webusb/
  - 保護対象インターフェースクラス8種の一覧: WebUSB仕様本文
    (index.bs の「Protected interface classes」表, #protected-interface-classes)
    を2026年7月に一次ソース(github.com/WICG/webusb)から直接取得して突き合わせ、
    Hub(0x09)が本実装から漏れていたことを確認・追加した。
  - デバイスブロックリスト: chrome/browser/usb/usb_blocklist.cc
    (https://github.com/chromium/chromium/blob/main/chrome/browser/usb/usb_blocklist.cc
     2026年7月時点のmainブランチより、vendor_id/product_idの組のみを移植。
     ★ 本家は随時更新されるため、定期的に上記URLを確認して追従すること。
     本モジュールの一覧はあくまで多層防御の一枚であり、下のHID等の
     インターフェースクラス丸ごと遮断の方が防御としては本質的に重要)
  - 参考実装 thegecko/webusb (Node.js): 2024年に非推奨化され、後継は
    npm "usb" パッケージ内蔵のWebUSB実装 (node-usb)。API形状
    (configurations/selectAlternateInterface/clearHalt/reset/serialNumber等)
    の突き合わせに使用した。この参照比較を行った時点ではisochronousTransferは
    node-usb側でも「現状未対応」だったため、当初は本実装でも同様に非対応として
    明示していた(中途半端な実装で「動いているように見えて実は壊れている」
    状態を避けるため)。
    🆕 v0.0.4a0でisochronousTransferIn/Out自体は実装済み(bridge.py参照、
    libusb1のiso転送APIをベストエフォートで利用)。ただし個々のパケット単位の
    正確性(actual per-packet fidelity)には既知の制約が残っており、詳細は
    CHANGELOG.mdの`0.0.5.post3`「Investigated, not changed」を参照。
"""

import time
import threading


# ============================================================
# 1) 保護対象インターフェースクラス
# ============================================================
# WebUSB仕様上、これらのクラスは claimInterface() 自体が拒否されるべきもの。
# 旧実装(監査時点)はHIDを含め一切のクラスチェックをしておらず、
# 許可さえ得ていれば(=ユーザーがチューザーダイアログで一度でも選んでしまえば)
# セキュリティキーやキーボード等のHIDインターフェースにも生アクセスできて
# しまっていた。ここで構造的に閉じる。
PROTECTED_INTERFACE_CLASSES = {
    0x01: "Audio",
    0x03: "HID (Human Interface Device: セキュリティキー/キーボード/マウス等の大半)",
    0x08: "Mass Storage",
    0x09: "Hub",
    0x0B: "Smart Card (CCID)",
    0x0E: "Video",
    0x10: "Audio/Video",
    0xE0: "Wireless Controller (Bluetooth/Wireless USBアダプタ等)",
}


def is_protected_interface_class(b_interface_class) -> bool:
    """このインターフェースクラスは claimInterface を拒否すべきか"""
    try:
        return int(b_interface_class) in PROTECTED_INTERFACE_CLASSES
    except (TypeError, ValueError):
        return True  # 判定できない場合は安全側(拒否)に倒す


def protected_class_name(b_interface_class) -> str:
    try:
        return PROTECTED_INTERFACE_CLASSES.get(int(b_interface_class), "Unknown")
    except (TypeError, ValueError):
        return "Unknown"


# ============================================================
# 2) 既知セキュリティキー/認証デバイスのブロックリスト(多層防御の2枚目)
# ============================================================
# Chromiumの usb_blocklist.cc (2026-07時点のmain) から vendor_id/product_id の
# 組のみを移植したもの。実際の脅威はほぼ全てHIDインターフェースとして
# 提示されるため上のPROTECTED_INTERFACE_CLASSESで既にブロックされるはずだが、
# 「非HIDインターフェースでCTAP相当を喋る」将来の変則的デバイスに備えて
# デバイス単位でも明示的に遮断する。
KNOWN_SECURITY_KEY_BLOCKLIST = frozenset([
    (0x096e, 0x0850), (0x096e, 0x0852), (0x096e, 0x0853), (0x096e, 0x0854),
    (0x096e, 0x0856), (0x096e, 0x0858), (0x096e, 0x085a), (0x096e, 0x085b),
    (0x096e, 0x0880),
    (0x09c3, 0x0023),
    (0x1050, 0x0010), (0x1050, 0x0018), (0x1050, 0x0030),
    (0x1050, 0x0110), (0x1050, 0x0111), (0x1050, 0x0112), (0x1050, 0x0113),
    (0x1050, 0x0114), (0x1050, 0x0115), (0x1050, 0x0116), (0x1050, 0x0120),
    (0x1050, 0x0200), (0x1050, 0x0211),
    (0x1050, 0x0401), (0x1050, 0x0402), (0x1050, 0x0403), (0x1050, 0x0404),
    (0x1050, 0x0405), (0x1050, 0x0406), (0x1050, 0x0407), (0x1050, 0x0410),
    (0x10c4, 0x8acf),
    (0x18d1, 0x5026),
    (0x1a44, 0x00bb),
    (0x1d50, 0x60fc),
    (0x1e0d, 0xf1ae), (0x1e0d, 0xf1d0),
    (0x1ea8, 0xf025),
    (0x20a0, 0x4287),
    (0x24dc, 0x0101),
    (0x2581, 0xf1d0),
    (0x2abe, 0x1002),
    (0x2ccf, 0x0880),
])


def is_blocklisted_device(vendor_id, product_id) -> bool:
    try:
        return (int(vendor_id), int(product_id)) in KNOWN_SECURITY_KEY_BLOCKLIST
    except (TypeError, ValueError):
        return True


def device_is_fully_blocked(dev) -> bool:
    """デバイス単位でブロックリストに一致するか(こちらはgetDevices/openDeviceの
    時点、つまりインターフェースをまだ見ていない段階での粗いチェック)。
    個々のインターフェースクラスのチェックは claimInterface 側で別途行う。"""
    try:
        return is_blocklisted_device(dev.idVendor, dev.idProduct)
    except Exception:
        return True


# ============================================================
# 3) BCDバージョン変換 (bcdUSB / bcdDevice -> major.minor.subminor)
# ============================================================
def bcd_to_version(bcd_value) -> tuple:
    """USB記述子のBCD値(例:0x0210)を(major, minor, subminor)=(2,1,0)に変換する。
    WebUSB仕様のUSBDevice.usbVersionMajor等はこの分解方式を使う。"""
    try:
        v = int(bcd_value)
    except (TypeError, ValueError):
        return (0, 0, 0)
    major = (v >> 8) & 0xFF
    minor = (v >> 4) & 0x0F
    subminor = v & 0x0F
    return (major, minor, subminor)


# ============================================================
# 4) リッチなデバイス記述子ビルダー
# ============================================================
# 旧実装はvendorId/productId/manufacturerName/productName/deviceClassのみを
# JSへ返しており、実際のWebUSB仕様が持つ configurations (interfaces/alternates/
# endpointsのツリー)や serialNumber, usbVersion*, deviceVersion* 等を
# 一切返していなかった。これでは「エンドポイント番号やインターフェース番号を
# 呼び出し元サイトが事前に知っている」ことが前提になってしまい、汎用の
# WebUSB対応ハードウェアSDK(例: thegecko/webusb同梱のデモや、市販USB機器の
# 公式Web SDK)がそのままでは動かない。ここで実機の記述子を可能な限り
# 汎用ブラウザ相当の形へ組み立てる。
def build_device_descriptor(dev, usb_util, include_configurations=True) -> dict:
    manufacturer = product = serial = None
    try:
        if getattr(dev, "iManufacturer", 0):
            manufacturer = sanitize_device_string(usb_util.get_string(dev, dev.iManufacturer))
    except Exception:
        pass
    try:
        if getattr(dev, "iProduct", 0):
            product = sanitize_device_string(usb_util.get_string(dev, dev.iProduct))
    except Exception:
        pass
    try:
        if getattr(dev, "iSerialNumber", 0):
            serial = sanitize_device_string(usb_util.get_string(dev, dev.iSerialNumber))
    except Exception:
        pass

    usb_major, usb_minor, usb_sub = bcd_to_version(getattr(dev, "bcdUSB", 0))
    dev_major, dev_minor, dev_sub = bcd_to_version(getattr(dev, "bcdDevice", 0))

    # 🛡️ 実機が「今実際にどのコンフィグレーションで動作しているか」(GET_CONFIGURATION相当)。
    #    旧実装はこれを一切取得しておらず、JS側は複数コンフィグレーションを持つ機器で
    #    常に配列の先頭を暫定activeとして扱っていた(pyusbのDevice.get_active_configuration()
    #    はGET_CONFIGURATIONに相当する情報を返すことをpyusb公式ドキュメント/ソースで確認済み)。
    #    取得できない場合はNoneのままにし、JS側で従来どおり先頭要素へ安全側フォールバックする。
    active_cfg_value = None
    try:
        active_cfg_value = dev.get_active_configuration().bConfigurationValue
    except Exception:
        active_cfg_value = None

    info = {
        "vendorId": dev.idVendor,
        "productId": dev.idProduct,
        "manufacturerName": manufacturer,
        "productName": product,
        "serialNumber": serial,
        "deviceClass": getattr(dev, "bDeviceClass", 0),
        "deviceSubclass": getattr(dev, "bDeviceSubClass", 0),
        "deviceProtocol": getattr(dev, "bDeviceProtocol", 0),
        "usbVersionMajor": usb_major, "usbVersionMinor": usb_minor, "usbVersionSubminor": usb_sub,
        "deviceVersionMajor": dev_major, "deviceVersionMinor": dev_minor, "deviceVersionSubminor": dev_sub,
        "configurations": [],
        "activeConfigurationValue": active_cfg_value,
    }

    if include_configurations:
        info["configurations"] = build_configurations_tree(dev, usb_util)
    return info


def build_configurations_tree(dev, usb_util) -> list:
    """dev配下の全Configuration/Interface(=各AlternateSetting)/Endpointを
    WebUSB仕様相当のツリー構造に変換する。1個の記述子取得に失敗しても
    全体を巻き込んで失敗させない(壊れた/変則的な記述子を持つ安物USB機器が
    実世界には少なくないため)。"""
    configurations = []
    try:
        cfg_iter = list(dev)
    except Exception:
        return configurations

    for cfg in cfg_iter:
        try:
            interfaces_by_number = {}
            for intf in cfg:
                try:
                    inum = intf.bInterfaceNumber
                    # 🛡️ spec: USBAlternateInterface.interfaceName は
                    #    「interface descriptorのiInterfaceが指すstring descriptorの値」
                    #    (pyusbのInterfaceオブジェクトはiInterface属性を公開していることを
                    #    ソース確認済み)。取得できない/未定義な機器も多いため、他の文字列
                    #    記述子(manufacturer/product/serial)と同じくベストエフォートで
                    #    Noneにフォールバックする。
                    interface_name = None
                    try:
                        if getattr(intf, "iInterface", 0):
                            interface_name = sanitize_device_string(usb_util.get_string(dev, intf.iInterface))
                    except Exception:
                        pass
                    alt = {
                        "alternateSetting": intf.bAlternateSetting,
                        "interfaceClass": intf.bInterfaceClass,
                        "interfaceSubclass": intf.bInterfaceSubClass,
                        "interfaceProtocol": intf.bInterfaceProtocol,
                        "interfaceProtected": is_protected_interface_class(intf.bInterfaceClass),
                        "interfaceName": interface_name,
                        "endpoints": [],
                    }
                    for ep in intf:
                        try:
                            ep_type = usb_util.endpoint_type(ep.bmAttributes)
                            # 🛡️ spec(USBAlternateInterface constructor): bmAttributesが
                            #    Control Transfer Type(下位2bitが00)を示す記述子は
                            #    endpoints一覧から除外する("There shouldn't be any endpoint
                            #    object belongs to Control Transfer Type" との注記どおり)。
                            if ep_type == usb_util.ENDPOINT_TYPE_CTRL:
                                continue
                            direction = usb_util.endpoint_direction(ep.bEndpointAddress)
                            alt["endpoints"].append({
                                "endpointNumber": ep.bEndpointAddress & 0x0F,
                                "direction": "in" if direction == usb_util.ENDPOINT_IN else "out",
                                "type": {
                                    usb_util.ENDPOINT_TYPE_BULK: "bulk",
                                    usb_util.ENDPOINT_TYPE_INTR: "interrupt",
                                    usb_util.ENDPOINT_TYPE_ISO: "isochronous",
                                }.get(ep_type, "unknown"),
                                "packetSize": getattr(ep, "wMaxPacketSize", 0),
                            })
                        except Exception as e:
                            # 🔍 品質改善(v0.0.4b1): 旧実装はここを完全に無言でcontinueして
                            #    いた。記述子が多少崩れたデバイスでendpointが1つ2つ丸ごと
                            #    消える場合、原因が一切追えなかった(=「デバイスが繋がって
                            #    いるのに一部のendpointが見えない」という調査困難な状況の
                            #    温床)。他の箇所(bridge.py)と同じ"例外を無視"表記に揃え、
                            #    制御フロー(continueして列挙を続ける)自体は変更しない。
                            print(f"[pyside6-webusb] build_configurations_tree(endpoint): 例外を無視: {e}")
                            continue
                    interfaces_by_number.setdefault(inum, []).append(alt)
                except Exception as e:
                    print(f"[pyside6-webusb] build_configurations_tree(alternate): 例外を無視: {e}")
                    continue

            interfaces_list = [
                {"interfaceNumber": inum, "alternates": alts}
                for inum, alts in sorted(interfaces_by_number.items())
            ]
            # 🛡️ spec: USBConfiguration.configurationName は
            #    「configuration descriptorのiConfigurationが指すstring descriptorの値」
            #    (pyusbのConfigurationオブジェクトはiConfiguration属性を公開していることを
            #    ソース確認済み)。
            configuration_name = None
            try:
                if getattr(cfg, "iConfiguration", 0):
                    configuration_name = sanitize_device_string(usb_util.get_string(dev, cfg.iConfiguration))
            except Exception:
                pass
            configurations.append({
                "configurationValue": getattr(cfg, "bConfigurationValue", 0),
                "configurationName": configuration_name,
                "interfaces": interfaces_list,
            })
        except Exception as e:
            print(f"[pyside6-webusb] build_configurations_tree(configuration): 例外を無視: {e}")
            continue
    return configurations


def interface_class_for(dev, interface_number, alternate_setting=None):
    """指定インターフェース番号のbInterfaceClassを、デバイスの現在アクティブな
    configuration内から取得する(claimInterface/controlTransfer検証時のHID等
    ブロック判定に使う)。取得できない場合は-1ではなくNoneを返す。
    🛡️ 修正1: 以前は見つからない場合に-1を返していたが、int(-1)は例外を
    投げないため is_protected_interface_class() の「判定不能なら安全側(拒否)に
    倒す」というTypeError/ValueErrorフォールバックを素通りしてしまい、
    -1 not in PROTECTED_INTERFACE_CLASSES → False(=保護対象でない)と
    誤判定されていた(実際にclaimInterface()でこの経路を通ると確認済み)。
    Noneであればint(None)がTypeErrorを送出するため、既存のフォールバックが
    意図どおり「不明なら拒否」として機能する。
    🛡️ 修正2: 以前はデバイスが持つ全configurationを横断的に探索していたが、
    実際にclaimでき/コントロール転送の対象になり得るインターフェースは常に
    「現在アクティブなconfiguration」内のものだけ(spec上の判定対象も同様)。
    ほとんどの実機はconfigurationを1つしか持たないため実害は小さいが、複数
    configurationを持つ機器では、非アクティブ側にたまたま同じ番号のインター
    フェースがあった場合にそちらを誤って拾ってしまう可能性があった。
    アクティブなconfiguration自体が特定できない場合も安全側(None)に倒す。
    🛡️ 修正3(security_audit No.1): 以前はbAlternateSettingを一切見ておらず、
    「指定interface_numberに一致する最初のInterfaceエントリ」のクラスだけを
    返していた。複合デバイスがalternate setting 0を無害なクラス、alternate
    setting 1を保護対象クラス(HID等)として宣言した場合、この関数は常に
    alternate setting 0側しか見えず、claimInterface()はそれだけを根拠に
    許可してしまっていた(CVE-2018-6125と同種の、保護対象インターフェース
    クラスへの回避策 — 詳細はVULNERABILITY_REPORT.md No.1)。
    - alternate_setting を明示した場合: その(interface_number,
      alternate_setting)の組にちょうど一致するエントリのクラスだけを返す
      (見つからなければNone = 安全側)。claimInterface()のように「今まさに
      選択されている(はずの)alternate setting」が分かっている呼び出し元向け。
    - alternate_setting=None(デフォルト、既存の呼び出し元との互換): この
      interface_number が持つ**全alternate setting**を横断し、1つでも
      保護対象クラスを宣言していればそのクラスを返す(=安全側に倒す)。
      どのalternateも保護対象でなければ、従来どおり最初に見つかったものを
      返す。_control_transfer_validation_error()のように、生のコントロール
      転送リクエストからは「選択中のalternate setting」という概念自体が
      存在しない呼び出し元向け(コントロール転送はendpoint 0宛てであり、
      alternate settingに依存しない)。
      ほとんどの実機はinterfaceあたりalternate settingが1つしかないため、
      この場合は新旧の挙動が完全に一致する — 挙動が変わるのは、alternate
      setting間でクラスが実際に異なる(稀な)複合デバイスの場合のみ。"""
    try:
        cfg = dev.get_active_configuration()
    except Exception:
        return None
    try:
        matches = [intf for intf in cfg if intf.bInterfaceNumber == interface_number]
    except Exception:
        return None
    if not matches:
        return None
    if alternate_setting is not None:
        for intf in matches:
            if getattr(intf, "bAlternateSetting", 0) == alternate_setting:
                return intf.bInterfaceClass
        return None
    for intf in matches:
        if is_protected_interface_class(intf.bInterfaceClass):
            return intf.bInterfaceClass
    return matches[0].bInterfaceClass


# ============================================================
# 5) 接続監視(connect/disconnectイベント)
# ============================================================
class UsbHotplugWatcher:
    """
    navigator.usb の 'connect'/'disconnect' イベント相当を実現するための
    ポーリング監視。pyusbはOS横断のホットプラグコールバックAPIを持たない
    (libusb自体にはあるがOS依存で不安定なため)、実用上は短間隔ポーリングで
    十分かつ確実。

    QTimer等のイベントループ駆動はbridge.py側(Qt依存)に任せ、
    このクラスはQtに依存しない「純粋な差分検出ロジック」だけを提供する。
    呼び出し側は一定間隔で poll() を呼び、戻り値の (connected, disconnected)
    のうち許可済みオリジンに関係するものだけをJSへ 'connect'/'disconnect'
    として配送する。
    """

    def __init__(self, pyusb_finder):
        # pyusb_finder: 引数無しで呼ぶと現在のUSBデバイス一覧
        # (vendor_id, product_id)のsetを返す callable
        self._pyusb_finder = pyusb_finder
        self._known = set()
        self._initialized = False
        self._lock = threading.Lock()
        self._last_poll = 0.0

    def poll(self):
        """🐛 バグ修正(v0.0.5a3): 監視開始前から挿さっていたデバイスは、
        「今まさに接続された」わけではないにもかかわらず、旧実装では最初の
        poll()が必ず「現在のデバイス一覧 - 空集合」を差分として返すため、
        起動直後に接続中の全デバイスぶんのconnectイベントが一度にJSへ
        配送されてしまっていた(実ブラウザは起動時に既に挿さっている
        デバイスについてconnectイベントを発火しない — それらは
        getDevices()で最初から見えるだけ)。初回のpoll()は現在の状態を
        「基準」として記録するだけにとどめ、connected/disconnectedは
        どちらも空のまま返す。2回目以降のpoll()は従来どおり差分検出する。
        ⚠️ 既知の制約: 識別子として(vendor_id, product_id)のみを使うsetの
        ため、全く同じVID/PIDの機器を2台同時に挿している場合、片方だけを
        抜いても(もう片方がまだ挿さっている限り)差分が検出できない
        (setからは消えない)。これはpyusbが安定した個体識別子
        (シリアル番号は未取得の機器では読めないことが多く、bus/address等の
        識別情報はOS/接続ポートの都合で抜き挿しのたびに変わりうる)を
        持たないことに由来する既知の限界であり、README「Known
        limitations」に明記する。"""
        with self._lock:
            try:
                current = self._pyusb_finder()
            except Exception:
                return [], []
            if not self._initialized:
                self._known = current
                self._initialized = True
                self._last_poll = time.time()
                return [], []
            connected = sorted(current - self._known)
            disconnected = sorted(self._known - current)
            self._known = current
            self._last_poll = time.time()
            return connected, disconnected


# ============================================================
# 6) requestDevice()/getDevices() のフィルタ照合 (WebUSB仕様 §5 Device Enumeration)
# ============================================================
# 出典: https://wicg.github.io/webusb/#dom-usb-requestdevice 内で定義されている
#   「A USB device device matches a device filter filter」
#   「A USB interface interface matches an interface filter filter」
#   「A USBDeviceFilter filter is valid」
# の3アルゴリズムをそのまま移植したもの。
#
# 旧実装はrequestDevice(options)に渡されたoptions.filters/exclusionFiltersを
# 一切参照しておらず、チューザーダイアログには(ブロックリスト機器を除く)
# 接続中の全デバイスが常に表示されていた。仕様は「filtersに一致しない
# デバイスは列挙結果から除外する」ことを必須(MUST)としており、これは
# 単なる見た目の問題ではない: 汎用WebUSB SDKの中にはfilters無し
# (=呼び出し側のミス)や意図せず広すぎるfiltersを渡すものもあり、
# 本来隠れているはずの無関係なデバイスまでチューザーに出てしまうと
# ユーザーが誤って無関係な(あるいは無関係に見えて実は機微な)デバイスを
# 選んでしまうリスクがある。
#
# is_valid_usb_device_filter()の妥当性チェック自体はJS側
# (WEBUSB_POLYFILL_JS)でTypeErrorとして先に弾く設計とし、ここへ渡って
# くるfiltersは構造的に妥当なものだけという前提を置いている(Python側は
# 念のため存在チェック程度は行うが、ここでの主目的は「一致判定」)。
def is_valid_usb_device_filter(filt) -> bool:
    """'A USBDeviceFilter filter is valid'(仕様7章相当)。より上位の
    フィールドを伴わない下位フィールドの指定はinvalid
    (例: vendorId無しでproductIdだけを指定 等)。
    さらに数値フィールドの型(int)および範囲(0-65535 / 0-255)、
    serialNumberの型(str)も厳格に検証する。"""
    if not isinstance(filt, dict):
        return False
    if "productId" in filt and "vendorId" not in filt:
        return False
    if "subclassCode" in filt and "classCode" not in filt:
        return False
    if "protocolCode" in filt and "subclassCode" not in filt:
        return False
    for key, max_val in (
        ("vendorId", 0xFFFF),
        ("productId", 0xFFFF),
        ("classCode", 0xFF),
        ("subclassCode", 0xFF),
        ("protocolCode", 0xFF),
    ):
        if key in filt:
            val = filt[key]
            if isinstance(val, bool) or not isinstance(val, int) or val < 0 or val > max_val:
                return False
    if "serialNumber" in filt and not isinstance(filt["serialNumber"], str):
        return False
    return True


def _device_interface_class_tuples(dev) -> list:
    """このデバイスが持つ全インターフェース(・全alternate)の
    (bInterfaceClass, bInterfaceSubClass, bInterfaceProtocol)を集めたもの。
    フィルタのclassCode照合で「インターフェース単位のクラス」も見るために使う
    (仕様: デバイス全体のbDeviceClassだけでなく、いずれかのインターフェースが
    一致すればそれだけでデバイス全体もmatch扱いになる。複合デバイス
    [composite device] がbDeviceClass=0xFF[vendor-specific]を名乗りつつ
    個々のインターフェースで実際のクラスを申告するケースに対応するため)。
    記述子が壊れている/読めない機器を1台巻き込んで全体を失敗させないよう、
    個々の失敗は握りつぶして安全側(=そのインターフェースは無視)に倒す。"""
    tuples = []
    try:
        for cfg in dev:
            try:
                for intf in cfg:
                    try:
                        tuples.append((intf.bInterfaceClass, intf.bInterfaceSubClass, intf.bInterfaceProtocol))
                    except Exception as e:
                        # 🔍 品質改善(v0.0.4b1): build_configurations_treeと同じ理由で
                        #    可視化する。この関数はフィルタ照合のたびに呼ばれうるため、
                        #    壊れた記述子を持つデバイスが挿さったままだと繰り返し出力
                        #    されうる点に注意(それでも「一度も分からない」よりは良い)。
                        print(f"[pyside6-webusb] _device_interface_class_tuples(interface): 例外を無視: {e}")
                        continue
            except Exception:
                continue
    except Exception:
        pass
    return tuples


def _interface_matches_filter(iface_triplet, filt) -> bool:
    """'A USB interface interface matches an interface filter filter'"""
    cls, sub, proto = iface_triplet
    if "classCode" in filt and cls != filt["classCode"]:
        return False
    if "subclassCode" in filt and sub != filt["subclassCode"]:
        return False
    if "protocolCode" in filt and proto != filt["protocolCode"]:
        return False
    return True


def device_matches_usb_filter(dev, usb_util, filt) -> bool:
    """'A USB device device matches a device filter filter'(仕様の手順をそのまま)。
    filtに存在しないキーは無条件一致(=絞り込みなし)として扱う。"""
    try:
        if not isinstance(filt, dict):
            return False
        if "vendorId" in filt and getattr(dev, "idVendor", None) != filt["vendorId"]:
            return False
        if "productId" in filt and getattr(dev, "idProduct", None) != filt["productId"]:
            return False
        if "serialNumber" in filt:
            serial = None
            try:
                if getattr(dev, "iSerialNumber", 0):
                    serial = usb_util.get_string(dev, dev.iSerialNumber)
            except Exception:
                serial = None  # 仕様: 読み取りエラー時はmismatch扱い
            if serial != filt["serialNumber"]:
                return False
        if "classCode" in filt:
            iface_tuples = _device_interface_class_tuples(dev)
            if any(_interface_matches_filter(t, filt) for t in iface_tuples):
                return True  # 仕様どおり: いずれか1つのインターフェースが一致すれば即match
            if getattr(dev, "bDeviceClass", None) != filt["classCode"]:
                return False
            if "subclassCode" in filt and getattr(dev, "bDeviceSubClass", None) != filt["subclassCode"]:
                return False
            if "protocolCode" in filt and getattr(dev, "bDeviceProtocol", None) != filt["protocolCode"]:
                return False
        return True
    except Exception:
        return False


def device_matches_any_usb_filter(dev, usb_util, filters) -> bool:
    """filtersが空リストの場合は仕様どおり「一致するものなし」
    (=1台も候補に残らない)。サイトが「フィルタなしで全デバイスを見せたい」
    場合、仕様上は filters: [{}] (空オブジェクト。どのフィールドも
    指定しないので無条件一致)を渡す必要がある——これは実際のChromiumの
    挙動も同じで、本実装だけの制約ではない。"""
    if not filters:
        return False
    try:
        return any(device_matches_usb_filter(dev, usb_util, f) for f in filters)
    except Exception:
        return False


# ============================================================
# 7) 転送失敗のうち「STALL」を仕様どおりUSBTransferStatus('stall')として扱う
# ============================================================
# 出典: https://wicg.github.io/webusb/#usbtransferstatus および6.1.2節の
# transferIn()等の仕様、および仕様6節の使用例(データチャンネルがエラーを
# STALLで通知し、呼び出し側がresult.status==='stall'を見てclearHalt()で
# 解除してから続行する、という一連の流れそのものが仕様の主要な用例)。
# 実際のブラウザはSTALLをPromiseのrejectではなく、status:'stall'を伴う
# "成功"resolveとして返す。
#
# pyusb(libusb1バックエンド)はSTALL(libusbのLIBUSB_ERROR_PIPE)を検出すると
# usb.core.USBError を送出し、errno=32("Pipe error")として報告することを、
# 複数件のpyusb issue/discussion(pyusb/pyusb#207, #351, #414, #415等、
# Linux/Windows双方の報告例)で確認した。この errno=32 は生のOS errnoでは
# なく、pyusbが usb/backend/libusb1.py 内で libusbのエラーコードから
# 固定的に変換した値であるため、OS非依存で信頼できる。
def is_stall_error(exc) -> bool:
    try:
        if getattr(exc, "errno", None) == 32:
            return True
    except Exception:
        pass
    try:
        msg = str(exc).lower()
        return "pipe error" in msg or "stall" in msg
    except Exception:
        return False


# ============================================================
# 7b) 転送失敗のうち「babble」を仕様どおりUSBTransferStatus('babble')として扱う
# ============================================================
# 出典: https://wicg.github.io/webusb/ (WICG/webusb、index.bs直接取得済み)の
# controlTransferIn()/transferIn()/isochronousTransferIn()各アルゴリズムより:
# 「"babble", if the device responded with more than |length| bytes of data」
# (isochronousTransferInは「device sent more than packetLengths[i] bytes of
# data for this packet」)。stallと同様、Promiseのreject対象ではなく
# status:'babble'を伴う"成功"resolveとして扱うべきステータス。USBTransferStatus
# enumは{"ok","stall","babble"}の3値のみ("ok"/"stall"は導入済み)。
#
# babbleはIN方向(=デバイスからホストへ、要求より多くのデータが返ってきた)
# 特有の状態であり、OUT方向のtransferOut()/controlTransferOut()/
# isochronousTransferOut()にはbabbleという概念自体が存在しない(spec上も
# 定義されていない)ため、is_babble_errorはIN方向の各メソッドでのみ使う。
#
# pyusb(libusb1バックエンド)は、デバイスが要求サイズを超えるデータを返した
# 場合、libusbのLIBUSB_ERROR_OVERFLOW(-8)を検出してusb.core.USBErrorを送出し、
# errno=75(Linux上のEOVERFLOW)、メッセージ"Overflow"として報告することを、
# is_stall_error と全く同じ手法(usb.backend.libusb1.LIBUSB_ERROR_OVERFLOWから
# 実際にUSBErrorを構築してstr(exc)/.errnoを確認)で実機検証済み:
# str(exc) == '[Errno 75] Overflow'。
#
# ⚠️ 既知の限界: pyusbの同期read API(dev.read()等)は、overflow発生時に
# 例外を送出するのみで、その例外から「オーバーフロー発生までに実際に何
# バイト受信できていたか」を取得する手段を提供しない。そのため、この実装が
# babbleを報告する際のdataは(stallの場合と同様)常に空になる — 仕様が
# 求める「bytesTransferredぶんの部分データ」の再現はできていない。
def is_babble_error(exc) -> bool:
    try:
        if getattr(exc, "errno", None) == 75:
            return True
    except Exception:
        pass
    try:
        msg = str(exc).lower()
        return "overflow" in msg or "babble" in msg
    except Exception:
        return False


# ============================================================
# 8) JSへ返すエラーメッセージの無害化
# ============================================================
# pyusb/libusb由来の例外メッセージをそのままJSON化してJS側へ渡していたが、
# バックエンド・OSによっては改行やタブを含むメッセージを返すことがあり、
# 極端に長いメッセージが返る可能性もゼロではない。JSON自体はこれらの文字を
# 正しくエスケープするので壊れはしないが、JS側でのログ表示崩れや、
# 万一の下流ログインジェクションを避けるための保険として正規化する。
def safe_error_str(exc, max_len: int = 500) -> str:
    """例外を、制御文字を含まない・長さの上限が保証された文字列に変換する。
    "SecurityError:"のような、こちら側で明示的に付けている振り分け用の
    接頭辞(文字列リテラルとして自前で組み立てているもので、str(exc)の
    生の出力ではない)には影響しない。"""
    try:
        msg = str(exc)
    except Exception:
        return "unknown error"
    msg = msg.replace("\n", " ").replace("\r", " ").replace("\t", " ")
    if len(msg) > max_len:
        msg = msg[:max_len] + "…"
    return msg


# 🛡️ security_audit No.3: U+202A-U+202E(LRE/RLE/PDF/LRO/RLO、いわゆる
#    "bidi override")とU+2066-U+2069(LRI/RLI/FSI/PDI、新しい方向分離文字)。
#    RLO等を使うと "cod.exe" のような文字列の表示順を入れ替えて
#    "exe.doc" のように見せかけられる、実際に知られたUIスプーフィング手法
#    (ファイル名偽装等で悪用された前例が多数ある)。
_BIDI_OVERRIDE_CHARS = "".join(chr(c) for c in list(range(0x202A, 0x202F)) + list(range(0x2066, 0x206A)))
_DEVICE_STRING_MAX_LEN = 255  # USB文字列記述子自体の実務上の上限より十分大きい保守的な上限


def sanitize_device_string(value, max_len: int = _DEVICE_STRING_MAX_LEN):
    """USBデバイス自身が返す文字列記述子(manufacturerName/productName/
    serialNumber/configurationName/interfaceName)向けのサニタイザー。
    🛡️ これらの文字列はエラーメッセージ(safe_error_str()の対象)よりも
    さらに攻撃者(=デバイス自身)制御下にあるにもかかわらず、従来は
    safe_error_str()と同水準のサニタイズが一切適用されておらず、制御文字・
    bidiオーバーライド文字・無制限長がbuild_device_descriptor()を素通り
    していた。chooser_dialog.py(QLabelへそのまま表示)を含む全ての
    利用箇所で一律に安全になるよう、生成元であるこの関数側で対処する。
    None/非文字列はそのまま返す(iManufacturer等が無い場合のNoneは
    正当な「無し」を表す値であり、空文字列に化けさせるべきではない)。"""
    if not isinstance(value, str):
        return value
    # 全てのC0/C1制御文字(タブ・改行・復帰・NUL等を含む)を除去
    cleaned = "".join(ch for ch in value if not (ch <= "\x1f" or "\x7f" <= ch <= "\x9f"))
    cleaned = "".join(ch for ch in cleaned if ch not in _BIDI_OVERRIDE_CHARS)
    if len(cleaned) > max_len:
        cleaned = cleaned[:max_len] + "…"
    return cleaned


# ============================================================
# 9) 大容量データ転送(WebADB等)向けの実務上のガード
# ============================================================
# WebUSBは「ADB (Android Debug Bridge) をブラウザから直接叩く」用途
# (WebADB/Tangoなど)で広く使われている。ADBプロトコルはUSB bulk転送を
# 使い、1回のtransferOut()/transferIn()で数百KB〜数MBのペイロードを
# やり取りすることが珍しくない。以下は、そうした「正当な大容量転送は
# 通したいが、行儀の悪い/悪意あるページが天文学的なサイズを要求してホスト
# 側プロセスに無制限のメモリ確保・無期限ブロックを強制することは防ぎたい」
# という要求のための、この実装独自の防御的な仕組み(いずれも仕様が要求する
# 値ではない — 仕様のtransferIn()のlength引数型はunsigned long、
# controlTransferIn()はunsigned shortだが、それをそのまま信用してホスト側で
# 即座にそのサイズのバッファを確保するのは安全ではない)。

# controlTransferIn()のlengthは仕様上 WebIDL の unsigned short (0-65535)。
CONTROL_TRANSFER_MAX_LENGTH = 0xFFFF

# 🛡️ v0.0.4b2: 実Chrome(Blink)のソース(third_party/blink/renderer/modules/
# webusb/usb_device.cc)を実際に取得して確認したところ、この実装が独自に
# 定めていた上限(旧: bulk=64MiB, isochronous合計=16MiB、いずれも根拠のない
# 独自の見積もり)とは別に、Blink自身が"kUsbTransferLengthLimit"という
# 実在の定数を持っており、値は32MiB(32 * 1024 * 1024)、bulk/isochronousの
# 両方に同じ値が適用されていた(kWebUSBTransferSizeLimitというフィーチャ
# フラグの有効時。無効な場合はBlink側では上限なし=Mojo IPCメッセージ長等の
# より上位の制約に委ねられる形になる)。
#
# 🔓 方針転換(v0.0.4b2): 当初はこの32MiBを本実装でも「そのまま拒否の閾値」
# として採用していたが、このプロジェクトは意図的に「実Chromeの完全な代替品」
# ではなく「WebUSBではあるが独自拡張も持つ実装」として作られている方針の
# ため、実Chrome由来のこの制限を「拒否」ではなく「参考値」として扱うことにした:
#   - 転送が32MiBを超えても実際には拒否せず処理を続行する(host側の生存を
#     脅かさない範囲=HOST_SAFETY_MAX_TRANSFER_LENGTH以下である限り)。
#   - ただし黙って通すのではなく、実Chromeなら拒否していたはずだという事実を
#     DevTools consoleへ警告として明示する(chrome_transfer_limit_warning()。
#     挙動の相違を隠さない、という透明性を保つ。実Chromeのエラーを騙る
#     のではなく、「これは実Chromeではなくpyside6-webusbだから通っている」
#     ことを明記する)。
CHROME_USB_TRANSFER_LENGTH_LIMIT = 32 * 1024 * 1024

# 上記とは完全に独立した、この実装自身のためのハード上限。Chrome互換性とは
# 無関係の理由(あまりに巨大なlengthを鵜呑みにしてホスト側で即座にその
# サイズのバッファを確保するのは、それ自体として安全ではない、という
# この実装自身のプロセス保護方針)で維持する。512MiBはWebADBは元より
# 通常のWebUSB用途を大きく上回りつつ、暴走(数十GBの確保要求等)は
# 防げる値として設定した——CHROME_USB_TRANSFER_LENGTH_LIMITとは目的も
# 値も別物である点に注意。
HOST_SAFETY_MAX_TRANSFER_LENGTH = 512 * 1024 * 1024

# transferIn()(=bulkTransferIn)のlength上限。実際に拒否されるのは
# HOST_SAFETY_MAX_TRANSFER_LENGTHを超えたときだけで、
# CHROME_USB_TRANSFER_LENGTH_LIMITを超えるだけなら警告付きで処理を続行する。
BULK_TRANSFER_MAX_LENGTH = HOST_SAFETY_MAX_TRANSFER_LENGTH

# isochronousTransferIn()のpacketLengths合計の上限。上と同じ二段階方式。
# 実Chromeでは同じkUsbTransferLengthLimitがbulkと共通で使われている
# (isochronousTransferIn/Out双方のC++実装が同じShouldRejectUsbTransferLength()
# を呼んでいることを確認済み)。
ISOCHRONOUS_TRANSFER_MAX_TOTAL_LENGTH = HOST_SAFETY_MAX_TRANSFER_LENGTH


def chrome_transfer_limit_warning(actual_length: int) -> str:
    """actual_lengthバイトの転送が実Chromeの32MiB上限(kUsbTransferLengthLimit)を
    超えている場合に、DevTools consoleへ表示する警告文を組み立てる。
    実Chromeが投げるDataErrorの実際の文言("The data buffer exceeded supported
    maximum size of %d bytes"、Blinkソースで確認済み)を引用しつつ、これは
    実Chromeではなくpyside6-webusbであり、この制限を課していないために処理を
    続行していることを明記する——実Chromeの挙動を偽装するのではなく、
    相違点を利用者へ透明に説明することが目的。"""
    return (
        f"[pyside6-webusb] This transfer is {actual_length} bytes, which exceeds the "
        f"{CHROME_USB_TRANSFER_LENGTH_LIMIT}-byte limit real Chrome enforces here — "
        f"real Chrome would reject this with "
        f'DataError: "The data buffer exceeded supported maximum size of '
        f'{CHROME_USB_TRANSFER_LENGTH_LIMIT} bytes" (confirmed by reading Blink\'s own '
        f"usb_device.cc). This is pyside6-webusb, not Chrome — it does not enforce that "
        f"limit, so this transfer is proceeding normally rather than failing. "
        f"(HOST_SAFETY_MAX_TRANSFER_LENGTH={HOST_SAFETY_MAX_TRANSFER_LENGTH} is this "
        f"implementation's own, much larger, unrelated safety ceiling.)"
    )


# bulkTransferIn/Outを内部的に分割する際の1サブチャンクあたりの上限バイト数。
# 単一の巨大なpyusb呼び出し(例: 2MBのdev.read()を1回)は、デバイスが
# データを出し渋る/応答しなくなった場合に、その呼び出し全体が完了する
# までQtのメインスレッド(=アプリ全体のUI)を長時間ブロックしてしまう
# (この実装の各転送メソッドはQWebChannelの@Slotとしてメインスレッド上で
# 同期的に実行されるため)。256KiB単位のサブチャンクに分割し、各サブ
# チャンクの合間にQCoreApplication.processEvents()を挟むことで、
# 「1回のブロッキング呼び出しの最大長」を大幅に縮め、その間にUIが
# 完全に固まりきることを防ぐ(完全な非同期化ではなく、あくまで
# 定期的に一息つかせる形の緩和策であることに注意。README/CHANGELOG参照)。
BULK_TRANSFER_CHUNK_SIZE = 256 * 1024

# バルク/コントロール転送のタイムアウト(ミリ秒)を、転送予定バイト数に応じて
# スケールさせる。
#
# 位置づけ: WebUSBのtransferIn()/transferOut()/controlTransferIn()/
# controlTransferOut()はいずれも「timeout」という概念自体をJSへ公開して
# いない(=呼び出し側は「時間がかかっても完了を待つ」ことを期待できる)。
# この実装は内部的にpyusb(=libusb)へタイムアウト付きで転送を依頼する
# 都合上、何らかの値を選ばなければならない立場にある。
#
# 固定5秒では、低速リンクや大容量ペイロード(WebADBのファイルpush等、
# 数百KB〜数MB規模になりうる)で、正当な転送が完了前に打ち切られてしまう。
# かといって無期限ブロック(timeout=None)にすると、この実装の各転送メソッドは
# Qtのメインスレッド上で同期的に実行される@Slotであるため、デバイスが
# (切断・フリーズ等で)応答しなくなった際にアプリ全体のUIがフリーズして
# しまう(これも実際に起こりうるバグ)。両者の折衷として、ベースタイムアウトに
# 「保守的に見積もった最低速度」で計算した所要時間を加算しつつ、上限もかけて
# 無期限ブロックにはしない、という現実的なスケーリングを行う。
_TRANSFER_TIMEOUT_MIN_MS = 5000
_TRANSFER_TIMEOUT_MAX_MS = 120000
_TRANSFER_ASSUMED_MIN_THROUGHPUT_BYTES_PER_MS = 100  # 100 KB/s 相当の保守的な下限


def scaled_transfer_timeout_ms(payload_size_bytes: int) -> int:
    """payload_size_bytes バイトの転送に許すタイムアウト(ミリ秒)を返す。
    小さい転送では最低5秒、大きい転送では100KB/s相当の下限スループットを
    見積もって加算し、最大120秒で頭打ちにする。"""
    try:
        size = max(0, int(payload_size_bytes))
    except Exception:
        size = 0
    scaled = _TRANSFER_TIMEOUT_MIN_MS + (size // _TRANSFER_ASSUMED_MIN_THROUGHPUT_BYTES_PER_MS)
    return min(scaled, _TRANSFER_TIMEOUT_MAX_MS)
