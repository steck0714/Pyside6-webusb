# -*- coding: utf-8 -*-
"""
bridge.py
=========
navigator.usb ポリフィル用のPython側ブリッジ本体 (WebUSBBridge)。QWebChannel経由で
polyfill.py 側のJSと通信し、実際のUSB通信は pyusb (内部で libusb というC言語ライブラリを
使用) に委譲する。

Typical usage (see polyfill.py's `install()` for the one-line version)::

    from pyside6_webusb import install
    install(web_engine_page)

or manually::

    from pyside6_webusb.bridge import WebUSBBridge
    from PySide6.QtWebChannel import QWebChannel

    bridge = WebUSBBridge(parent=page, settings_organization="MyApp", settings_application="MyApp")
    channel = QWebChannel(page)
    channel.registerObject("pyUsbBridge", bridge)
    page.setWebChannel(channel)
    # ...then inject qwebchannel.js + polyfill.WEBUSB_POLYFILL_JS as a QWebEngineScript
    # at DocumentCreation time. See polyfill.install() for the full wiring.
"""
import base64
import binascii
import json
import secrets
import sys
import time
import weakref

from PySide6.QtCore import QCoreApplication, QObject, Signal, Slot, QTimer, QSettings

from ._version import __version__
from .i18n import chooser_strings_for, log_text, resolve_locale
from .platform_support import capability_summary, platform_summary, setup_hints

# 🆕 v0.0.5a1: Python 3.15 (Doc/whatsnew/3.15.rst, Lib/base64.py,
# Modules/binascii.c を実ソース確認済み)でbase64.b64decode()にcanonical
# 引数が追加された。canonical=Trueだとパディングビットが非ゼロ等の
# 「非正規(non-canonical)」なbase64をbinascii.Errorで拒否する
# (RFC 4648 §3.5「Decoders MAY reject non-zero padding bits」)。
# 3.15未満にはこの引数自体が無い(TypeErrorになる)ため、バージョンで
# 分岐する。
#
# 🔮 v0.0.6: 関数化してテスト可能にした(以前はモジュール読み込み時に一度
# だけ評価される定数だったため、「3.16になっても正しく動き続けるか」を
# 実際の3.16インタプリタなしに検証する手段が無かった)。判定式自体は
# `>=` を使った"3.15以上"という床(floor)判定であり、上限(ceiling)を
# 設けていないため、3.16はもちろん3.17やそれ以降でも変わらずTrueに
# なり続ける設計であることを、tests/test_bridge.pyの
# test_b64_decode_supports_canonical_is_forward_compatible_beyond_3_15
# が(3, 16, 0)や(3, 99, 0)のような未来のversion_infoを直接与えて証明する
# (このパッケージの通常のCIが実際の3.16インタプリタ上で走っていなくても
# 検証できる)。引数省略時は実際に動いているインタプリタのsys.version_info
# を使う——モジュール読み込み時に一度だけ評価される挙動そのものは
# 0.0.5.post7までと完全に同じ(_B64_DECODE_SUPPORTS_CANONICALは従来どおり
# モジュール属性として存在し、下の_b64decode()もそれを直接参照する)。
def _b64_decode_supports_canonical(version_info=None) -> bool:
    if version_info is None:
        version_info = sys.version_info
    return tuple(version_info)[:2] >= (3, 15)


_B64_DECODE_SUPPORTS_CANONICAL = _b64_decode_supports_canonical()

# 🦀 大容量転送(WebADB等)向けのオプショナルなRustアクセラレーション。
# `native/pyside6_webusb_accel/`(maturinでビルドするPyO3拡張)がビルド済みで
# importできればそれを使い、そうでなければ標準ライブラリのbase64へ
# 自動的にフォールバックする。Rust拡張が無くてもpyside6-webusbは完全に動作する
# ——これは性能面のみのオプトイン最適化であり、必須の依存関係ではない
# (README「Rust acceleration (optional)」節、CHANGELOG v0.0.4bを参照)。
try:
    import pyside6_webusb_accel as _rust_accel
    HAVE_RUST_ACCEL = True
except ImportError:
    _rust_accel = None
    HAVE_RUST_ACCEL = False


def _b64encode(data) -> str:
    if HAVE_RUST_ACCEL:
        return _rust_accel.encode_base64(bytes(data))
    return base64.b64encode(bytes(data)).decode("ascii")


def _b64decode(s: str) -> bytes:
    """base64文字列をbytesへ。

    🛡️ 入力検証(v0.0.5a1): QWebChannelは素のJSオブジェクトとして公開される
    ため、悪意あるフレームはWEBUSB_POLYFILL_JSを経由せずcontrolTransferOut等の
    data引数へ任意の文字列を直接渡せる。正規のエンコーダ(_b64encode/JSの
    btoa())は常に正規形のbase64しか生成しないため、以下の正規性
    (canonical)チェックで正規の呼び出しが壊れることはない——弾かれるのは
    非ゼロパディングビットや代替アルファベット混入を意図的に仕込んだ
    入力のみ。失敗時はbinascii.Errorを送出する(呼び出し元は
    _b64decode_or_data_error()経由でDataErrorとしてJSへ届けること)。

    Python 3.15+ではbase64.b64decode()自身のcanonical引数(C実装の
    binascii.a2b_base64側で判定)を使う。3.15未満ではその引数が無いため、
    デコード結果を再エンコードして入力文字列と一致するかで同じ判定を行う
    (RFC 4648の正規形かどうかを、バージョンに依存せず判定できる同値な
    方法——実際にcanonical=Trueが内部でしている「非ゼロパディングビットの
    拒否」は、正規のエンコーダなら絶対に作らないビット列を弾くことと
    等価なので、round-trip比較で同じ結果になる)。

    🐛 バグ修正(v0.0.5a3): 従来はRust高速パス(_rust_accel.decode_base64)が
    この正規性チェックを一切行わず(そのままの生バイト列を返すだけ)、
    非正規base64の拒否はPure Pythonパスでしか効いていなかった
    (v0.0.5a1〜post3のCHANGELOGに「既知の制約」として明記していたギャップ)。
    Rust側のデコード結果そのものは信頼しつつ、Pythonの標準ライブラリで
    再エンコードした結果と入力文字列を比較する同じround-trip判定を
    Rust経路にも適用することで、デコード自体の速度は落とさずに
    (再エンコード1回ぶんのコストのみ追加)検証だけを両経路で揃えた。
    比較対象は常にPython標準ライブラリのbase64.b64encode()の出力とする
    (Rust側のエンコーダを検証の基準に使うと、エンコーダ自身に不具合が
    あった場合に検証がすり抜けてしまう自己参照になるため)。"""
    if HAVE_RUST_ACCEL:
        decoded = bytes(_rust_accel.decode_base64(s))
        if base64.b64encode(decoded).decode("ascii") != s:
            raise binascii.Error("Non-canonical base64 string (unexpected padding bits or alphabet)")
        return decoded
    if _B64_DECODE_SUPPORTS_CANONICAL:
        try:
            return base64.b64decode(s, canonical=True)
        except TypeError:
            # 保険: rc2〜正式版の間でcanonical引数の名前/対応状況が変わって
            # いた場合でも、データ検証自体(binascii.Error)は握りつぶさず
            # 下のround-trip判定へフォールバックする。
            pass
    decoded = base64.b64decode(s)
    if base64.b64encode(decoded).decode("ascii") != s:
        raise binascii.Error("Non-canonical base64 string (unexpected padding bits or alphabet)")
    return decoded


def _b64decode_or_data_error(s: str):
    """_b64decode()のラッパー。"""
    if not isinstance(s, str):
        return None, _json_dumps({
            "success": False,
            "error": data_error("base64 payload must be a string"),
        })
    max_b64_len = ((HOST_SAFETY_MAX_TRANSFER_LENGTH + 2) // 3) * 4 + 64
    if len(s) > max_b64_len:
        return None, _json_dumps({
            "success": False,
            "error": data_error(
                f"The data buffer exceeded supported maximum size of {HOST_SAFETY_MAX_TRANSFER_LENGTH} bytes"
            ),
        })
    """_b64decode()のラッパー。戻り値は(data, error_json)のタプルで、
    data is Noneのときerror_jsonをそのままreturnすべきことを示す
    (_control_transfer_validation_error()等、既存の「検証NGならJSON文字列を
    返す/OKならNoneを返す」パターンに合わせた形)。

    🛡️ バグ修正(v0.0.5a1): 従来はbase64.b64decode()が送出する
    binascii.Errorが個別のtry/exceptで捕まえられず、呼び出し元メソッド
    末尾の`except Exception as e: return _json_dumps({"error": safe_error_str(e)})`
    まで素通りしていた。この経路にはerrors.pyの規約上の接頭辞
    ("DataError: "等)が付かないため、polyfill.py側のthrowFromResult()が
    どのDOMExceptionにも振り分けられず、デフォルトのNetworkErrorへ
    フォールバックしていた——不正なbase64という「データの中身がおかしい」
    ケースにも関わらず、実Chromeが使うDataErrorにならないという仕様不一致。"""
    try:
        return _b64decode(s), None
    except (binascii.Error, ValueError) as e:
        return None, _json_dumps({
            "success": False,
            "error": data_error(f"Invalid base64 data: {safe_error_str(e)}"),
        })


def _json_dumps(obj) -> str:
    """json.dumps()のラッパー。区切り文字からデフォルトの空白
    (', ' / ': ')を落としたコンパクト形式で出力する。JSON.parse()する側
    (polyfill.py)には空白の有無は一切関係しない(JSONの構文上、空白は常に
    無視される)ため純粋な転送量削減であり、Rustアクセラレーション版
    (format_transfer_in_success_json、空白を入れずに直接組み立てている)と
    出力形式を揃える意味もある——HAVE_RUST_ACCELの有無でワイヤ上の
    バイト列が変わってしまわないようにする。"""
    return json.dumps(obj, separators=(",", ":"))


def _format_transfer_success_json(status: str, data, warning=None) -> str:
    """{"success":true,"status":<status>,"data":<base64(data)>} 形式の
    レスポンスJSONを組み立てる。🚚 データ転送最適化(v0.0.4b1): Rustが使える
    場合は bytes連結→base64エンコード→json.dumps という3段階すべてを
    Rust側の1回のバッファ構築にまとめたformat_transfer_in_success_json()を
    使い、大容量ペイロードで発生する中間Pythonオブジェクト(base64文字列・
    JSON文字列)のコピーを1回分減らす。

    warning(v0.0.4b2): 指定した場合、レスポンスへ"warning"フィールドとして
    含める(chrome_transfer_limit_warning()等、DevTools consoleへ表示したい
    但し書き用)。warningが要る呼び出しはそもそも巨大転送(32MiB超)という
    レアケースに限られるため、その場合だけRust高速パスを使わずPure Python側
    (JSON構築の手間が1回増えるだけで、転送そのものの重さに比べれば無視できる)
    に倒して実装をシンプルに保つ。

    ⚠️ status引数は必ず"ok"/"stall"/"babble"のような、こちら側で完全に
    把握している固定文字列リテラルのみを渡すこと。Rustパス
    (format_transfer_in_success_json)はJSON文字列エスケープを一切行わない
    ため、任意のテキスト(例外メッセージ等)をここに渡すと壊れたJSON、
    または(理論上は)JSONインジェクションを生みうる。エラーメッセージ等の
    自由テキストを含むレスポンスには、これまでどおり_json_dumps()を直接
    使うこと。"""
    if warning is None and HAVE_RUST_ACCEL:
        return _rust_accel.format_transfer_in_success_json(status, bytes(data))
    obj = {"success": True, "status": status, "data": _b64encode(data)}
    if warning is not None:
        obj["warning"] = warning
    return _json_dumps(obj)


from .errors import (
    data_error,
    index_size_error,
    invalid_access_error,
    invalid_state_error,
    not_found_error,
    security_error,
    type_error,
)
from .frame_origin import url_to_origin
from .hardening import (
    BULK_TRANSFER_CHUNK_SIZE,
    BULK_TRANSFER_MAX_LENGTH,
    CHROME_USB_TRANSFER_LENGTH_LIMIT,
    CONTROL_TRANSFER_MAX_LENGTH,
    HOST_SAFETY_MAX_TRANSFER_LENGTH,
    ISOCHRONOUS_TRANSFER_MAX_TOTAL_LENGTH,
    UsbHotplugWatcher,
    build_device_descriptor,
    chrome_transfer_limit_warning,
    device_is_fully_blocked,
    device_matches_any_usb_filter,
    interface_class_for,
    is_babble_error,
    is_blocklisted_device,
    is_protected_interface_class,
    is_stall_error,
    is_valid_usb_device_filter,
    protected_class_name,
    safe_error_str,
    scaled_transfer_timeout_ms,
)
from .chooser_dialog import WebUsbDeviceChooserDialog


def _find_usb_device(usb_core, usb_util, vendor_id, product_id, serial_number=None):
    """vendorId/productIdに一致するデバイスを検索する。serial_numberが指定されている場合は
    該当シリアル番号を持つデバイスを最優先で探索し、同一VID/PIDの複数機器が存在する環境でも
    意図した実機を正確に特定できるようにする。"""
    candidates = list(usb_core.find(find_all=True, idVendor=vendor_id, idProduct=product_id))
    if not candidates:
        return None
    if serial_number:
        for dev in candidates:
            try:
                if getattr(dev, "iSerialNumber", 0):
                    s = usb_util.get_string(dev, dev.iSerialNumber)
                    if s == serial_number:
                        return dev
            except Exception:
                pass
    return candidates[0]


try:
    import shiboken6 as _shiboken
    _is_valid_qobject = _shiboken.isValid
except Exception:  # pragma: no cover - shibokenが無い環境では常にTrue扱い
    def _is_valid_qobject(_obj):
        return True


def _weak_callback(obj, method_name):
    """QObjectのメソッドを「弱参照つきの素のPython関数」として返す(Signal接続用)。

    🛡️ security_audit No.9(v0.0.6a): `sig.connect(self._method)` のようにQObject
    自身のバウンドメソッドをSignalへ接続すると、PySide6はそのメソッドを動的スロット
    としてQObjectのメタオブジェクトへ登録する。QWebChannelは登録済みオブジェクトの
    「全ての公開スロット」をJavaScriptへ露出するため、`_on_page_navigated` や
    `_poll_hotplug` のような内部メソッドが**任意のWebページから直接呼べて**しまった
    (実機のQtWebEngineで、他オリジンのオープン中ハンドルを破棄できることを確認)。
    素のクロージャ経由で接続すればメタオブジェクトには載らない。弱参照なので
    ブリッジの寿命も延ばさない。
    """
    ref = weakref.ref(obj)

    def _callback(*_args):
        target = ref()
        if target is None or not _is_valid_qobject(target):
            return
        try:
            getattr(target, method_name)()
        except RuntimeError:
            pass  # C++側が既に破棄されている
    return _callback


class WebUSBBridge(QObject):
    """
    navigator.usb ポリフィル用のPython側ブリッジ（QWebChannel経由でJSと通信）。
    実際のUSB通信は pyusb（内部で libusb というC言語ライブラリを使用）が担う。
    QtWebEngine自体にはWebUSBのAPIが存在しないため、この仕組みで代替する。

    ★ フェイルセーフ設計: 全ての@Slotメソッドは、例外が絶対にQtのメタオブジェクト
    呼び出し境界を越えて漏れないよう、メソッド全体を単一のtry/exceptで包んでいる。
    PySide6ではQtのC++側から呼ばれるスロット内で未捕捉のPython例外が発生すると、
    単に無視されるだけでなくアプリケーション全体が強制終了する場合があるため、
    「何が起きても必ず有効なJSON文字列を返す」ことを徹底している。

    セキュリティモデルの要点(詳しくはREADME参照):
      - Audio/HID/Mass Storage/Hub/Smart Card/Video/Audio-Video/Wireless Controller
        の8つの「保護対象インターフェースクラス」はclaimInterface自体を拒否する
        (WebUSB仕様 #protected-interface-classes が定めるものと同じ一覧)。
      - 上記に加えて、既知のFIDO/セキュリティキー製品をvendor_id/product_id単位で
        ブロックリスト化(Chromiumのusb_blocklist.cc準拠)。
      - claimInterfaceの保護は controlTransferIn/Out からも回避できない:
        requestType:'class'や recipient:'interface'/'endpoint' で保護対象クラスや
        未claimのインターフェースを直接狙う呼び出しは、実機に届く前に
        _control_transfer_validation_error() で拒否する
        (WebUSB仕様の「check the validity of the control transfer parameters」
        アルゴリズム相当)。
      - requestDevice()はユーザーが実際に選んだ1台の情報しかサイトに渡さない
        (チューザーダイアログでの明示的な操作が必須)。
      - オリジン単位の許可の一覧化・個別失効・全失効API。
    """

    # 🛡️ navigator.usb の 'connect'/'disconnect' 相当。JSON化したデバイス記述子を
    #    引数に取る。許可されていないオリジンには(JS側で)配送しない。
    deviceConnected = Signal(str)
    deviceDisconnected = Signal(str)

    def __init__(self, browser_window=None, parent=None,
                 settings_organization="pyside6-webusb", settings_application="WebUSBBridge",
                 usb_backend=None, locale=None, chooser_strings=None,
                 chooser=None, transport_kind="webchannel"):
        """
        browser_window: 任意。`.settings` 属性(QSettingsオブジェクト)を持つホストアプリの
            メインウィンドウ等を渡すと、許可の永続化にそれを使う。渡さない場合は
            QSettings(settings_organization, settings_application) にフォールバックする。
        parent: 通常はこのブリッジを保持する QWebEnginePage を渡す(ページ遷移時に
            開きっぱなしのハンドルを破棄するため)。
        settings_organization / settings_application: browser_windowが無い場合に使う
            QSettingsの組織名・アプリ名。ホストアプリ独自の値を渡すことを推奨する
            (省略時は "pyside6-webusb"/"WebUSBBridge" になる)。
        usb_backend: 🆕 v0.0.5a3。省略時は実機を操作するpyusb(usb.core/usb.util)を
            遅延importして使う(従来どおり)。`(usb_core, usb_util)` のタプルを渡すと、
            以降このインスタンスの全操作がそちらへ差し替わる——実USBハードウェアを
            挿さずに開発・自動テストするための「仮想USBデバイス」機能
            (pyside6_webusb.virtual.make_virtual_usb_backend())が使う差し込み口。
            usb.core/usb.util と同じ最小限のインターフェースを満たす自作オブジェクトを
            渡しても良い(pyside6_webusb.virtual、またはsecurity_audit/_fixtures.pyの
            FakeUsbCore/FakeUsbUtilを参照)。
        locale: 🆕 v0.0.5b3。デバイスチューザーダイアログの表示言語。
            "en"/"ja"/"zh"(pyside6_webusb.i18n.SUPPORTED_LOCALES)、OSロケールへ
            明示的に追従させる特別値 "auto"、または省略(None、既定は"ja"——理由は
            i18n.DEFAULT_LOCALEのdocstring参照)のいずれか。認識できない値は
            i18n.normalize_locale()により静かに既定値へフォールバックする
            (ロケール文字列の間違いでチューザーダイアログ自体が出せなくなっては
            本末転倒なため)。
        chooser_strings: 🆕 v0.0.5b3。localeが選ぶ既定文言をさらに上書きしたい場合に
            渡す。dict(一部のキーだけの部分上書きも可。例: {"trust_reminder": "..."} )、
            または"en"/"ja"/"zh"/"auto"のいずれかの文字列(その言語の既定文言一式へ
            切り替える、localeとは独立したショートカット)を受け付ける。
            _resolve_chooser_strings()参照。
        """
        super().__init__(parent)
        self.browser_window = browser_window
        self._settings_organization = settings_organization
        self._settings_application = settings_application
        self._usb_backend_override = usb_backend
        # 🆕 v0.0.6a: デバイス選択UIの差し替え(callable(devices, origin, strings)->dict|None)と、
        #    このブリッジがどの転送層(webchannel/websocket)で使われているか。
        self._chooser_override = chooser
        self._transport_kind = transport_kind
        self._allow_delete = False
        self._hotplug_listeners = []
        self._top_level_url_provider = None   # callable() -> QUrl|str|None (QtWebView等 page.url() が無い場合)
        self._locale = locale
        self._chooser_strings_override = chooser_strings
        self._open_devices = {}   # handle_id(int) -> {"device":.., "origin":.., "claimed_interfaces": set()}
        # 🧵 大容量bulk転送のチャンク分割(BULK_TRANSFER_CHUNK_SIZE)を行う際、
        #    サブチャンクの合間にQCoreApplication.processEvents()を挟んで
        #    メインスレッド(=UI)を一息つかせる。この間に同じhandle_idへの
        #    別の転送呼び出しが再入してくると、同一デバイスへ向けたpyusb呼び
        #    出しが入り乱れてデータが壊れる恐れがあるため、handle_idごとに
        #    「今チャンク転送中かどうか」を追跡し、再入を検出したら安全に
        #    エラーを返す(状態を壊すより早く失敗させる)。
        self._busy_handles = set()
        self._next_handle = 1
        # 🛡️ requestDeviceChooser()の再入防止フラグ。dlg.exec()はネストしたQtイベント
        #    ループを回すため、その最中に(同じページからの連打や、別タブ/別フレーム
        #    経由で)requestDeviceChooser()がもう一度呼ばれると、このメソッドが
        #    再入してチューザーダイアログが二重に開いてしまう恐れがある
        #    (WebUSBBridgeインスタンスはページ単位なので、同一インスタンスへの
        #    再入だけを防げば十分)。
        self._chooser_active = False
        # 🛡️ フレーム単位オリジン特定(frame_origin.FrameOriginTracker)。
        #    install()がこのページを配線する際にセットする。未設定(None)の
        #    ままなら、_current_origin()は従来どおりpage.url()だけを見る
        #    後方互換パス(make_bridge()等でのテストや、install()を使わない
        #    利用)を使う。
        self._frame_tracker = None
        # 🛡️ security_audit No.2: requestDeviceChooser()の「本物のユーザー操作
        #    (クリック等)からの呼び出しか」をPython側で検証するためのトークン
        #    ストア。polyfill.py がnavigator.userActivation.isActiveを確認した
        #    直後にmintGestureToken()を呼んで発行を受け、そのトークンを
        #    requestDeviceChooser()へ渡す。トークンは短命(_GESTURE_TOKEN_TTL_SECONDS)
        #    ・使い切り(検証時にpopする)。
        #    ⚠️ 正直な限界: mintGestureToken()自体も他の@Slotと同様、素のQWebChannel
        #    接続から直接叩ける。PySide6/QtWebEngineの公開APIには「ページ内で
        #    本物のユーザー操作が今まさに起きているか」をPython側から独立に
        #    確認する手段が無いため、この仕組みは「polyfill.py経由の正規フローが
        #    最低限もう1往復のハンドシェイクを踏まなければならない」という
        #    フリクションを課すこと、およびNo.2bのフィルタ構造検証を確実に
        #    サーバー側で通すことまでは達成できるが、mint自体を直接叩く
        #    高度に自動化された敵対的スクリプトまでは防げない。実ブラウザ相当の
        #    完全な保証には、Chromiumの実際のUser Activation状態をQt側から
        #    観測できるAPIが必要で、現時点のPySide6/QtWebEngineには存在しない。
        self._gesture_tokens = {}  # token(str) -> 発行時刻(time.monotonic())

        # 🛡️ ページが別オリジンへ遷移したら、開きっぱなしのUSBハンドルを即座に破棄する。
        #    (サイトAが開いたハンドル番号をサイトBが使い回して乗っ取る、を防ぐ)
        #    parentは実際にはこのブリッジを保持する QWebEnginePage。
        try:
            if parent is not None and hasattr(parent, "urlChanged"):
                parent.urlChanged.connect(_weak_callback(self, "_on_page_navigated"))
        except Exception as e:
            self._log("__init__", e)

        # --- ホットプラグ(接続/切断)監視 ---
        self._hotplug_watcher = None
        self._hotplug_timer = None
        try:
            def _enum_vid_pid_set():
                usb_core, _u = self._pyusb()
                return {(d.idVendor, d.idProduct) for d in usb_core.find(find_all=True)}
            self._hotplug_watcher = UsbHotplugWatcher(_enum_vid_pid_set)
            self._hotplug_timer = QTimer(self)
            self._hotplug_timer.setInterval(1500)  # 1.5秒間隔。頻度と消費電力のバランス
            self._hotplug_timer.timeout.connect(_weak_callback(self, "_poll_hotplug"))
            self._hotplug_timer.start()
        except Exception as e:
            self._log("PyUsbBridge hotplug watcher init", e)

    def _log(self, context, error):
        """🆕 v0.0.6: 「例外を無視する」デバッグprintの共通経路。以前はこのクラス内
        だけで約30箇所、`print(f"[pyside6-webusb] X: 例外を無視: {e}")` という
        日本語決め打ちの文字列をその場で個別に組み立てていた——self._locale
        (install()/WebUSBBridge(locale=...)が既に受け付けているのに、これらの
        printだけはそれを一切参照していなかった)を反映するよう、i18n.log_text()
        経由に統一する(i18n.LOG_STRINGSのモジュールdocstring、errors.pyの
        同種の集約と同じ考え方)。呼び出し元は例外時にそのまま
        `self._log("context", e)` と呼ぶだけでよい。
        ログ出力自体の失敗(通常起こり得ないが、例えば標準出力が閉じている等)で
        呼び出し元の処理を巻き込んで落とさないよう、ここ自体もexceptで包む。"""
        try:
            print(log_text(self._locale, "exception_ignored", context=context, error=error))
        except Exception:
            pass

    def event(self, e):
        """🛡️ security_audit No.9(v0.0.6a): ページからの `bridge.deleteLater()` を無効化する。

        deleteLater()はQObject由来の公開スロットなので、QWebChannel経由で任意のページが
        呼べてしまい、ブリッジ(=そのページのWebUSB機能全体)を破棄できた。
        DeferredDeleteイベントを飲み込めば、ページからの呼び出しは何も起こさない。
        ホスト側が本当に破棄したいときは dispose() を使う(親QObjectの破棄に伴う
        デストラクタ経由の削除はDeferredDeleteを使わないので影響を受けない)。
        """
        try:
            from PySide6.QtCore import QEvent
            if e.type() == QEvent.Type.DeferredDelete and not self._allow_delete:
                return True
        except Exception:
            pass
        return super().event(e)

    def dispose(self):
        """ホスト側からブリッジを安全に破棄する(ページからのdeleteLater()は無効)。"""
        self._allow_delete = True
        try:
            if self._hotplug_timer is not None:
                self._hotplug_timer.stop()
        except Exception as ex:
            self._log("dispose", ex)
        # 注意: ページが先に deleteLater() を呼んでいた(=上のevent()が飲み込んだ)場合、Qtは
        # 「deleteLater済み」のフラグを立てたままにするので、その後の deleteLater() は
        # 黙って無視される(実測)。DeferredDeleteイベントを直接postすればフラグを迂回できる。
        try:
            from PySide6.QtCore import QCoreApplication, QEvent
            QCoreApplication.postEvent(self, QEvent(QEvent.Type.DeferredDelete))
        except Exception:
            self.deleteLater()

    def add_hotplug_listener(self, listener):
        """listener(kind: 'connect'|'disconnect', vendor_id:int, product_id:int) を登録する。

        WebSocket転送層(QtWebView)など、Signalを使わない配送先向け。フィルタ(どの
        オリジン/接続へ流すか)は登録側の責任。
        """
        if callable(listener) and listener not in self._hotplug_listeners:
            self._hotplug_listeners.append(listener)

    def remove_hotplug_listener(self, listener):
        try:
            self._hotplug_listeners.remove(listener)
        except ValueError:
            pass

    def _poll_hotplug(self):
        """1.5秒ごとに接続USBデバイス一覧を差分検出し、現在のオリジンに許可済みの
        デバイスについてのみ connect/disconnect をJSへ配送する(未許可オリジンへは
        デバイスの抜き挿し情報すら渡さない=フィンガープリンティング対策)。"""
        if self._hotplug_watcher is None:
            return
        try:
            connected, disconnected = self._hotplug_watcher.poll()
            if not connected and not disconnected:
                return
            events = ([("connect", v, p) for v, p in sorted(connected)] +
                      [("disconnect", v, p) for v, p in sorted(disconnected)])
            for listener in list(self._hotplug_listeners):
                for kind, vid, pid in events:
                    try:
                        listener(kind, vid, pid)
                    except Exception as e:
                        self._log("_poll_hotplug(listener)", e)
            if self._transport_kind != "webchannel":
                return
            # 🛡️ deviceConnected/deviceDisconnectedはQt Signalとしてページ内の全フレームへ
            #    ブロードキャストされる(フレーム単位に絞る仕組みは無い)ので、トップレベル
            #    ページの許可状況を基準にし、**VID/PIDだけ**を流す(0.0.6a: それまでは
            #    製品名・シリアル番号まで含む記述子を全フレームへ流していた)。許可済みの
            #    フレームだけが listDevices() で詳細を取得する。
            origin = self._top_level_origin()
            if not origin:
                return
            for kind, vid, pid in events:
                if not self._is_granted(origin, vid, pid):
                    continue
                try:
                    signal = self.deviceConnected if kind == "connect" else self.deviceDisconnected
                    signal.emit(_json_dumps({"vendorId": vid, "productId": pid}))
                except Exception as e:
                    self._log("_poll_hotplug(emit)", e)
        except Exception as e:
            self._log("_poll_hotplug", e)

    def _pyusb(self):
        """pyusbを遅延インポートし、未インストール環境でも他機能に影響を与えないようにする。
        🆕 v0.0.5a3: コンストラクタへ usb_backend=(usb_core, usb_util) が渡されていれば
        実pyusbのimport自体を行わずそちらを返す(pyside6_webusb.virtual参照)。"""
        if self._usb_backend_override is not None:
            return self._usb_backend_override
        import usb.core
        import usb.util
        return usb.core, usb.util

    # ==================== オリジン(サイト単位)権限管理 ====================
    # WebUSB本来の仕様では「どのサイトが許可されたか」をオリジン単位で厳密に区別する。
    # 旧実装はvendorId/productIdだけでゲートしており、任意のWebサイトがgetDevices()で
    # 接続中の全USBデバイスを確認なしで取得でき、openDevice()もチューザーダイアログを
    # 経由せず直接デバイスを掴めてしまっていた。以下はその是正。

    def _origin_from_url(self, qurl):
        """QUrlから 'scheme://host[:port]' 形式の正規化オリジン文字列を作る。
        実体は frame_origin.url_to_origin() (このbridge.py側とFrameOriginTracker側とで
        オリジン正規化ロジックが食い違わないよう、一箇所に集約してある)。"""
        return url_to_origin(qurl)

    def _current_origin(self, frame_token=""):
        """呼び出し元フレームの「現在表示中」のオリジンを取得する。
        JSからの自己申告originを信用するのではなく、Qt/Python側で独立に確認することで、
        ページ自身(=攻撃者が完全に制御できる側)による偽装を防ぐのが目的。

        🛡️ frame_tokenの扱いに関する重要な設計判断:
        self._frame_tracker が配線されている(=install()経由の実運用でsetRunsOnSubFrames
        が有効になっている)場合、メインフレームかどうかを問わず必ずトークン経由でしか
        解決しない。「トークンが空/不明ならメインフレーム扱いにフォールバックする」という
        判定は絶対に行わない -- それを許してしまうと、素のQWebChannelオブジェクトを直接
        叩く敵対的なサブフレームが、トークンを渡さない(空文字のまま呼ぶ)だけで
        トップレベルページに成りすませてしまい、0.0.2b0で修正した脆弱性がそのまま
        復活してしまう。
        self._frame_tracker が配線されていない場合(make_bridge()を使う既存の
        単体テストや、install()を使わない後方互換の利用)は、従来どおり
        page.url()を直接見る(この経路ではsetRunsOnSubFramesはFalseのままなので、
        サブフレームからの呼び出しはそもそも構造的にあり得ない)。"""
        if self._frame_tracker is not None:
            return self._frame_tracker.origin_for_token(frame_token)
        page = self.parent()
        if page is None or not hasattr(page, "url"):
            return None
        try:
            return self._origin_from_url(page.url())
        except Exception as e:
            self._log("_current_origin", e)
            return None

    def _get_open_device(self, handle_id, frame_token=""):
        """ハンドルからusb.core.Deviceを取り出す。ハンドルを開いた本人(オリジン)と
        現在のオリジンが一致しない場合はNoneを返す(サイトを跨いだハンドル乗っ取り防止)。"""
        info = self._open_devices.get(handle_id)
        if info is None:
            return None
        if info.get("origin") != self._current_origin(frame_token):
            return None
        return info.get("device")

    def _top_level_origin(self):
        """トップレベルページのオリジン。0.0.6a: top_level_url_provider(QtWebView等)を先に見る。"""
        provider = self._top_level_url_provider
        if provider is not None:
            try:
                value = provider()
                if isinstance(value, str):
                    from PySide6.QtCore import QUrl
                    value = QUrl(value)
                return self._origin_from_url(value)
            except Exception as e:
                self._log("_top_level_origin(provider)", e)
                return None
        page = self.parent()
        if page is None or not hasattr(page, "url"):
            return None
        try:
            return self._origin_from_url(page.url())
        except Exception as e:
            self._log("_top_level_origin", e)
            return None

    def set_top_level_url_provider(self, provider):
        """QtWebViewのようにpage.url()を持たない埋め込みビュー向け。provider() は現在の
        トップレベルURL(QUrlかstr)を返すcallable。"""
        self._top_level_url_provider = provider

    def notify_navigated(self):
        """ホストがトップレベルの遷移を検知したときに呼ぶ(オリジンが変わったら、
        旧オリジンが開いたままのデバイスハンドルを閉じる)。"""
        self._on_page_navigated()

    def _on_page_navigated(self, *_args):
        """別オリジンへ遷移した瞬間、開いていたUSBハンドルを破棄する。
        ★ current(遷移先のオリジン)がNone(=判定不能。about:blank等)の場合は、
        「安全にどのハンドルも維持できる根拠がない」とみなし、個別のorigin比較に
        頼らず全ハンドルを破棄する(念のための安全側強化。理論上は_grant()が
        falsyなoriginへの許可を発行しないためinfo["origin"]がNoneになることは
        無いはずだが、比較ロジックだけに依存しない形にしておく)。"""
        try:
            current = self._top_level_origin()
            if current is None:
                stale_ids = list(self._open_devices.keys())
            else:
                stale_ids = [hid for hid, info in self._open_devices.items() if info.get("origin") != current]
            for hid in stale_ids:
                info = self._open_devices.pop(hid, None)
                if info and info.get("device") is not None:
                    try:
                        _usb_core, usb_util = self._pyusb()
                        usb_util.dispose_resources(info["device"])
                    except Exception as e:
                        self._log("_on_page_navigated", e)
        except Exception as e:
            self._log("_on_page_navigated", e)

    def _known_device_settings(self):
        """設定を保存するQSettingsを取得する。browser_window経由で取得できない場合でも、
        コンストラクタで指定された(既定は"pyside6-webusb"/"WebUSBBridge")
        QSettings(organization, application)へフォールバックし、常に永続化できるようにする。"""
        try:
            if self.browser_window is not None and hasattr(self.browser_window, "settings"):
                s = self.browser_window.settings
                if s is not None:
                    return s
        except Exception as e:
            self._log("_known_device_settings", e)
        try:
            return QSettings(self._settings_organization, self._settings_application)
        except Exception as e:
            self._log("_known_device_settings(fallback)", e)
            return None

    def _load_granted_origins(self):
        """{origin: [{"vendorId":.., "productId":.., "grantedAt":..}, ...]} を読み込む"""
        s = self._known_device_settings()
        if s is None:
            return {}
        try:
            raw = s.value("webusb_granted_origins", "{}", type=str)
            data = json.loads(raw)
            return data if isinstance(data, dict) else {}
        except Exception as e:
            self._log("_load_granted_origins", e)
            return {}

    def _save_granted_origins(self, data):
        s = self._known_device_settings()
        if s is None:
            return
        try:
            s.setValue("webusb_granted_origins", _json_dumps(data))
        except Exception as e:
            self._log("_save_granted_origins", e)

    def _is_granted(self, origin, vendor_id, product_id):
        if not origin:
            return False
        grants = self._load_granted_origins().get(origin, [])
        return any(g.get("vendorId") == vendor_id and g.get("productId") == product_id for g in grants)

    def _grant(self, origin, vendor_id, product_id):
        if not origin:
            return
        data = self._load_granted_origins()
        grants = data.setdefault(origin, [])
        if not any(g.get("vendorId") == vendor_id and g.get("productId") == product_id for g in grants):
            grants.append({"vendorId": vendor_id, "productId": product_id, "grantedAt": time.time()})
            self._save_granted_origins(data)

    def _load_known_devices(self):
        """設定に保存済みの既知デバイス一覧（優先順位・接続履歴付き）を取得する"""
        s = self._known_device_settings()
        if s is None:
            return []
        try:
            raw = s.value("webusb_known_devices", "[]", type=str)
            data = json.loads(raw)
            return data if isinstance(data, list) else []
        except Exception as e:
            self._log("_load_known_devices", e)
            return []

    def _save_known_devices(self, devices_list):
        s = self._known_device_settings()
        if s is None:
            return
        try:
            s.setValue("webusb_known_devices", _json_dumps(devices_list))
        except Exception as e:
            self._log("_save_known_devices", e)

    def _record_device_usage(self, vendor_id, product_id, product_name, manufacturer_name):
        """接続したデバイスを既知一覧に記録し、最終接続時刻・接続回数を更新する（優先順位付けに使用）"""
        try:
            devices = self._load_known_devices()
            now = time.time()
            found = False
            for d in devices:
                if d.get("vendorId") == vendor_id and d.get("productId") == product_id:
                    d["lastConnected"] = now
                    d["connectCount"] = d.get("connectCount", 0) + 1
                    if product_name: d["productName"] = product_name
                    if manufacturer_name: d["manufacturerName"] = manufacturer_name
                    found = True
                    break
            if not found:
                devices.append({
                    "vendorId": vendor_id, "productId": product_id,
                    "productName": product_name, "manufacturerName": manufacturer_name,
                    "firstSeen": now, "lastConnected": now, "connectCount": 1,
                    "priority": len(devices),  # 新規追加分は末尾優先度
                })
            self._save_known_devices(devices)
        except Exception as e:
            self._log("_record_device_usage", e)  # 記録の失敗は致命的ではないため静かに無視（接続自体は継続させる）

    @Slot(result=str)
    def isAvailable(self):
        """pyusb / libusb が実際に使える状態か確認する。
        🔧 v0.0.4b2: F12(DevTools)デバッグ用の静的メタ情報も併せて返すよう拡張した。
        バージョン・Rustアクセラレーションの有無・転送サイズ上限値といった、
        オリジンやデバイスに一切紐付かない静的情報のみ(=どのページから見ても
        同じ内容であり、他オリジンの情報を一切開示しない)。既知デバイス一覧や
        許可済みオリジンのような、オリジン横断の機微情報は絶対にここに含めない
        こと(listKnownDevices等が@Slotを外された理由と同じ原則、このファイル内
        list_granted_origins直前のコメント参照)。"""
        try:
            usb_core, _usb_util = self._pyusb()
            usb_core.find()  # バックエンド疎通確認（デバイスの有無は問わない）
            return _json_dumps({
                "available": True,
                "bridgeVersion": __version__,
                "rustAccelerated": HAVE_RUST_ACCEL,
                "transferLimits": {
                    "chromeCompatibleWarnThreshold": CHROME_USB_TRANSFER_LENGTH_LIMIT,
                    "hostSafetyHardLimit": HOST_SAFETY_MAX_TRANSFER_LENGTH,
                    "controlTransferMaxLength": CONTROL_TRANSFER_MAX_LENGTH,
                },
                "platform": platform_summary(),
                "capabilities": capability_summary(),
                "transport": self._transport_kind,
            })
        except Exception as e:
            return _json_dumps({
                "available": False, "error": safe_error_str(e), "bridgeVersion": __version__,
                "platform": platform_summary(), "capabilities": capability_summary(),
                "transport": self._transport_kind,
            })

    @Slot(result=str)
    def getDiagnostics(self):
        """🆕 v0.0.6a: window.__pysideWebUSB.diagnose() の実体。ページへ渡して安全な範囲
        (パス・ユーザー名・例外の生テキストを含まない)の環境レポートをJSONで返す。"""
        try:
            report = {
                "bridgeVersion": __version__,
                "transport": self._transport_kind,
                "platform": platform_summary(),
                "capabilities": capability_summary(),
                "hints": setup_hints(),
                "customBackend": self._usb_backend_override is not None,
                "chooser": "custom" if self._chooser_override is not None else "qt-dialog",
                "hotplug": {"polling": self._hotplug_watcher is not None},
                "backendUsable": False,
            }
            try:
                usb_core, _usb_util = self._pyusb()
                usb_core.find()
                report["backendUsable"] = True
            except Exception as e:
                self._log("getDiagnostics(backend)", e)
            return _json_dumps(report)
        except Exception as e:
            self._log("getDiagnostics", e)
            return _json_dumps({"bridgeVersion": __version__, "error": "diagnostics unavailable"})

    @Slot(int, int, str, result=bool)
    def isGrantedToThisFrame(self, vendor_id, product_id, frame_token=""):
        """🛡️ security_audit No.5: このオリジン(=呼び出し元frame_tokenが指す
        フレーム自身)が(vendorId, productId)への許可を実際に持っているかだけを
        answerする、副作用の無い軽量な問い合わせ。listDevices()と違い
        usb_core.find(find_all=True)で現在の物理接続状態を見る必要が無いため、
        「今まさに切断されたデバイス」についても正しく判定できる
        (listDevices()は接続中のデバイスしか列挙しないため、切断イベントの
        検証に使うとdisconnectイベントを全て握りつぶしてしまう)。
        polyfill.py側は、Python発のdeviceConnected/deviceDisconnected
        シグナル(QWebChannelの仕組み上ページ内の全フレームへブロードキャスト
        される。_poll_hotplug()のコメント参照)を実際にページへdispatchする前に、
        これを使って「本当に自分自身のオリジンが許可されているデバイスか」を
        再検証する。ブロードキャスト自体はQt Signalの都合上フレーム単位に
        絞れないが、observableな挙動としては無関係なフレームに漏れないように
        できる。listDevices()と全く同じ_is_granted()判定を、例外時は安全側
        (False)に倒しつつ流用する。"""
        try:
            origin = self._current_origin(frame_token)
            if not origin:
                return False
            return bool(self._is_granted(origin, vendor_id, product_id))
        except Exception:
            return False

    @Slot(str, result=str)
    def listDevices(self, frame_token=""):
        """navigator.usb.getDevices() が呼ぶ。WebUSB本来の仕様どおり、
        「現在のオリジンがrequestDevice()で過去に許可したデバイス」だけを返す。
        旧実装は_is_granted()を一切参照せず接続中の全USBデバイスを無条件で返しており、
        任意のサイトがダイアログ無しでベンダーID/製品名等を収集できてしまっていた。
        frame_token: フレーム単位オリジン特定用(frame_origin.FrameOriginTracker)。
        install()経由の実運用では必須(空/不明なトークンは「オリジン不明」として
        安全側に倒れ、devices:[]を返す)。"""
        try:
            origin = self._current_origin(frame_token)
            if not origin:
                return _json_dumps({"devices": []})
            usb_core, usb_util = self._pyusb()
            devices = []
            for dev in usb_core.find(find_all=True):
                if not self._is_granted(origin, dev.idVendor, dev.idProduct):
                    continue
                # 🛡️ 既知のセキュリティキー等はオリジンへ許可済みであっても列挙自体を拒否する
                #    (多層防御。本来のブロックはclaimInterface時のインターフェースクラス
                #     チェックが主だが、デバイス単位でも念のため塞ぐ)
                if device_is_fully_blocked(dev):
                    continue
                try:
                    devices.append(build_device_descriptor(dev, usb_util, locale=self._locale))
                    continue
                except Exception as e:
                    self._log("listDevices(rich descriptor)", e)
                # リッチな記述子の構築に失敗した場合のみ簡易記述子へフォールバックする
                manufacturer = product = None
                try:
                    if dev.iManufacturer:
                        manufacturer = usb_util.get_string(dev, dev.iManufacturer)
                except Exception as e:
                    self._log("listDevices", e)
                try:
                    if dev.iProduct:
                        product = usb_util.get_string(dev, dev.iProduct)
                except Exception as e:
                    self._log("listDevices", e)
                devices.append({
                    "vendorId": dev.idVendor,
                    "productId": dev.idProduct,
                    "manufacturerName": manufacturer,
                    "productName": product,
                    "deviceClass": dev.bDeviceClass,
                })
            return _json_dumps({"devices": devices})
        except Exception as e:
            return _json_dumps({"devices": [], "error": safe_error_str(e)})

    def _enumerate_filtered_devices(self, usb_core, usb_util, filters, exclusion_filters):
        """列挙 + ブロックリスト除外 + filters/exclusionFiltersでの絞り込みを行い、
        チューザー表示用の軽量デバイス記述子のリストを返す。requestDeviceChooser()の
        初回一覧構築と、ダイアログのライブ更新(refresh_callback)の両方から使う
        共通ロジック。"""
        raw_devices = list(usb_core.find(find_all=True))
        devices_info = []
        for dev in raw_devices:
            # 🛡️ 既知のセキュリティキー等はチューザーダイアログの選択肢にすら出さない
            #    (Chromium実装と同様の挙動。ユーザーが誤って許可してしまう余地を無くす)
            if device_is_fully_blocked(dev):
                continue
            # 🛡️ WebUSB仕様どおり、options.filters/exclusionFiltersに一致しない
            #    デバイスはチューザーの候補から除外する。
            if not device_matches_any_usb_filter(dev, usb_util, filters, locale=self._locale):
                continue
            if exclusion_filters and device_matches_any_usb_filter(dev, usb_util, exclusion_filters, locale=self._locale):
                continue
            try:
                devices_info.append(build_device_descriptor(dev, usb_util, include_configurations=False, locale=self._locale))
                continue
            except Exception as e:
                self._log("_enumerate_filtered_devices(rich descriptor)", e)
            manufacturer = product = None
            try:
                if dev.iManufacturer: manufacturer = usb_util.get_string(dev, dev.iManufacturer)
                if dev.iProduct: product = usb_util.get_string(dev, dev.iProduct)
            except Exception as e:
                self._log("_enumerate_filtered_devices", e)
            devices_info.append({
                "vendorId": dev.idVendor, "productId": dev.idProduct,
                "manufacturerName": manufacturer, "productName": product,
                "deviceClass": dev.bDeviceClass,
            })

        # 既知デバイス（過去に接続実績あり）を優先順位/最終接続日時順に並べ替える
        try:
            known = self._load_known_devices()
            known_map = {(d.get("vendorId"), d.get("productId")): d for d in known}
            def _sort_key(dev):
                k = known_map.get((dev["vendorId"], dev["productId"]))
                if k is None:
                    return (1, 0, 0)  # 未知デバイスは後ろへ
                return (0, -(k.get("connectCount", 0)), -(k.get("lastConnected", 0)))
            devices_info.sort(key=_sort_key)
        except Exception as e:
            self._log("_enumerate_filtered_devices", e)  # 並べ替えに失敗しても一覧表示自体は継続する
        return devices_info

    _GESTURE_TOKEN_TTL_SECONDS = 5.0  # 実ブラウザのtransient activationの典型的な猶予に合わせた保守的な値
    _GESTURE_TOKEN_CACHE_CAP = 64     # 単一ページが妥当な理由で同時に持つ発行済みトークン数を大きく超える上限
    _MAX_OPEN_HANDLES_PER_ORIGIN = 64  # security_audit No.6: 正当なユースケースでも十分すぎるほど余裕を持たせた上限

    @Slot(result=str)
    def mintGestureToken(self):
        """polyfill.pyがnavigator.userActivation.isActiveを確認した直後に呼ぶ。
        短命・使い切りの不可予測トークンを発行し、requestDeviceChooser()への
        次の呼び出しがこの発行と対になっていることを検証できるようにする
        (see: __init__のself._gesture_tokensのコメント、およびNo.2の限界)。"""
        now = time.monotonic()
        # 失効済みトークンを掃除してから上限を適用する(古いものから捨てる)
        for tok in [t for t, minted_at in self._gesture_tokens.items() if now - minted_at > self._GESTURE_TOKEN_TTL_SECONDS]:
            self._gesture_tokens.pop(tok, None)
        while len(self._gesture_tokens) >= self._GESTURE_TOKEN_CACHE_CAP:
            oldest = min(self._gesture_tokens, key=self._gesture_tokens.get)
            self._gesture_tokens.pop(oldest, None)
        token = secrets.token_urlsafe(24)
        self._gesture_tokens[token] = now
        return token

    def _consume_gesture_token(self, token):
        """有効(未失効・未使用)なトークンなら消費してTrueを返す。使い切りに
        することで、同じトークンを使い回した複数回のrequestDeviceChooser()呼び出しを防ぐ。"""
        if not token or not isinstance(token, str):
            return False
        minted_at = self._gesture_tokens.pop(token, None)
        if minted_at is None:
            return False
        return (time.monotonic() - minted_at) <= self._GESTURE_TOKEN_TTL_SECONDS

    @Slot(str, str, str, result=str)
    def requestDeviceChooser(self, options_json, frame_token="", gesture_token=""):
        """navigator.usb.requestDevice() 相当。実処理は _request_device_chooser_impl()
        に委譲し、ここでは再入防止ガードだけを担う。
        🛡️ dlg.exec()(_request_device_chooser_impl内)はネストしたQtイベントループを
        回すため、その最中に同じWebUSBBridgeインスタンスへ対してもう一度
        requestDeviceChooser()が呼ばれる(ページの連打や、QWebChannelメッセージが
        ネストループ中に処理される等)と、チューザーダイアログが二重に開いてしまう
        恐れがある。try/finallyで確実にフラグを解除することで、内部実装側の
        どの return/例外経路を通っても再入状態が残留しないようにしている。
        frame_token: フレーム単位オリジン特定用。
        🛡️ security_audit No.2: gesture_token — mintGestureToken()が発行した
        トークンをここで検証・消費する。欠落・失効・使い切り済みならダイアログを
        一切構築せずSecurityErrorで拒否する(=素のQWebChannel直叩きで
        gesture_tokenを渡す方法を知らない/持たない敵対的スクリプトは、
        ここで必ず弾かれる)。mintGestureToken自体の限界はそのdocstring/
        __init__のコメントを参照。
        チェック順序: 再入防止ガード(_chooser_active)を先に見る — 既にダイアログが
        開いている場合はInvalidStateErrorの方がgesture_token不備によるSecurityError
        よりも呼び出し元にとって直接的で分かりやすい理由になるため。"""
        if self._chooser_active:
            return _json_dumps({
                "cancelled": True,
                "error": invalid_state_error("a device chooser is already open for this page"),
            })
        if not self._consume_gesture_token(gesture_token):
            return _json_dumps({
                "cancelled": True,
                "error": security_error("Must be handling a user gesture to call navigator.usb.requestDevice()."),
            })
        self._chooser_active = True
        try:
            return self._request_device_chooser_impl(options_json, frame_token)
        finally:
            self._chooser_active = False

    def _resolve_chooser_strings(self):
        """🆕 v0.0.5b3: __init__の locale=/chooser_strings= からデバイスチューザー
        ダイアログ用の文言辞書を組み立てる。requestDeviceChooser()が実際にダイアログを
        開く直前に毎回呼ぶ(コンストラクタ時点で1回だけ解決してキャッシュしない——
        後述のとおりchooser_stringsは実行時に差し替えられても良い設計にしてあるため)。

        解決順序:
          1. self._locale (省略時は"ja"。i18n.resolve_locale()参照) から、まず
             その言語の既定文言一式を取る。
          2. self._chooser_strings_override が dict なら、そこだけ部分上書きする
             (例: locale="ja"の既定文言のうち trust_reminder だけ差し替える、
             といった使い方ができる)。
          3. self._chooser_strings_override が文字列("en"/"ja"/"zh"/"auto")なら、
             1.の結果を無視してその言語の既定文言一式に丸ごと切り替える
             (localeとは別に、chooser_strings側だけでも言語切り替えができる
             ショートカット。例えば「アプリ全体はauto検出のlocaleだが、
             チューザーだけは常に英語で見せたい」といった需要に対応する)。
          4. どちらも指定が無ければ1.の結果をそのまま返す。
        """
        strings = chooser_strings_for(self._locale)
        override = self._chooser_strings_override
        if isinstance(override, dict):
            strings.update(override)
        elif isinstance(override, str):
            strings = chooser_strings_for(resolve_locale(override))
        return strings

    def _resolve_chooser_parent_window(self):
        """デバイスチューザーダイアログの親ウィンドウを解決する。

        🛡️ バグ修正(v0.0.4, ユーザー報告): 旧実装はQApplication.activeWindow()
        だけで親を決めていた。これはOS/ウィンドウマネージャが「今アクティブな
        トップレベルウィンドウ」をQtへどう伝えるかに依存しており、
        QWebEngineView経由のJS呼び出し(=ネストしたイベントループ経由で非同期に
        着地するコールバック)ではフォーカス状態が正しく伝播せずNoneになることが
        ある(実際、コンストラクタは__init__の時点でbrowser_windowを受け取り
        self.browser_windowへ保存していたにもかかわらず、ここでは一切参照して
        いなかった)。Noneのまま渡すと、ダイアログは親を持たない独立ウィンドウ
        として開かれ、ブラウザ本体の裏に隠れる/別ワークスペースに開く/
        タスクバー上でブラウザと無関係に見える等の理由で、実際には表示されて
        いても「画面が出ない」ように見えることがある。

        優先順位:
          1. self.browser_window が実際にQWidgetならそれを使う。ホストアプリが
             __init__/install()で明示的に渡した「今のブラウザウィンドウ」への
             確実な参照であり、OSのフォーカス状態に左右されない。
             (browser_windowは元々「.settingsを持つオブジェクトなら何でもよい」
             というダックタイピングで文書化されており、必ずしもQWidgetとは
             限らないため、isinstanceで確認できた場合だけ親として使う。)
          2. QApplication.activeWindow() -- 多くの環境では正しく動くフォールバック
             (browser_window省略時のため残してある)。
          3. 可視なトップレベルウィジェットを1つ拾う(1.も2.も得られない場合の保険)。
        どれも得られなければNoneを返す(モーダル性そのものはWebUsbDeviceChooserDialog
        側のsetModal(True)により親の有無と関係なく保たれる)。"""
        try:
            from PySide6.QtWidgets import QApplication, QWidget
        except Exception as e:
            self._log("_resolve_chooser_parent_window(import)", e)
            return None

        bw = self.browser_window
        if isinstance(bw, QWidget):
            return bw

        try:
            active = QApplication.activeWindow()
            if active is not None:
                return active
        except Exception as e:
            self._log("_resolve_chooser_parent_window(activeWindow)", e)

        try:
            for w in QApplication.topLevelWidgets():
                if isinstance(w, QWidget) and w.isVisible() and w.isWindow():
                    return w
        except Exception as e:
            self._log("_resolve_chooser_parent_window(topLevelWidgets)", e)

        return None

    def _run_chooser(self, devices_info, origin, refresh_callback):
        """デバイス選択UIを実行し、選ばれたデバイス情報(dict)かNoneを返す。

        🆕 v0.0.6a: install(chooser=...)/install_webview(chooser=...) で差し替え可能。
        差し替えcallableは chooser(devices_info, origin, strings) -> dict | None。
        戻り値は必ず列挙済み候補のどれか(vendorId/productId/serialNumberが一致)で
        なければならず、候補に無いデバイスを返した場合は無視する(=バグのある/悪意の
        あるチューザーが、フィルタに合わない任意のデバイスへ許可を与えられない)。
        """
        override = self._chooser_override
        if override is not None:
            picked = override(list(devices_info), origin, self._resolve_chooser_strings())
            if picked is None:
                return None
            for cand in devices_info:
                if (cand.get("vendorId") == picked.get("vendorId")
                        and cand.get("productId") == picked.get("productId")
                        and (cand.get("serialNumber") or None) == (picked.get("serialNumber") or None)):
                    return cand
            self._log("_run_chooser", ValueError("custom chooser returned a device that was not offered"))
            return None
        from PySide6.QtWidgets import QApplication
        if not isinstance(QCoreApplication.instance(), QApplication):
            # QGuiApplication(=QML/QtWebViewアプリ)ではQtWidgetsのダイアログを作れない
            # (QApplicationが無いままQWidgetを作るとプロセスごと異常終了する)。
            raise RuntimeError("no QApplication: pass chooser=... (see pyside6_webusb.QmlDeviceChooser)")
        parent = self._resolve_chooser_parent_window()
        dlg = WebUsbDeviceChooserDialog(
            devices_info, parent,
            strings=self._resolve_chooser_strings(),
            origin=origin,
            refresh_callback=refresh_callback,
        )
        # parentがあってもプラットフォームによっては前面に来ないことがあるので明示的に前面へ。
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()
        result = dlg.exec()
        accepted = (result == WebUsbDeviceChooserDialog.DialogCode.Accepted)
        return dlg.selected_device if accepted else None

    def _request_device_chooser_impl(self, options_json, frame_token=""):
        """navigator.usb.requestDevice() の実処理本体。実デバイス選択ダイアログを表示し、
        ユーザーが明示的に選んだ場合のみデバイス情報を返す（WebUSB本来のセキュリティ設計を踏襲）。
        ★ メソッド全体を try/except で包み、ダイアログ表示中の例外でアプリが落ちないようにしている。
        ★ options.filters/exclusionFiltersによる絞り込み(WebUSB仕様
        「requestDevice(options)」のenumerate〜絞り込み手順を再現)。filters自体の
        必須チェック・各フィルタの妥当性検証("is a valid filter")はJS側
        (WEBUSB_POLYFILL_JS)で完了させた上でここへ渡す設計なので、ここでは
        構造的に妥当なfilters/exclusionFiltersが来る前提で一致判定だけを行う。
        filtersが空リストの場合は仕様どおり「一致するデバイスなし」となる。
        ★ Chromeの実際のチューザーを参考に、(1)要求元オリジンを明示、
        (2)ダイアログを開いたままの接続/切断でライブ更新、を行う。
        ★ @Slotをあえて付けていない: QWebChannel/JSから直接叩けるのは
        requestDeviceChooser()(再入防止ガード込み)だけにするため。"""
        try:
            origin = self._current_origin(frame_token)
            if len(options_json) > 65536:
                return _json_dumps({"cancelled": True, "error": type_error("options payload too large")})
            try:
                options = json.loads(options_json) if options_json else {}
                if not isinstance(options, dict):
                    return _json_dumps({"cancelled": True, "error": type_error("options must be a JSON object")})
            except Exception as e:
                return _json_dumps({"cancelled": True, "error": type_error(f"Malformed options JSON: {safe_error_str(e)}")})
            filters = options.get("filters")
            exclusion_filters = options.get("exclusionFilters")
            filters = filters if isinstance(filters, list) else []
            exclusion_filters = exclusion_filters if isinstance(exclusion_filters, list) else []

            # 🛡️ security_audit No.2b: filters/exclusionFiltersの構造妥当性
            # ("A USBDeviceFilter filter is valid")はこれまでpolyfill.pyの
            # JS側だけで検証しており、Python側はここまで「構造的に妥当な
            # ものだけが渡ってくる」という前提に完全に依存していた
            # (このメソッド自身のdocstringが明記していた前提)。素の
            # QWebChannel接続からrequestDeviceChooserを直接叩けば、この
            # 前提はJS側のチェックごと丸ごと素通りする。実ブラウザは無効な
            # filterに対してTypeErrorで(チューザーを開く前に)同期的に拒否
            # するため、ここでも同じタイミングで同じ強さの拒否を行う
            # (中途半端に「一致件数を絞る」のではなく、要求そのものを拒否する)。
            invalid_filters = [f for f in (filters + exclusion_filters) if not is_valid_usb_device_filter(f)]
            if invalid_filters:
                return _json_dumps({
                    "cancelled": True,
                    "error": type_error(
                        "Failed to execute 'requestDevice' on 'USB': the provided filter value is invalid."
                    ),
                })

            # 🛡️ security_audit No.10(v0.0.6a): 呼び出し元フレームのオリジンを特定できない
            #    (about:blank / data: / file: / サンドボックス化されたiframe / 未知のトークン)
            #    場合は、チューザーを開かずにSecurityErrorで拒否する。これまではダイアログが
            #    開き(オリジン表示なし)、選ばれたデバイスの完全な記述子(シリアル番号・
            #    全コンフィグレーション)が、許可(_grant)が記録されないまま呼び出し元へ
            #    返っていた。
            if not origin:
                return _json_dumps({
                    "cancelled": True,
                    "error": security_error("The calling frame has an opaque or unknown origin and cannot request a USB device."),
                })
            try:
                usb_core, usb_util = self._pyusb()
            except Exception as e:
                return _json_dumps({"cancelled": True, "error": safe_error_str(e)})

            try:
                devices_info = self._enumerate_filtered_devices(usb_core, usb_util, filters, exclusion_filters)
            except Exception as e:
                return _json_dumps({"cancelled": True, "error": safe_error_str(e)})

            def _refresh():
                # 🛡️ ダイアログが開いている間、新しく挿された/抜かれたデバイスを
                #    反映する(Chromeのチューザーと同じ挙動)。再度pyusbから
                #    取り直す必要があるため、ここでも_pyusb()を呼び直す。
                u_core, u_util = self._pyusb()
                return self._enumerate_filtered_devices(u_core, u_util, filters, exclusion_filters)

            try:
                selected = self._run_chooser(devices_info, origin, _refresh)
            except Exception as e:
                self._log("requestDeviceChooser(chooser)", e)
                return _json_dumps({"cancelled": True, "error": "Dialog error"})

            if selected is not None:
                try:
                    self._record_device_usage(
                        selected.get("vendorId"), selected.get("productId"),
                        selected.get("productName"), selected.get("manufacturerName"))
                except Exception as e:
                    self._log("requestDeviceChooser", e)
                # ユーザーがダイアログで明示的に選んだ場合のみ、このオリジンに対する
                # 恒久的な許可を記録する(listDevices/openDeviceはこれを介してのみ許可を判定する)。
                try:
                    self._grant(origin, selected.get("vendorId"), selected.get("productId"))
                except Exception as e:
                    self._log("requestDeviceChooser", e)
                # 🛡️ チューザー一覧はパフォーマンスのため軽量記述子(configurations無し)で
                #    構築しているが、requestDevice()がJSへ返す「選ばれた1台」は
                #    getDevices()と同じリッチな記述子でなければならない。仕様6節の
                #    使用例が示すとおり、requestDevice()の戻り値へ直接
                #    .open()→.selectConfiguration()→.claimInterface() を呼ぶのが
                #    標準的な使い方であり、configurationsが空だとこの一連の流れが
                #    機能しない(旧実装はここが軽量記述子のまま返ってしまっていた)。
                rich_selected = selected
                try:
                    real_dev = _find_usb_device(usb_core, usb_util, selected.get("vendorId"), selected.get("productId"), selected.get("serialNumber"))
                    if real_dev is not None:
                        rich_selected = build_device_descriptor(real_dev, usb_util, include_configurations=True, locale=self._locale)
                except Exception as e:
                    self._log("requestDeviceChooser(rich rebuild)", e)
                return _json_dumps({"cancelled": False, "device": rich_selected})
            return _json_dumps({"cancelled": True})
        except Exception as e:
            # 最外殻の保険: ここまでの個別try/exceptで拾いきれない想定外の例外も必ず捕捉する
            return _json_dumps({"cancelled": True, "error": f"Unexpected error: {e}"})

    @Slot(int, int, str, result=str)
    @Slot(int, int, str, str, result=str)
    def openDevice(self, vendor_id, product_id, frame_token="", serial_number=""):
        """requestDeviceChooser()で許可されたオリジンだけがデバイスを開けるようにする。
        旧実装はvendorId/productIdさえ知っていれば任意のサイトが直接開けてしまっていた
        (チューザーダイアログを経由しないバイパス経路)。ここで許可をゲートする。
        frame_token: フレーム単位オリジン特定用。ここで確定したオリジンが
        _open_devices[handle_id]["origin"] として記録され、以降そのハンドルを使う
        全ての操作(_get_open_device経由)の認証基準になる。
        🛡️ security_audit No.6: 1オリジンが同時に保持できるハンドル数に上限
        (_MAX_OPEN_HANDLES_PER_ORIGIN)を設ける。旧実装はこれが無制限で、
        たった1台のデバイスへの正規の許可さえあれば、closeDevice()を挟まず
        device.open()をループで呼び続けるだけの、素のQWebChannel直叩きすら
        不要なごく普通のJSコードで、_open_devices(とその中のpyusb Deviceへの
        参照)を無制限に増やし続けられた。WebUSBBridgeはホストアプリ本体の
        プロセス内で動くため、これは表示中のタブのメモリではなくホスト
        アプリケーション本体のメモリを消費する(=通常のレンダラプロセス分離や
        タブ単位のメモリ上限では守られない)。
        方式はエラーでの拒否ではなくLRU的な自動退去: 上限に達している状態で
        新規にopenする場合、そのオリジンが持つ最も古いハンドルを1つ
        (実機のリソースごと)dispose_resources()で解放してから新しいハンドルを
        発行する。これによりopenDevice()自体は(通常のオープン処理が成功する限り)
        常に成功を返し続けつつ、_open_devices のオリジンあたりの総数は
        上限で頭打ちになる。退去させられた古いハンドルは以後
        _get_open_device()から見えなくなり、それを使った操作は他の閉じた
        ハンドルと同じ"Invalid device handle"として安全に失敗する。"""
        try:
            origin = self._current_origin(frame_token)
            if not self._is_granted(origin, vendor_id, product_id):
                return _json_dumps({"success": False, "error": "Permission denied: this origin has not been granted access to this device"})
            if is_blocklisted_device(vendor_id, product_id):
                return _json_dumps({"success": False, "error": security_error("this device is on the protected security-key blocklist and cannot be accessed via WebUSB")})
            open_count_for_origin = sum(1 for info in self._open_devices.values() if info.get("origin") == origin)
            if open_count_for_origin >= self._MAX_OPEN_HANDLES_PER_ORIGIN:
                # 挿入順(Python dictは3.7+で挿入順を保持する)で最初に見つかる
                # 同一オリジンのエントリが、そのオリジンにとって最も古いハンドル。
                oldest_handle_id = next(
                    hid for hid, info in self._open_devices.items() if info.get("origin") == origin
                )
                evicted = self._open_devices.pop(oldest_handle_id, None)
                if evicted is not None and evicted.get("device") is not None:
                    try:
                        _usb_core, usb_util = self._pyusb()
                        usb_util.dispose_resources(evicted["device"])
                    except Exception as e:
                        self._log("openDevice(LRU eviction)", e)
            usb_core, usb_util = self._pyusb()
            dev = _find_usb_device(usb_core, usb_util, vendor_id, product_id, serial_number or None)
            if dev is None:
                # 🐛 バグ修正(v0.0.5a3): 実仕様のUSBDevice.open()は「このデバイスが
                # もうシステムに接続されていない」場合をNotFoundErrorと定めている
                # (wicg.github.io/webusb §USBDevice.open())。旧実装はプレフィックス無しの
                # 生文字列を返しており、polyfill.pyのthrowFromResult()がどの
                # KNOWN_ERROR_PREFIXESにも一致せずデフォルトのNetworkErrorへ
                # フォールバックしてしまっていた(=許可済みだが抜かれた/未接続の
                # デバイスをopen()した際、DOMExceptionの.nameが仕様と異なっていた)。
                return _json_dumps({"success": False, "error": not_found_error("device not found")})
            handle_id = self._next_handle
            self._next_handle += 1
            self._open_devices[handle_id] = {"device": dev, "origin": origin, "claimed_interfaces": set()}
            return _json_dumps({"success": True, "handle": handle_id})
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    @Slot(int, str, result=str)
    def closeDevice(self, handle_id, frame_token=""):
        """🆕 v0.0.5a0: v0.0.4bのCHANGELOGで「既知の限界、スコープ外」として
        明記されていたギャップをここで解消する。bulkTransferIn/Outの
        チャンク分割(_busy_handles)はprocessEvents()を挟むため、その合間に
        同じhandleへ向けたQWebChannel呼び出しが再入する余地がある —
        transferIn/Out自身は再入をhandle単位で検出して安全に拒否する
        ガードを最初から持っていたが、closeDeviceだけはこのチェックを
        持たず、「チャンク転送の途中でたまたま同じhandleに対して
        closeDeviceが割り込む」と、転送ループの足元でdeviceがdispose
        されてしまいうる状態のまま残っていた(実害は次のサブチャンクで
        例外→通常のexceptハンドラがNetworkError相当として捕捉するだけで、
        クラッシュや状態破壊はしないが、成功するはずの転送が失敗する)。
        bulkTransferIn/Outと全く同じ`_busy_handles`集合を見て、転送中の
        handleへのcloseDeviceはInvalidStateErrorで拒否するようにし、
        「転送を安全に完了させてから閉じる」という順序をPython側で保証する。
        `test_closeDevice_rejects_close_while_handle_is_mid_chunked_transfer`
        が実際のprocessEvents()再入から検証する。
        🛡️ security_audit No.4: このクラスのdocstringは「全てのSlotは常に
        有効なJSON文字列を返し、Python例外をJSに漏らさない」ことを謳っているが、
        このメソッドは無効ハンドル時に`return`(=None)、さらに成功時も含めて
        どの経路でも明示的なreturn文が無く、実際には常にNoneを返していた
        (handle_idが無効な場合に限らない、より広範な不具合だった)。
        JS側で`JSON.parse(result)`する呼び出し元(polyfill.py)にとって、
        Noneは`null`/`undefined`として届き`JSON.parse()`が例外を投げる。
        他の全Slotと同じ形の戻り値に統一する。"""
        try:
            # 別オリジンのハンドルは「存在しない」ものとして扱う(_get_open_deviceがオリジン照合する)
            if self._get_open_device(handle_id, frame_token) is None:
                return _json_dumps({"success": False, "error": "Invalid device handle"})
            if handle_id in self._busy_handles:
                return _json_dumps({
                    "success": False,
                    "error": invalid_state_error(
                        f"handle {handle_id} has a bulk transfer in progress and cannot be "
                        f"closed until it completes"
                    ),
                })
            info = self._open_devices.pop(handle_id, None)
            dev = info.get("device") if info else None
            if dev is not None:
                try:
                    _usb_core, usb_util = self._pyusb()
                    usb_util.dispose_resources(dev)
                except Exception as e:
                    self._log("closeDevice", e)
            return _json_dumps({"success": True})
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    @Slot(int, int, str, result=str)
    def claimInterface(self, handle_id, interface_number, frame_token=""):
        """🛡️ WebUSB仕様が定める「保護対象インターフェースクラス」
        (Audio/HID/Mass Storage/Hub/Smart Card/Video/Audio-Video/Wireless Controller)は
        ここで一律拒否する。旧実装はインターフェースクラスを一切見ておらず、
        オリジンへの許可さえあればセキュリティキーやキーボードのHIDインターフェースにも
        生アクセスできてしまっていた(WebHID等、別の専用APIが本来担うべき領域)。
        🛡️ 実Chrome(usb_device.ccのUSBDevice::claimInterface()を実際に取得して確認)
        は、これより先にEnsureDeviceConfigured()相当のチェック(configurationが
        選択されていること)を行う。これが無いと、configuration未選択のまま
        claimInterface()が呼ばれた場合に「保護対象クラス」という誤った理由の
        エラーになってしまっていた(interface_class_for()がget_active_configuration()
        失敗時にNoneを返し、is_protected_interface_class(None)がTrueになるため、
        機能的には拒否されていたが理由の表示が不正確だった)。
        🛡️ security_audit No.1: interface_class_for()には明示的に
        alternate_setting=0 を渡す — claim直後のinterfaceは(まだ
        selectAlternateInterface()が一度も呼ばれていない限り)常にUSB仕様上
        alternate setting 0にあるため、判定はその具体的なalternate setting
        だけを見て行う(alternate_setting未指定時の保守的フォールバックだと、
        「無害なalt 0だが、別のalt設定が保護対象クラスを持つ」デバイスまで
        claim自体を拒否してしまい、実害のない構成まで過剰に締め出すことになる
        — alt 0以外への実際の防御はselectAlternateInterface()自身が切替先
        alternateのクラスを検証することで行う(v0.0.5a3で追加、詳細はそちらの
        docstring及びVULNERABILITY_REPORT.md No.1参照)。claim成功時にはそのalternate
        settingの記録(interface_alt_settings)も0で初期化し、
        selectAlternateInterface()が呼ばれるまでこの前提を維持する。
        🐛 バグ修正(v0.0.5a3、WebUSB仕様の該当アルゴリズムを実際に取得して確認):
        - 既にclaim済みのinterfaceへの再度のclaimInterface()は、仕様上は実機操作も
          保護対象クラス判定も行わない単純な成功のno-op。旧実装はこの分岐が無く、
          再claimのたびにinterface_alt_settingsを無条件に0へ書き戻していたため、
          「selectAlternateInterface()で正当に別のalternateへ切り替えた後、同じ
          interfaceをもう一度claimInterface()した」だけで、実機は元のalternateの
          ままなのに追跡側だけ0へ巻き戻る状態不整合が起きていた。
        - 指定interface_numberがそもそも存在しない場合は仕様上NotFoundError。
          旧実装はこの区別をせず、interface_class_for()がNoneを返す→
          is_protected_interface_class(None)がTrue(安全側フォールバック)経由で
          誤ってSecurityError「interface X is class 'Unknown'」を返していた。"""
        try:
            dev = self._get_open_device(handle_id, frame_token)
            if dev is None:
                return _json_dumps({"success": False, "error": "Invalid device handle"})
            try:
                dev.get_active_configuration()
            except Exception:
                return _json_dumps({
                    "success": False,
                    "error": invalid_state_error("the device must have a configuration selected"),
                })

            info = self._open_devices.get(handle_id)
            if info is not None and interface_number in info.get("claimed_interfaces", set()):
                # 仕様どおりの単純な成功no-op。実機操作・保護対象クラス判定・
                # interface_alt_settingsのリセットのいずれも行わない。
                return _json_dumps({"success": True})

            if interface_class_for(dev, interface_number, alternate_setting=None) is None:
                return _json_dumps({
                    "success": False,
                    "error": not_found_error(f"interface {interface_number} does not exist on this device"),
                })

            iface_class = interface_class_for(dev, interface_number, alternate_setting=0)
            if is_protected_interface_class(iface_class):
                name = protected_class_name(iface_class)
                return _json_dumps({
                    "success": False,
                    "error": security_error(
                        f"interface {interface_number} is class '{name}', "
                        f"which is a protected interface class and cannot be claimed via WebUSB"
                    ),
                })

            _usb_core, usb_util = self._pyusb()
            try:
                if dev.is_kernel_driver_active(interface_number):
                    dev.detach_kernel_driver(interface_number)
            except Exception as e:
                self._log("claimInterface", e)  # OSによっては未対応/不要な場合がある
            usb_util.claim_interface(dev, interface_number)
            if info is not None:
                info.setdefault("claimed_interfaces", set()).add(interface_number)
                info.setdefault("interface_alt_settings", {})[interface_number] = 0
            return _json_dumps({"success": True})
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    @Slot(int, int, str, result=str)
    def releaseInterface(self, handle_id, interface_number, frame_token=""):
        """旧実装はJS側のreleaseInterface()がno-op(Promise.resolve()するだけ)で
        Python側に一切届いておらず、一度claimしたインターフェースは
        デバイスを閉じるまで解放されなかった。
        🛡️ claimInterfaceと同様、実Chromeが要求するEnsureDeviceConfigured()相当の
        チェック(configurationが選択されていること)も行う。
        🐛 バグ修正(v0.0.5a3、WebUSB仕様の該当アルゴリズムを実際に取得して確認):
        - claimしていないinterfaceへのreleaseInterface()は、仕様上は実機操作を
          一切行わない成功のno-op。旧実装はこの分岐が無く、claim済みかどうかに
          関わらず常にusb_util.release_interface()を実機へ呼んでいたため、
          未claimのinterfaceに対して呼ぶと(バックエンド次第で)libusb側の
          エラーを誘発し、本来仕様上は常に成功するはずの呼び出しが不定形の
          エラー(接頭辞規約に沿わないためNetworkError扱い)になり得ていた。
        - 指定interface_numberがそもそも存在しない場合は仕様上NotFoundError。"""
        try:
            dev = self._get_open_device(handle_id, frame_token)
            if dev is None:
                return _json_dumps({"success": False, "error": "Invalid device handle"})
            try:
                dev.get_active_configuration()
            except Exception:
                return _json_dumps({
                    "success": False,
                    "error": invalid_state_error("the device must have a configuration selected"),
                })
            info = self._open_devices.get(handle_id)
            if info is None or interface_number not in info.get("claimed_interfaces", set()):
                if interface_class_for(dev, interface_number, alternate_setting=None) is None:
                    return _json_dumps({
                        "success": False,
                        "error": not_found_error(f"interface {interface_number} does not exist on this device"),
                    })
                # 仕様どおりの単純な成功no-op(実機操作は行わない)。
                return _json_dumps({"success": True})
            _usb_core, usb_util = self._pyusb()
            usb_util.release_interface(dev, interface_number)
            info.get("claimed_interfaces", set()).discard(interface_number)
            info.get("interface_alt_settings", {}).pop(interface_number, None)
            return _json_dumps({"success": True})
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    @Slot(int, int, str, result=str)
    def selectConfiguration(self, handle_id, configuration_value, frame_token=""):
        """旧実装はJS側のselectConfiguration()がno-opで、複数コンフィグレーションを
        持つデバイスでは常に(pyusbが自動選択した)最初のコンフィグレーションしか
        使えなかった。
        🛡️ バグ修正(v0.0.4): 仕様(USBDevice.selectConfiguration())は成功時に
        [[claimedInterface]]を全てfalseへリセットすると定めている
        (configurationが変われば、そもそもインターフェース番号の並びごと
        別物になりうるため)。旧実装はdev.set_configuration()を呼ぶだけで
        claimed_interfacesを一切リセットしていなかった。この場合、
        古いconfiguration下でclaimしていたインターフェース番号が新しい
        configuration下でも「claim済み」として扱われ続け、実際にはclaimして
        いないインターフェースに対してselectAlternateInterface()やbulk/
        isochronous転送が誤って許可されてしまう状態追跡バグだった。"""
        try:
            dev = self._get_open_device(handle_id, frame_token)
            if dev is None:
                return _json_dumps({"success": False, "error": "Invalid device handle"})
            dev.set_configuration(configuration_value)
            info = self._open_devices.get(handle_id)
            if info is not None:
                info["claimed_interfaces"] = set()
                info["interface_alt_settings"] = {}
            return _json_dumps({"success": True})
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    @Slot(int, int, int, str, result=str)
    def selectAlternateInterface(self, handle_id, interface_number, alternate_setting, frame_token=""):
        """USBInterface.selectAlternateInterface() 相当。pyusbの
        Device.set_interface_altsetting()へ実配線する(調査の結果、pyusb 1.x系の
        公開APIとして存在することを確認済み)。旧実装はJS側で常にNotSupportedErrorを
        返すだけのスタブだった。
        🛡️ 実Chrome(usb_device.ccのUSBDevice::selectAlternateInterface()を実際に
        取得して確認)は、これを呼ぶ前に必ずEnsureInterfaceClaimed()相当のチェックを
        行い、対象interfaceがclaim済みでなければInvalidStateErrorで拒否する。
        旧実装はこの確認が完全に欠落しており、claimInterface()を一度も呼ばずに
        (=保護対象クラスの拒否を経由せずに)任意のインターフェース番号の
        alternate settingを変更できてしまっていた。
        🛡️ セキュリティ修正(v0.0.5a3、VULNERABILITY_REPORT.md No.1の残存部分):
        claimInterface()はalternate setting 0のクラスだけを見て許可するため、
        「alternate 0は無害なvendor-specificクラス、alternate 1は保護対象クラス
        (HID等)」という複合デバイスをclaimすること自体は許可される
        (claimInterfaceのdocstring参照——意図的にそうなっている)。旧実装はこの
        selectAlternateInterface()自体には保護対象クラスの検証が一切無かったため、
        一度そのようなinterfaceをclaimしてしまえば、selectAlternateInterface()を
        呼ぶだけで保護対象クラス側のalternateへ実際に切り替えられてしまい
        (_endpoint_available_or_error()は「今まさに選択されているalternate」の
        endpointを正しく探し出す設計になっているため、切替後はそのendpointへの
        bulk/interrupt転送も普通に成功してしまう)、claimInterface()による
        入り口での防御が実質的に迂回できてしまっていた。切替先alternateの
        クラスをここでも検証することで閉じる(★の「(稀だが)想定していない」と
        していた変則的デバイスへの対応が、この修正そのものにあたる)。"""
        try:
            dev = self._get_open_device(handle_id, frame_token)
            if dev is None:
                return _json_dumps({"success": False, "error": "Invalid device handle"})
            info = self._open_devices.get(handle_id) or {}
            claimed = info.get("claimed_interfaces", set())
            if interface_number not in claimed:
                return _json_dumps({
                    "success": False,
                    "error": invalid_state_error("the specified interface has not been claimed"),
                })
            # 🐛 バグ修正(v0.0.5a3): 実仕様は切替先alternate_settingが存在しない
            # 場合をNotFoundErrorと定めている。旧実装はこの検証をpyusb/libusbへの
            # 生呼び出し任せにしており(不明なalternateを渡した際の挙動は
            # バックエンド依存で、接頭辞規約に沿わないエラーになり得ていた)、
            # ここで事前に構造的に検証する。
            target_class = interface_class_for(dev, interface_number, alternate_setting=alternate_setting)
            if target_class is None:
                return _json_dumps({
                    "success": False,
                    "error": not_found_error(
                        f"interface {interface_number} has no alternate setting {alternate_setting}"
                    ),
                })
            if is_protected_interface_class(target_class):
                name = protected_class_name(target_class)
                return _json_dumps({
                    "success": False,
                    "error": security_error(
                        f"interface {interface_number} alternate setting {alternate_setting} is class "
                        f"'{name}', which is a protected interface class and cannot be selected via WebUSB"
                    ),
                })
            dev.set_interface_altsetting(interface=interface_number, alternate_setting=alternate_setting)
            # 🛡️ security_audit No.1: _endpoint_available_or_error()が
            # 「claim済みinterfaceの、今まさに選択されているalternate setting」を
            # 正しく参照できるよう、実際に切り替えが成功した後にここで記録する。
            info.setdefault("interface_alt_settings", {})[interface_number] = alternate_setting
            return _json_dumps({"success": True})
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    @Slot(int, str, result=str)
    def resetDevice(self, handle_id, frame_token=""):
        """USBDevice.reset() 相当。デバイスのUSBバスリセットを行う。
        🛡️ security_audit No.1(拡張): バスリセット後のデバイスは、リセット前とは
        異なるディスクリプタで再列挙され得る(例: DFUモードへの遷移や
        ファームウェア更新後の再起動等)。reset()の前に記録していた
        claimed_interfaces/interface_alt_settings をそのまま信用し続けると、
        「以前は無害だったinterface番号が、リセット後は実は保護対象クラスに
        変わっていた」ケースでも判定に古い前提を使い回してしまう恐れがある。
        selectConfiguration()と同様にここでも無効化し、reset後は
        claimInterface()からの明示的なやり直しを要求する(=毎回その時点の
        実際のディスクリプタに対してalternate setting 0からの判定をやり直す)。"""
        try:
            dev = self._get_open_device(handle_id, frame_token)
            if dev is None:
                return _json_dumps({"success": False, "error": "Invalid device handle"})
            dev.reset()
            info = self._open_devices.get(handle_id)
            if info is not None:
                info["claimed_interfaces"] = set()
                info["interface_alt_settings"] = {}
            return _json_dumps({"success": True})
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    def _endpoint_available_or_error(self, handle_id, dev, in_transfer, endpoint_number, required_type=None):
        """実Chromeの USBDevice::EnsureEndpointAvailable()
        (third_party/blink/renderer/modules/webusb/usb_device.cc を実際に取得して
        確認)が transferIn/transferOut/clearHalt の前に必ず要求する事前条件:
        対象endpointは「claim済みかつ選択中のalternate settingに属する」
        interfaceの一部でなければならない。
        🛡️ 旧実装はcontrolTransferIn/Outにしかこの種の検証を入れておらず、
        bulkTransferIn/Out・clearHaltは対象ハンドルが開いてさえいれば無条件で
        実機へ転送を投げていた。つまりclaimInterface()を一度も呼ばず(=保護対象
        クラスの拒否を経由せず)に、保護対象インターフェースのbulk/interrupt
        endpointへ直接データを読み書きできてしまう抜け穴だった。
        endpoint_numberは方向ビットを含まない生の番号(spec/実Chrome: 1-15、
        0と16以上はIndexSizeError)。in_transfer=Trueならreadに使うin方向の
        endpoint、Falseならwriteに使うout方向のendpointを探す(同じ番号でも
        IN用とOUT用は別の記述子なので、Chrome同様に方向まで一致させる)。
        「選択中のalternate setting」までは追跡しておらず、claim済み
        インターフェースの持つ全alternateを対象に探索する簡略化をしている
        (ほとんどの実機はinterfaceあたりalternateが1つしかないため実害は小さく、
        より許容的になる方向の簡略化なので安全側からは外れない)。
        🛡️ security_audit No.1: 上記の「実害は小さい」という判断は誤りだった
        — alternate setting 0が無害なクラス、alternate setting 1が保護対象
        クラス(HID等)という複合デバイスでは、claimInterface()はalternate
        setting 0だけを見て許可する一方、この関数が全alternateを横断して
        endpointを探してしまうため、selectAlternateInterface()を一度も
        呼ばずに保護対象クラス側のendpointへ実データを読み書きできてしまう
        (詳細はVULNERABILITY_REPORT.md No.1、CVE-2018-6125と同種の回避策)。
        claimInterface()/selectAlternateInterface()が更新する
        interface_alt_settings(interface番号→現在のalternate setting、
        未記録なら仕様どおりデフォルトの0)を参照し、各interfaceについて
        「claim済み」かつ「今まさに選択されているalternate setting」の
        エントリだけを対象にendpointを探すよう修正した。
        required_type: 指定した場合、見つかったendpointの実際の転送タイプ
        ("bulk"/"interrupt"/"isochronous")がこれに含まれないとInvalidAccessError
        にする。文字列1つ("isochronous"等)、または許可するタイプのタプル/集合
        (("bulk", "interrupt")等)のどちらでも渡せる。
        (spec: isochronousTransferIn/Outが要求する「endpoint.typeが
        isochronousでなければInvalidAccessError」、およびtransferIn/Outが
        要求する「endpoint.typeがbulkでもinterruptでもなければ
        InvalidAccessError」の両方に対応する。)
        妥当なら (None, 見つかったInterface番号)、そうでなければ
        (json.dumps済みのエラーレスポンス文字列, None) を返す。"""
        if not (1 <= endpoint_number <= 15):
            return _json_dumps({
                "success": False,
                "error": index_size_error(f"endpoint number {endpoint_number} is out of range (must be 1-15)"),
            }), None
        info = self._open_devices.get(handle_id) or {}
        claimed = info.get("claimed_interfaces", set())
        alt_settings = info.get("interface_alt_settings", {})
        try:
            active_cfg = dev.get_active_configuration()
        except Exception:
            return _json_dumps({
                "success": False,
                "error": invalid_state_error("the device must have a configuration selected"),
            }), None

        owner_number = None
        found_ep = None
        try:
            for intf in active_cfg:
                inum = intf.bInterfaceNumber
                if inum not in claimed:
                    continue
                if getattr(intf, "bAlternateSetting", 0) != alt_settings.get(inum, 0):
                    continue  # claim済みだが、今は選択されていない別alternateの記述子
                for ep in intf:
                    addr = getattr(ep, "bEndpointAddress", None)
                    if addr is None or (addr & 0x0F) != endpoint_number:
                        continue
                    if bool(addr & 0x80) != bool(in_transfer):
                        continue
                    owner_number, found_ep = inum, ep
                    raise StopIteration
        except StopIteration:
            pass
        except Exception:
            pass

        if owner_number is None:
            direction_word = "IN" if in_transfer else "OUT"
            return _json_dumps({
                "success": False,
                "error": not_found_error(
                    f"{direction_word} endpoint {endpoint_number} is not part "
                    "of a claimed and selected alternate interface"
                ),
            }), None

        if required_type is not None:
            try:
                _usb_core, usb_util = self._pyusb()
                ep_type = usb_util.endpoint_type(found_ep.bmAttributes)
                type_name = {
                    usb_util.ENDPOINT_TYPE_BULK: "bulk",
                    usb_util.ENDPOINT_TYPE_INTR: "interrupt",
                    usb_util.ENDPOINT_TYPE_ISO: "isochronous",
                }.get(ep_type, "unknown")
            except Exception:
                type_name = "unknown"
            allowed_types = (required_type,) if isinstance(required_type, str) else tuple(required_type)
            if type_name not in allowed_types:
                allowed_word = " or ".join(allowed_types)
                return _json_dumps({
                    "success": False,
                    "error": invalid_access_error(
                        f"endpoint {endpoint_number} is a {type_name} endpoint, not {allowed_word}"
                    ),
                }), None

        return None, owner_number

    @Slot(int, str, int, str, result=str)
    def clearHalt(self, handle_id, direction, endpoint_number, frame_token=""):
        """USBDevice.clearHalt(direction, endpointNumber) 相当。
        directionは 'in' または 'out'。"""
        try:
            dev = self._get_open_device(handle_id, frame_token)
            if dev is None:
                return _json_dumps({"success": False, "error": "Invalid device handle"})
            validation_error, _owner = self._endpoint_available_or_error(
                handle_id, dev, direction == "in", endpoint_number
            )
            if validation_error is not None:
                return validation_error
            _usb_core, usb_util = self._pyusb()
            address = endpoint_number | (0x80 if direction == "in" else 0x00)
            dev.clear_halt(address)
            return _json_dumps({"success": True})
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    def _chunked_bulk_read(self, dev, endpoint_address, length):
        """endpoint_addressから最大length バイトをbulk/interrupt読み出しする。
        length が BULK_TRANSFER_CHUNK_SIZE 以下ならこれまでどおり1回のpyusb
        呼び出しで済ませる。それより大きい場合のみ、サブチャンクに分割し
        各サブチャンクの後で QCoreApplication.processEvents() を呼ぶ
        (大容量転送中もUIがある程度反応し続けるようにするため)。

        USBのbulk転送は「要求した長さぶん受信し終える」か「short packet
        (wMaxPacketSizeより短いパケット、'これで終わり'の合図として一般的な
        USBの慣習)を受信する」かのどちらか早い方で完了する、という仕様に
        従う必要がある。この関数は、各サブチャンクの受信量がそのサブ
        チャンクの要求量ちょうどだった場合のみ「まだ続きがあるかもしれない」
        と判断して次のサブチャンクを読みに行き、要求量より少なかった場合は
        short packetとみなしてそこで打ち切る — 単一の巨大な呼び出しをlibusbが
        内部的に行うのと同じ完了条件を、Python側のループでも再現している。"""
        if length <= BULK_TRANSFER_CHUNK_SIZE:
            return bytes(dev.read(endpoint_address, length, timeout=scaled_transfer_timeout_ms(length)))
        chunks = []
        remaining = length
        while remaining > 0:
            this_chunk = min(BULK_TRANSFER_CHUNK_SIZE, remaining)
            piece = bytes(dev.read(endpoint_address, this_chunk, timeout=scaled_transfer_timeout_ms(this_chunk)))
            chunks.append(piece)
            remaining -= len(piece)
            if len(piece) < this_chunk:
                break  # short packet = このtransferはここで完了
            if remaining > 0:
                QCoreApplication.processEvents()  # まだ続きがあるサブチャンクの合間だけ一息つく
        return b"".join(chunks)

    def _chunked_bulk_write(self, dev, endpoint, data):
        """dataをBULK_TRANSFER_CHUNK_SIZE単位に分割してendpointへ書き込む。
        書き込みには読み出しのようなshort packetの曖昧さは無い(呼び出し側が
        送るバイト数を完全に決めている)ため、ロジックは読み出し側より単純:
        全チャンクを順に書き込み、書き込めたバイト数の合計を返す。"""
        if len(data) <= BULK_TRANSFER_CHUNK_SIZE:
            return dev.write(endpoint, data, timeout=scaled_transfer_timeout_ms(len(data)))
        total_written = 0
        offset = 0
        while offset < len(data):
            chunk = data[offset:offset + BULK_TRANSFER_CHUNK_SIZE]
            written = dev.write(endpoint, chunk, timeout=scaled_transfer_timeout_ms(len(chunk)))
            total_written += written
            offset += len(chunk)
            if written < len(chunk):
                break  # デバイス側が全部は受け取れなかった -> ここで打ち切る
            if offset < len(data):
                QCoreApplication.processEvents()  # まだ続きがあるサブチャンクの合間だけ一息つく
        return total_written

    @Slot(int, int, int, str, result=str)
    def bulkTransferIn(self, handle_id, endpoint, length, frame_token=""):
        """USBDevice.transferIn(endpointNumber, length) 相当。
        🛡️ 実仕様: 'Let endpointAddress be endpointNumber | 0x80' — JSから渡ってくる
        endpointはIN/OUTの方向ビットを含まない生のendpointNumber(spec/JS両方の呼称)
        であり、実際にpyusbへ渡す必要があるbEndpointAddress(方向ビット込み)へは
        ここで変換しなければならない(pyusb公式ドキュメント: 'The endpoint parameter
        corresponds to the bEndpointAddress member' — endpointNumberそのものではない)。
        旧実装はこの変換が丸ごと抜けており、endpoint=1のIN転送がbEndpointAddress=0x01
        (=同じ番号のOUT側)を叩きにいってしまい、実機相手には常に失敗していた。
        🛡️ バグ修正(v0.0.4): 仕様のtransferIn()は対象endpointのtypeがbulkでも
        interruptでもなければInvalidAccessErrorを返すと定めている
        (isochronousTransferInが別メソッドとして独立して用意されているのはこの
        ため)。旧実装はrequired_typeを指定しておらず、isochronous専用の
        endpointに対してもこのメソッド経由でread()できてしまっていた
        (pyusbのDevice.read()自体はendpoint記述子から転送タイプを自動判別して
        くれるため実際に転送自体は成功してしまう分、見過ごされやすい)。
        🚚 大容量転送対応(v0.0.4a0, WebADB等を想定): (1) lengthに実務上の上限
        (BULK_TRANSFER_MAX_LENGTH)を設け、行儀の悪い/悪意あるページが巨大な
        lengthを渡すだけでホスト側に無制限のメモリ確保を強制できないようにする。
        (2) 固定5秒だったtimeoutを、要求サイズに応じてスケールさせる
        (scaled_transfer_timeout_ms) — 低速リンクや大容量ペイロードで正当な
        転送が完了前に打ち切られるのを防ぎつつ、無期限ブロックにはしない。
        (3) デバイスが要求より多くのデータを返した場合のbabbleステータス
        (仕様のUSBTransferStatus)を検出する。
        🧵 UIフリーズ対策(v0.0.4b): BULK_TRANSFER_CHUNK_SIZEを超える要求は
        _chunked_bulk_read()でサブチャンクに分割し、合間にQtのイベント
        ループを一息つかせる(単一の巨大なブロッキングpyusb呼び出しが
        アプリ全体のUIを長時間フリーズさせる問題への対処。詳細はCHANGELOG
        v0.0.4bを参照)。再入(processEvents()中に同じhandleへの新たな転送
        呼び出しが割り込むこと)はhandle単位で検出し、安全にエラーを返す。"""
        if handle_id in self._busy_handles:
            return _json_dumps({
                "success": False,
                "error": invalid_state_error(
                    f"handle {handle_id} already has a bulk transfer in progress"
                ),
            })
        try:
            dev = self._get_open_device(handle_id, frame_token)
            if dev is None:
                return _json_dumps({"success": False, "error": "Invalid device handle"})
            # 🔓 v0.0.4b2: 実Chromeの32MiB上限(CHROME_USB_TRANSFER_LENGTH_LIMIT)は
            # ここでは拒否理由にしない(方針: Chromeの代替品ではなく独自拡張を持つ
            # 実装として、実転送は続行しDevTools consoleへ警告するだけに留める)。
            # 実際に拒否するのは、この実装自身のホストプロセス保護のための
            # はるかに大きいHOST_SAFETY_MAX_TRANSFER_LENGTHを超えた場合のみ。
            if length < 0 or length > HOST_SAFETY_MAX_TRANSFER_LENGTH:
                return _json_dumps({
                    "success": False,
                    "error": data_error(
                        f"The data buffer exceeded supported maximum size of "
                        f"{HOST_SAFETY_MAX_TRANSFER_LENGTH} bytes"
                    ),
                })
            transfer_warning = (
                chrome_transfer_limit_warning(length) if length > CHROME_USB_TRANSFER_LENGTH_LIMIT else None
            )
            validation_error, _owner = self._endpoint_available_or_error(
                handle_id, dev, True, endpoint, required_type=("bulk", "interrupt")
            )
            if validation_error is not None:
                return validation_error
            endpoint_address = endpoint | 0x80
            self._busy_handles.add(handle_id)
            try:
                data = self._chunked_bulk_read(dev, endpoint_address, length)
            except Exception as e:
                # 🛡️ 実仕様: STALL/babbleはPromiseのreject対象ではなく、
                #    status:'stall'/'babble'を伴う"成功"resolveとして返す
                #    (STALLは呼び出し側がclearHalt()で解除して続行するのが
                #    仕様が想定する標準的な流れ)。それ以外の失敗理由は
                #    従来どおり外側のexceptでNetworkError相当として扱う。
                if is_stall_error(e):
                    return _format_transfer_success_json("stall", b"")
                if is_babble_error(e):
                    return _format_transfer_success_json("babble", b"")
                raise
            finally:
                self._busy_handles.discard(handle_id)
            return _format_transfer_success_json("ok", data, warning=transfer_warning)
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    @Slot(int, int, str, str, result=str)
    def bulkTransferOut(self, handle_id, endpoint, data_b64, frame_token=""):
        """USBDevice.transferOut(endpointNumber, data) 相当。
        🛡️ バグ修正(v0.0.4): bulkTransferInと同じ理由で、endpointのtypeがbulk/
        interruptであることを要求する(isochronous endpointへの誤爆を防ぐ)。
        🚚 大容量転送対応(v0.0.4a0): データはbase64で受け取る(旧: hex文字列。
        base64はhexの2倍膨張に対しおよそ1.33倍で済み、WebADBのような大容量
        転送でのJSON往復サイズを抑えられる)。timeoutも要求サイズに応じて
        スケールさせる。
        🧵 UIフリーズ対策(v0.0.4b): bulkTransferInと同じ理由・同じ仕組みで
        _chunked_bulk_write()によりサブチャンク分割 + processEvents() +
        再入ガードを行う。"""
        if handle_id in self._busy_handles:
            return _json_dumps({
                "success": False,
                "error": invalid_state_error(
                    f"handle {handle_id} already has a bulk transfer in progress"
                ),
            })
        try:
            dev = self._get_open_device(handle_id, frame_token)
            if dev is None:
                return _json_dumps({"success": False, "error": "Invalid device handle"})
            validation_error, _owner = self._endpoint_available_or_error(
                handle_id, dev, False, endpoint, required_type=("bulk", "interrupt")
            )
            if validation_error is not None:
                return validation_error
            data, _b64_error = _b64decode_or_data_error(data_b64)
            if _b64_error is not None:
                return _b64_error
            self._busy_handles.add(handle_id)
            try:
                written = self._chunked_bulk_write(dev, endpoint, data)
            except Exception as e:
                if is_stall_error(e):
                    return _json_dumps({"success": True, "status": "stall", "bytesWritten": 0})
                raise
            finally:
                self._busy_handles.discard(handle_id)
            return _json_dumps({"success": True, "status": "ok", "bytesWritten": written})
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    def _control_transfer_validation_error(self, handle_id, dev, request_type, request, index):
        """WebUSB仕様「check the validity of the control transfer parameters」
        (index.bs, controlTransferIn/Outの手前で毎回走る前提のアルゴリズム)の
        うちPython側でしか判定できない部分 -- インターフェースが保護対象クラスか、
        実際にclaim済みか -- をここで最終防衛として検証する。
        🛡️ この検証が無いと、claimInterface()自体は保護対象クラス(HID等)を
        拒否していても、controlTransferIn/Out に requestType:'class' や
        recipient:'interface'/'endpoint' を指定して直接その保護対象インターフェースへ
        生のコントロール転送を送れてしまい、claimInterfaceの保護を完全にバイパス
        できる状態だった(実際にJS/Python双方のコードを読んで確認した抜け穴で、
        テストも無かった)。
        妥当なら None、そうでなければ json.dumps済みのエラーレスポンス文字列を返す。
        bmRequestType(request_type)からの復号は仕様どおりのビット割り当て:
          bit7    : 方向(1=IN)。ここではrequestTypeそのものから読めるので
                    JSから別途directionを受け取る必要が無い。
          bit6-5  : requestType種別(00=standard, 01=class, 10=vendor)
          bit1-0  : recipient種別(00=device, 01=interface, 10=endpoint, 11=other)
        (polyfill.py側のreqType組み立てロジックと1対1で対応する)。"""
        info = self._open_devices.get(handle_id) or {}
        claimed = info.get("claimed_interfaces", set())
        direction_in = bool(request_type & 0x80)
        req_kind = (request_type >> 5) & 0x03      # 0=standard,1=class,2=vendor
        recipient = request_type & 0x03            # 0=device,1=interface,2=endpoint,3=other

        _ERROR_BUILDERS = {
            "SecurityError": security_error,
            "InvalidStateError": invalid_state_error,
            "NotFoundError": not_found_error,
        }

        def _err(name, msg):
            return _json_dumps({"success": False, "error": _ERROR_BUILDERS[name](msg)})

        if req_kind == 0:  # standard
            if not direction_in:
                return _err("SecurityError", "standard requests are not allowed for controlTransferOut")
            if request not in (0x00, 0x06, 0x08, 0x0A, 0x0C):
                return _err(
                    "SecurityError",
                    f"standard request {request:#04x} is not one of the requests allowed by the "
                    "WebUSB spec (GET_STATUS/GET_DESCRIPTOR/GET_CONFIGURATION/GET_INTERFACE/SYNCH_FRAME)",
                )

        if req_kind == 1:  # class
            iface_number = index & 0xFF
            iface_class = interface_class_for(dev, iface_number)
            if is_protected_interface_class(iface_class):
                name = protected_class_name(iface_class)
                return _err(
                    "SecurityError",
                    f"interface {iface_number} is class '{name}', a protected interface class, "
                    "and cannot receive class-specific control requests",
                )

        if recipient == 1:  # interface
            iface_number = index & 0xFF
            iface_class = interface_class_for(dev, iface_number)
            if iface_class is None:
                return _err("NotFoundError", f"interface {iface_number} was not found on this device")
            if is_protected_interface_class(iface_class):
                name = protected_class_name(iface_class)
                return _err("SecurityError", f"interface {iface_number} is class '{name}', a protected interface class")
            if iface_number not in claimed:
                return _err("InvalidStateError", f"interface {iface_number} has not been claimed")

        if recipient == 2:  # endpoint
            # 仕様: recipient=="endpoint"の場合は setup.index そのものがendpointAddress
            # (interface/classのように下位8bitへ切り詰めない)。実運用上のindexは
            # 常に1バイトに収まる値なので & 0xFF は安全側の正規化として扱う。
            endpoint_address = index & 0xFF
            owner_number, owner_class = None, None
            alt_settings = info.get("interface_alt_settings", {})
            try:
                active_cfg = dev.get_active_configuration()
                matching_alts = []
                for intf in active_cfg:
                    for ep in intf:
                        if getattr(ep, "bEndpointAddress", None) == endpoint_address:
                            matching_alts.append((
                                intf.bInterfaceNumber,
                                getattr(intf, "bAlternateSetting", 0),
                                intf.bInterfaceClass,
                            ))
                if not matching_alts:
                    return _err("NotFoundError", f"endpoint {endpoint_address:#04x} was not found on this device")

                # 🐛 バグ修正(v0.0.5b2、実際に再現して確認): 以前は「このendpoint
                # アドレスを持ついずれかのalternateが保護対象クラスなら一律拒否」を、
                # どのaltが今選択されているかを見る前に判定してしまっていた。
                # alt 0(無害・現在選択中)とalt 1(HID・現在は選択されていない)が
                # 同じendpointアドレスを共有する複合デバイス(実デバイスでも
                # 珍しくない——USB仕様上、同一interface番号の別alternateは
                # 別々のbInterfaceClassとendpoint構成を持ってよい)に対して、
                # claimInterface()は正しくalt 0を無害と判定してclaimを許可した
                # にもかかわらず、その後の現在有効なalt 0への完全に正当な
                # controlTransferIn/Out(recipient=endpoint)までSecurityErrorで
                # 拒否してしまっていた(実際に再現して確認済み)。
                # 先に「今どのaltが実際にこのendpointの持ち主か」
                # (_endpoint_available_or_error()と同じく、alt_settingsが
                # 追跡する「現在選択中のalternate」)を決定してから、その持ち主
                # だけを保護対象クラス判定にかけるよう順序を入れ替える。
                for iface_num, alt_num, cls in matching_alts:
                    current_alt = alt_settings.get(iface_num, 0)
                    if alt_num == current_alt:
                        owner_number, owner_class = iface_num, cls
                        break
                if owner_number is None:
                    # 🛡️ 現在選択中のどのaltもこのendpointアドレスを持たない
                    # (＝実機の現在の状態としてはそもそも到達できないはずの
                    # endpoint)場合。素朴にNotFoundErrorにする前に、候補の
                    # いずれかが保護対象クラスであれば、raw endpointアドレス
                    # 指定で保護対象alternateへ間接的に探りを入れようとした
                    # 可能性を疑い、引き続きSecurityErrorを優先する(安全側、
                    # 元のsecurity_audit No.1拡張の意図はここで維持する)。
                    for iface_num, alt_num, cls in matching_alts:
                        if is_protected_interface_class(cls):
                            name = protected_class_name(cls)
                            return _err(
                                "SecurityError",
                                f"endpoint {endpoint_address:#04x} belongs to interface class '{name}', "
                                "a protected interface class",
                            )
                    owner_number, _alt_num, owner_class = matching_alts[0]
                elif is_protected_interface_class(owner_class):
                    name = protected_class_name(owner_class)
                    return _err(
                        "SecurityError",
                        f"endpoint {endpoint_address:#04x} belongs to interface class '{name}', "
                        "a protected interface class",
                    )
            except Exception:
                pass
            if owner_number is None:
                return _err("NotFoundError", f"endpoint {endpoint_address:#04x} was not found on this device")
            if owner_number not in claimed:
                return _err("InvalidStateError", f"interface {owner_number} owning endpoint {endpoint_address:#04x} has not been claimed")

        return None

    @Slot(int, int, int, int, int, int, str, result=str)
    def controlTransferIn(self, handle_id, request_type, request, value, index, length, frame_token=""):
        """USBDevice.controlTransferIn() 相当。
        🚚 大容量転送対応(v0.0.4a0): 仕様上lengthはWebIDLのunsigned short
        (0-65535)なので、それを超える値はここで弾く(この実装独自の防御。
        コントロール転送は仕様上そもそも64KiBが上限なのでBULK_TRANSFER_
        MAX_LENGTHのような大きな上限は不要、そのまま仕様の型上限を使う)。
        timeoutは要求サイズに応じてスケールさせ、babbleステータスも検出する。"""
        try:
            dev = self._get_open_device(handle_id, frame_token)
            if dev is None:
                return _json_dumps({"success": False, "error": "Invalid device handle"})
            if length < 0 or length > CONTROL_TRANSFER_MAX_LENGTH:
                return _json_dumps({
                    "success": False,
                    "error": index_size_error(
                        f"length {length} is out of range "
                        f"(must be between 0 and {CONTROL_TRANSFER_MAX_LENGTH})"
                    ),
                })
            validation_error = self._control_transfer_validation_error(handle_id, dev, request_type, request, index)
            if validation_error is not None:
                return validation_error
            try:
                data = dev.ctrl_transfer(
                    request_type, request, value, index, length,
                    timeout=scaled_transfer_timeout_ms(length),
                )
            except Exception as e:
                if is_stall_error(e):
                    return _format_transfer_success_json("stall", b"")
                if is_babble_error(e):
                    return _format_transfer_success_json("babble", b"")
                raise
            return _format_transfer_success_json("ok", data)
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    @Slot(int, int, int, int, int, str, str, result=str)
    def controlTransferOut(self, handle_id, request_type, request, value, index, data_b64, frame_token=""):
        """USBDevice.controlTransferOut() 相当。
        🚚 大容量転送対応(v0.0.4a0): データはbase64で受け取る(旧: hex文字列)。
        timeoutも要求サイズに応じてスケールさせる。"""
        try:
            dev = self._get_open_device(handle_id, frame_token)
            if dev is None:
                return _json_dumps({"success": False, "error": "Invalid device handle"})
            validation_error = self._control_transfer_validation_error(handle_id, dev, request_type, request, index)
            if validation_error is not None:
                return validation_error
            data, _b64_error = _b64decode_or_data_error(data_b64)
            if _b64_error is not None:
                return _b64_error
            try:
                written = dev.ctrl_transfer(
                    request_type, request, value, index, data,
                    timeout=scaled_transfer_timeout_ms(len(data)),
                )
            except Exception as e:
                if is_stall_error(e):
                    return _json_dumps({"success": True, "status": "stall", "bytesWritten": 0})
                raise
            return _json_dumps({"success": True, "status": "ok", "bytesWritten": written})
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    # 🛡️ セキュリティ修正(v0.0.4b2): 以下3メソッドは元々@Slotが付いており、
    # QWebChannel経由でJS/Webページから直接呼び出し可能になっていた。しかし
    # install()はポリフィルJSをMainWorld(=表示中ページ自身のJSと同じ実行
    # コンテキスト)へ注入するため(polyfill.py内setWorldId呼び出し参照)、
    # qt.webChannelTransportはページJSからも到達可能であり、ページが独自に
    # QWebChannelへ接続してchannel.objects.pyUsbBridgeへ直接触れることを妨げる
    # 手段が無い。つまり@Slotが付いている限り、任意のWebページがこれらを直接
    # 呼び出せてしまっていた——「既知デバイス一覧の閲覧・全削除を表示中の
    # Webページへ公開すべきではない」というのは、すぐ下のlist_granted_origins
    # 等がまさに同じファイル内で明記している原則そのものであり、この3つだけが
    # (おそらく、より慎重なオリジン単位の許可管理アーキテクチャが整備される前の
    # 初期実装のまま)その原則に反していた。@Slotを外し、list_granted_origins
    # 等と同じ「ホストアプリ自身の信頼されたPythonコード(設定画面等)からのみ
    # 呼び出せる」扱いへ揃えた。polyfill.py側のJSはこれら3メソッドを一切
    # 呼んでおらず(grep済み)、この変更で失われる機能は無い。
    def listKnownDevices(self):
        """設定内に保存済みの既知USBデバイス一覧を返す（設定画面のUSB管理パネル用）"""
        try:
            devices = self._load_known_devices()
            devices.sort(key=lambda d: (-(d.get("connectCount", 0)), -(d.get("lastConnected", 0))))
            return _json_dumps({"devices": devices})
        except Exception as e:
            return _json_dumps({"devices": [], "error": safe_error_str(e)})

    def forgetKnownDevice(self, vendor_id, product_id):
        """既知デバイス一覧から特定の1台を削除する"""
        try:
            devices = self._load_known_devices()
            new_devices = [d for d in devices
                           if not (d.get("vendorId") == vendor_id and d.get("productId") == product_id)]
            self._save_known_devices(new_devices)
            return _json_dumps({"success": True})
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    def forgetAllKnownDevices(self):
        """既知デバイス一覧を全削除する"""
        try:
            self._save_known_devices([])
            return _json_dumps({"success": True})
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    def _iso_backend_or_error(self, dev):
        """isochronous転送に使う低レベルbackend/デバイスハンドルを取得する。
        🛡️ 重要な注意: pyusbの公開API(usb.core.Device)にはisochronous転送用の
        メソッドが無い(read()/write()はbulk/interrupt専用、と公式ドキュメントに
        明記されている)。一方、libusb1バックエンド自体は iso_read()/iso_write()
        という低レベルAPIを持っており、これがpyusbコミュニティで知られている
        事実上唯一のワークアラウンドだが、使うには dev._ctx.handle という
        pyusbの非公開の内部属性へ直接アクセスする必要がある。
        これはこのプロジェクトの他の全実装が守っている「pyusbの公開APIのみに
        依存する」という原則から外れる、この機能固有の例外。
        pyusbのバージョンが変わって内部構造が変化した場合や、libusb1以外の
        バックエンド(古いWindows環境のlibusb0/OpenUSB等)が使われている場合は、
        例外を投げず素直にNotSupportedErrorの文字列を返す
        (黙って間違った動作をするより、対応できないことを呼び出し元に伝える)。
        妥当なら (backend, dev_handle) のタプル、そうでなければ
        json.dumps済みのエラーレスポンス文字列を返す。"""
        try:
            backend = dev.backend
            dev_handle = dev._ctx.handle
            if backend is None or dev_handle is None:
                raise AttributeError("backend or device handle not available")
            if not (hasattr(backend, "iso_read") and hasattr(backend, "iso_write")):
                raise AttributeError("backend has no iso_read/iso_write")
        except Exception:
            return _json_dumps({
                "success": False,
                "error": (
                    "NotSupportedError: isochronous transfers require pyusb's libusb1 "
                    "backend with an open device handle, which is not available in this "
                    "environment"
                ),
            })
        return backend, dev_handle

    @staticmethod
    def _validate_packet_lengths(packet_lengths_json):
        """packetLengthsの妥当性検証と、pyusbのiso_read/iso_writeが要求する
        「全パケット同じ長さ」制約のチェック。
        🛡️ 既知の制約: pyusbのlibusb1バックエンドは、渡した1本のバッファを
        libusb_get_max_iso_packet_size()から求めた"均一な"パケット長で機械的に
        分割する実装になっており(最後の1個だけ端数を許容)、spec本文が許す
        「パケットごとに異なる長さ」を表現する手段が無い。このため、渡された
        packetLengthsが全て同じ長さの場合のみ対応し、そうでない場合は
        NotSupportedErrorを返す(誤った長さで黙って動くよりはるかに安全)。
        妥当なら (packet_lengths, None)、そうでなければ (None, エラーレスポンス文字列)。

        🔬 打開策の調査(v0.0.4b2): 可変長パケットへの対応をRust経由のlibusb直接
        バインディング(rusb/libusb1-sys等)で実現できないか検討した。libusbの
        C API自体は`libusb_fill_iso_transfer`でパケットごとに異なる長さを設定
        できる(`iso_packet_desc[i].length`)ため、理論上は可能。ただし
        実装するには次の課題があり、今回は見送った:
          1. libusbの等時転送は非同期API(submit + イベントループでの
             コールバック待ち)のみで、同期APIが存在しない。「同期的に完了を
             待つ」薄いラッパーを書くこと自体は可能だが、
          2. pyusbが既に開いている同じデバイス・同じインターフェースに対して、
             Rust側から別途libusbハンドルを取って同時に触るのは、多くの
             プラットフォームで「同一インターフェースの二重claim」に相当し
             安全に共存できない。回避するにはpyusbが内部で保持する生の
             `libusb_device_handle*`をRustへ渡す必要があるが、これは
             pyusbの非公開の内部実装(`_ctx.handle.handle`等)に依存する
             脆弱な方法であり、かつ生ポインタを言語間で共有するunsafeな
             FFIになる。
          3. 実USBハードウェアがこの環境に存在せず、上記のような低レベル
             FFIコードを実機で検証する手段が無い。誤って実装した場合、
             単なる論理バグではなくクラッシュや、デバイスへ意図しない
             バイト列(パディング等)を送りつけて実機を誤動作させる
             リスクがある——検証不能な状態でこれを組み込むのは、明確な
             NotSupportedErrorを返す現状より悪い結果になりかねないと判断した。
        そのため、この制約は解消できていない(既知の制約として残す)。将来的に
        実機での検証手段が確保できれば、上記1-2を踏まえた設計で再検討する
        価値はある。"""
        try:
            packet_lengths = json.loads(packet_lengths_json) if packet_lengths_json else []
        except Exception:
            return None, _json_dumps({"success": False, "error": "TypeError: packetLengths must be a JSON array"})
        if not isinstance(packet_lengths, list) or not packet_lengths:
            return None, _json_dumps({"success": False, "error": "TypeError: packetLengths must be a non-empty array"})
        if any((not isinstance(n, int)) or isinstance(n, bool) or n < 0 for n in packet_lengths):
            return None, _json_dumps({"success": False, "error": "TypeError: packetLengths must contain non-negative integers"})
        if len(set(packet_lengths)) > 1:
            return None, _json_dumps({
                "success": False,
                "error": (
                    "NotSupportedError: this bridge only supports isochronous transfers "
                    "with uniform packet lengths (pyusb's isochronous backend doesn't "
                    "expose arbitrary per-packet lengths)"
                ),
            })
        return packet_lengths, None

    # --- isochronous転送 ---
    # ⚠️ 実機での動作は未検証: このサンドボックスには実USBハードウェアが存在せず、
    #    ここから先(iso_read/iso_writeの実呼び出し)は自動テストでも実機相手には
    #    検証できていない。フォールバック経路(バックエンド非対応・packetLengths
    #    不正)とパケット分割の算術だけはテスト済み。実配線での検証は別途必要。
    @Slot(int, int, str, str, result=str)
    def isochronousTransferIn(self, handle_id, endpoint, packet_lengths_json, frame_token=""):
        """USBDevice.isochronousTransferIn(endpointNumber, packetLengths) 相当。
        🚚 大容量転送対応(v0.0.4a0): packetLengths合計に上限を設け(この実装
        独自の防御)、timeoutを合計サイズに応じてスケールさせ、babbleステータス
        (デバイスが要求より多くのデータを返した場合)も検出する。
        🧵 スコープ上の判断(v0.0.4b): bulkTransferIn/Outとは異なり、あえて
        _chunked_bulk_read()相当のサブチャンク分割は行っていない。isochronous
        転送は音声/映像等のリアルタイム性が本質であり、サブチャンクの合間に
        processEvents()で一息つく設計は、そのリアルタイム性そのものを損ないうる
        (bulk転送には無い副作用)。また実際のADB等の大容量転送ユースケースは
        bulk転送のみを使い、isochronousは使わない。ISOCHRONOUS_TRANSFER_MAX_
        TOTAL_LENGTH(16MiB)はあくまで暴走防止の安全弁であり、現実的な
        isochronousの1回あたり使用量(通常は数KB〜数百KB程度)を大きく上回る
        値なので、チャンク化しないことによるブロッキング時間もbulk転送ほど
        深刻にはなりにくいと判断した。"""
        try:
            packet_lengths, error = self._validate_packet_lengths(packet_lengths_json)
            if error is not None:
                return error
            packet_length = packet_lengths[0]
            total_length = packet_length * len(packet_lengths)
            # 🔓 v0.0.4b2: bulkTransferInと同じ方針転換。CHROME_USB_TRANSFER_LENGTH_LIMIT
            # (実Chromeの32MiB上限)は拒否理由にせず警告に留め、実際に拒否するのは
            # この実装自身のHOST_SAFETY_MAX_TRANSFER_LENGTHを超えた場合のみ。
            if total_length > HOST_SAFETY_MAX_TRANSFER_LENGTH:
                return _json_dumps({
                    "success": False,
                    "error": data_error(
                        f"The data buffer exceeded supported maximum size of "
                        f"{HOST_SAFETY_MAX_TRANSFER_LENGTH} bytes"
                    ),
                })
            transfer_warning = (
                chrome_transfer_limit_warning(total_length)
                if total_length > CHROME_USB_TRANSFER_LENGTH_LIMIT else None
            )

            dev = self._get_open_device(handle_id, frame_token)
            if dev is None:
                return _json_dumps({"success": False, "error": "Invalid device handle"})
            validation_error, owner_number = self._endpoint_available_or_error(
                handle_id, dev, True, endpoint, required_type="isochronous"
            )
            if validation_error is not None:
                return validation_error

            iso = self._iso_backend_or_error(dev)
            if isinstance(iso, str):
                return iso
            backend, dev_handle = iso

            import array
            buff = array.array("B", bytes(total_length))
            endpoint_address = endpoint | 0x80
            # 🛡️ バグ修正(v0.0.4): インストール済みpyusbのlibusb1.pyを直接読んで確認した
            # 実シグネチャは iso_read(self, dev_handle, ep, intf, buff, timeout) であり、
            # 第3引数はインターフェース番号(高レベルAPIのDevice.read()内部でも
            # intf.bInterfaceNumberとして渡している値)。旧実装はここにエンドポイント
            # 番号を渡していた。現行pyusb(1.3.1)の_IsoTransferHandlerはintfを実際には
            # 参照しないため実害は無いが、意味的に誤った値であり、将来のpyusbが
            # intfを使い始めた場合の地雷になる。既に_endpoint_available_or_error()が
            # 正しいインターフェース番号を返しているのでそれを使う。
            try:
                transferred = backend.iso_read(
                    dev_handle, endpoint_address, owner_number, buff,
                    timeout=scaled_transfer_timeout_ms(total_length),
                )
            except Exception as e:
                if is_stall_error(e):
                    # 個々のパケット単位でstall/ok を区別する手段がpyusb越しには無いため、
                    # 安全側に倒して全パケットstall扱いにする。
                    packets = [{"status": "stall", "data": ""} for _ in packet_lengths]
                    return _json_dumps({"success": True, "packets": packets})
                if is_babble_error(e):
                    packets = [{"status": "babble", "data": ""} for _ in packet_lengths]
                    return _json_dumps({"success": True, "packets": packets})
                raise

            received = bytes(buff)[:max(int(transferred), 0)]
            packets = []
            offset = 0
            for _ in packet_lengths:
                chunk = received[offset:offset + packet_length]
                offset += packet_length
                packets.append({"status": "ok", "data": _b64encode(chunk)})
            response = {"success": True, "packets": packets}
            if transfer_warning is not None:
                response["warning"] = transfer_warning
            return _json_dumps(response)
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    @Slot(int, int, str, str, str, result=str)
    def isochronousTransferOut(self, handle_id, endpoint, data_b64, packet_lengths_json, frame_token=""):
        """USBDevice.isochronousTransferOut(endpointNumber, data, packetLengths) 相当。
        🚚 大容量転送対応(v0.0.4a0): データはbase64で受け取る(旧: hex文字列)。
        timeoutもpacketLengths合計に応じてスケールさせる。"""
        try:
            packet_lengths, error = self._validate_packet_lengths(packet_lengths_json)
            if error is not None:
                return error
            packet_length = packet_lengths[0]
            total_length = packet_length * len(packet_lengths)
            # 🔓 v0.0.4b2: isochronousTransferInと同じ方針転換(下記参照)。
            if total_length > HOST_SAFETY_MAX_TRANSFER_LENGTH:
                return _json_dumps({
                    "success": False,
                    "error": data_error(
                        f"The data buffer exceeded supported maximum size of "
                        f"{HOST_SAFETY_MAX_TRANSFER_LENGTH} bytes"
                    ),
                })
            transfer_warning = (
                chrome_transfer_limit_warning(total_length)
                if total_length > CHROME_USB_TRANSFER_LENGTH_LIMIT else None
            )

            data, _b64_error = _b64decode_or_data_error(data_b64)
            if _b64_error is not None:
                return _b64_error
            if len(data) != total_length:
                # 🛡️ バグ修正(v0.0.4b2, 実Blinkソース確認済み): dataの長さが
                # packetLengths合計と一致しない場合、実Chromeは
                # "The data buffer size must match the total packet length."
                # というDataErrorで拒否している(kBufferSizeMismatch)。旧実装は
                # この検証が丸ごと抜けており、data長がtotal_lengthと食い違って
                # いても(短すぎ/長すぎのいずれでも)そのままbackend.iso_write()へ
                # 渡してしまっていた——意図しないバイト列を送出しうる、実害の
                # あるバリデーション漏れだった。
                return _json_dumps({
                    "success": False,
                    "error": data_error("The data buffer size must match the total packet length."),
                })

            dev = self._get_open_device(handle_id, frame_token)
            if dev is None:
                return _json_dumps({"success": False, "error": "Invalid device handle"})
            validation_error, owner_number = self._endpoint_available_or_error(
                handle_id, dev, False, endpoint, required_type="isochronous"
            )
            if validation_error is not None:
                return validation_error

            iso = self._iso_backend_or_error(dev)
            if isinstance(iso, str):
                return iso
            backend, dev_handle = iso

            import array
            buff = array.array("B", data)
            # 🛡️ バグ修正(v0.0.4): isochronousTransferInと同じ理由で、第3引数には
            # エンドポイント番号ではなくインターフェース番号(owner_number)を渡す。
            try:
                transferred = backend.iso_write(
                    dev_handle, endpoint, owner_number, buff,
                    timeout=scaled_transfer_timeout_ms(len(data)),
                )
            except Exception as e:
                if is_stall_error(e):
                    packets = [{"status": "stall", "bytesWritten": 0} for _ in packet_lengths]
                    return _json_dumps({"success": True, "packets": packets})
                raise

            remaining = max(int(transferred), 0)
            packets = []
            for _ in packet_lengths:
                written = min(packet_length, remaining)
                remaining -= written
                packets.append({"status": "ok", "bytesWritten": written})
            response = {"success": True, "packets": packets}
            if transfer_warning is not None:
                response["warning"] = transfer_warning
            return _json_dumps(response)
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    # --- オリジン権限の管理 ---
    @Slot(int, int, str, result=str)
    def forgetGrantedDevice(self, vendor_id, product_id, frame_token=""):
        """USBDevice.forget() 相当。★あえて対象オリジンを引数に取らない:
        現在のページ自身(self._current_origin())の許可だけを取り消せるようにし、
        任意のサイトが他サイトの許可を操作できないようにしている。"""
        try:
            origin = self._current_origin(frame_token)
            if not origin:
                return _json_dumps({"success": False})
            data = self._load_granted_origins()
            grants = data.get(origin, [])
            new_grants = [g for g in grants if not (g.get("vendorId") == vendor_id and g.get("productId") == product_id)]
            if len(new_grants) != len(grants):
                data[origin] = new_grants
                self._save_granted_origins(data)
            return _json_dumps({"success": True})
        except Exception as e:
            return _json_dumps({"success": False, "error": safe_error_str(e)})

    # ↓↓↓ 以下4つは意図的に @Slot を付けていない(=QWebChannel経由でJS/Webページからは
    # 一切呼び出せない)。任意のオリジン一覧の閲覧・許可の付与/取り消しは、
    # 設定画面のようなアプリ内部の信頼された経路からのみ行うべき情報/操作であり、
    # 表示中のWebページに公開すべきではないため。設定UIを追加する際はここから
    # Python側で直接呼び出す想定。
    def list_granted_origins(self):
        """{origin: [{"vendorId":.., "productId":.., "grantedAt":..}, ...]}"""
        try:
            return self._load_granted_origins()
        except Exception as e:
            self._log("list_granted_origins", e)
            return {}

    def grant_device_for_origin(self, origin, vendor_id, product_id):
        """🆕 v0.0.5a0: revoke_origin_grant()/revoke_all_for_origin()は元々あったが、
        その対になる「取り消しではなく能動的に許可する」公開APIが存在しない
        非対称なギャップがあった。ホストアプリ自身が、チューザーダイアログを
        一切経由せずに、あるオリジンへ特定デバイスへのアクセスを事前許可
        できるようにする——実Chromeのエンタープライズポリシー
        `WebUsbAllowDevicesForUrls` に相当する、kiosk/組み込み用途向けの
        仕組み(起動時に設定ファイルや管理者ポリシーから呼び出す想定)。

        requestDeviceChooser()経由の通常の許可と全く同じ_grant()/永続化
        ストア(QSettings、_load_granted_origins/_save_granted_origins)を
        使うため、事前許可された組み合わせはlistDevices()/navigator.usb.
        getDevices()にも即座に反映され、後からrevoke_origin_grant()で
        取り消すこともできる——通常フローで得た許可と区別できない、
        完全に対称な操作として扱える。

        🛡️ ブロックリスト対象デバイス(セキュリティキー等、
        KNOWN_SECURITY_KEY_BLOCKLIST)は、ここでも拒否する。むしろ
        ユーザー本人の明示的な操作(チューザーダイアログでの選択)を経ない
        経路だからこそ、汚染された/誤った設定ファイル経由でうっかり
        許可してしまう事故を防ぐ意味は openDevice() 以上に大きい。

        戻り値: 実際に新規の許可を追加したら True。既に許可済みだった場合や、
        origin未指定/ブロックリスト該当で許可しなかった場合は False——
        「何か変わったか」を呼び出し元(設定UIの保存ボタン等)がそのまま
        判定に使えるようにするため、単なる成功フラグではなくこの意味にする
        (revoke_origin_grant()の戻り値の意味と対称)。"""
        try:
            if not origin:
                return False
            if is_blocklisted_device(vendor_id, product_id):
                print(
                    f"[pyside6-webusb] grant_device_for_origin: ブロックリスト対象デバイス "
                    f"(vendorId={vendor_id}, productId={product_id}) への事前許可はスキップされました"
                )
                return False
            already_granted = self._is_granted(origin, vendor_id, product_id)
            self._grant(origin, vendor_id, product_id)
            return not already_granted
        except Exception as e:
            self._log("grant_device_for_origin", e)
            return False

    def revoke_origin_grant(self, origin, vendor_id, product_id):
        try:
            data = self._load_granted_origins()
            grants = data.get(origin, [])
            new_grants = [g for g in grants if not (g.get("vendorId") == vendor_id and g.get("productId") == product_id)]
            if len(new_grants) != len(grants):
                data[origin] = new_grants
                self._save_granted_origins(data)
                return True
            return False
        except Exception as e:
            # 🛡️ 呼び出し元(設定パネル等)が「取り消しに成功したか」を正しく判断できるよう、
            #    保存失敗時にTrueを誤って返さない。
            self._log("revoke_origin_grant", e)
            return False

    def revoke_all_for_origin(self, origin):
        try:
            data = self._load_granted_origins()
            if origin in data:
                del data[origin]
                self._save_granted_origins(data)
                return True
            return False
        except Exception as e:
            self._log("revoke_all_for_origin", e)
            return False

