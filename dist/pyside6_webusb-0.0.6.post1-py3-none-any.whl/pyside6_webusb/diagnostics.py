# -*- coding: utf-8 -*-
"""
diagnostics.py
==============
🆕 v0.0.5a0: ホストアプリ/開発者向けの環境診断ユーティリティ。

「navigator.usbが動かない」「デバイスが一覧に出てこない」系の問い合わせの多くは、
実際にはこのパッケージ自体のロジックのバグではなく、周辺環境
(インストールされているPySide6/pyusbのバージョン、OS側のlibusb共有ライブラリの
有無、Rustアクセラレーションのビルド有無)に起因する。これまではその確認方法が
README中に散らばった説明とisAvailable()(JS/DevTools向け)しかなく、Pythonの
ホストアプリ側から一箇所で確認する手段が無かった。このモジュールはそのギャップを
埋める。

- `environment_report()`: 診断結果をJSON化可能なプリミティブ型のみの辞書として
  返す。ホストアプリが独自の「バージョン情報」画面やサポート用ログにそのまま
  埋め込める。
- `format_environment_report()`: 上記を人間が読むためのテキストに整形する。
- `python -m pyside6_webusb` (__main__.py) からコマンドラインでも直接実行できる。

⚠️ 意図的にPySide6/QtCoreに一切依存しない(importでもQApplicationの生成でも)。
「PySide6が正しくインストールされているか」自体を診断する道具が、その診断対象
であるPySide6が無いと動かないのでは本末転倒であるため——importの成否そのものが
診断結果の一部になる設計にしている。
"""
import platform

from ._version import __version__
from .i18n import DEFAULT_LOCALE, diagnostics_text, resolve_locale
from .platform_support import capability_summary, detect_platform, recommended_transport, setup_hints


def _pyside6_versions():
    """(pyside6_version, shiboken6_version, qt_runtime_version) のタプルを返す。
    いずれも取得できない場合はNoneになる(PySide6が全く入っていない場合や、
    バージョン属性を持たない極端に古い/壊れたインストールでも例外を投げない
    ——診断ツール自身が原因不明のクラッシュをしては本末転倒なため)。"""
    pyside6_version = None
    shiboken6_version = None
    qt_runtime_version = None
    try:
        import PySide6
        pyside6_version = getattr(PySide6, "__version__", None)
    except Exception:
        pass
    try:
        import shiboken6
        shiboken6_version = getattr(shiboken6, "__version__", None)
    except Exception:
        pass
    try:
        from PySide6.QtCore import qVersion
        qt_runtime_version = qVersion()
    except Exception:
        pass
    return pyside6_version, shiboken6_version, qt_runtime_version


def _pyusb_backend_info(locale):
    """(pyusb_version, backend_name_or_None, problem_or_None, backend_note_or_None) を返す。

    pyusbが「importできる」ことと「実際にUSBデバイスへアクセスできる」ことは
    別問題: pyusb自体は純Pythonパッケージなのでpipで必ず入るが、実際の通信は
    OS側のlibusb共有ライブラリ(.so/.dylib/.dll)にFFI越しで委譲しており、
    そちらが無いと`usb.core.find()`などが常に失敗する。この2段階を切り分けて
    報告することで、「pipでは入っているのになぜか動かない」という、この種の
    問い合わせで最も多いパターンを診断できるようにする。backend_nameは
    実際に解決できたバックエンド名('libusb1'/'libusb0')。

    🆕 v0.0.5.post3: backend_noteは、backend_nameが解決できた場合の追加の
    注記(現状はlibusb0へフォールバックした場合のみ非None)。problemとは違い
    「動作はするが知っておいた方がよい」情報であり、environment_report()の
    problemsリストには含めない(frame_origin_isolation_note等と同じ扱い)。
    security_report/VULNERABILITY_REPORT.mdの「Environment note」の追跡:
    Python 3.14でpyusb 1.3.1のlibusb0.pyバックエンドがctypes.Structureの
    _pack_/_fields_の組み合わせについてDeprecationWarningを出すことが
    その監査時点で確認されていた(将来のPythonでエラーになりうる、upstream
    pyusb側の課題)。この実装のこのPython(3.12系)では当該警告は再現しない
    ことを確認済みだが、libusb0への実際のフォールバックが起きた環境でのみ
    意味を持つ注記なので、フォールバックが実際に発生した場合にのみ表示する。
    """
    pyusb_version = None
    try:
        import usb
        pyusb_version = getattr(usb, "__version__", None)
    except Exception as e:
        return None, None, diagnostics_text(locale, "pyusb_import_error", error=e), None

    backend_name = None
    try:
        import usb.backend.libusb1 as _libusb1
        if _libusb1.get_backend() is not None:
            backend_name = "libusb1"
    except Exception:
        pass
    if backend_name is None:
        try:
            import usb.backend.libusb0 as _libusb0
            if _libusb0.get_backend() is not None:
                backend_name = "libusb0"
        except Exception:
            pass

    problem = None
    if backend_name is None:
        problem = diagnostics_text(locale, "pyusb_backend_missing")
    backend_note = None
    if backend_name == "libusb0":
        backend_note = diagnostics_text(locale, "pyusb_backend_note_libusb0")
    return pyusb_version, backend_name, problem, backend_note


def _rust_accel_status():
    """(rust_accelerated: bool, rust_accel_version_or_None) を返す。
    未ビルドでも本パッケージは完全に動作する(README「Rust acceleration
    (optional)」参照)ため、これは"problem"としては報告しない——単なる性能上の
    最適化がオプトインで効いているかどうかの情報。"""
    try:
        import pyside6_webusb_accel
        return True, getattr(pyside6_webusb_accel, "__version__", None)
    except ImportError:
        return False, None


def _qtwebengine_status(locale):
    """(importable: bool | None, note_or_None) を返す。Noneは
    「PySide6自体が無いので判定不能(=既にpyside6_versionのNoneで報告済み)」。

    🔍 実機検証(v0.0.5a1、2026-09時点のPySide6 6.12.0a1開発版wheelを実際に
    展開して確認): QtWebEngineCore/QtWebEngineWidgetsの実体(.abi3.so/.pyi)
    が、もはやPySide6-Addonsのwheelには含まれておらず、新設の
    PySide6-WebEngineという別wheelへ分離されていた
    (`unzip -l pyside6_addons-*.whl`にQtWebEngineCore.abi3.soが無いことを
    確認/`unzip -l pyside6_webengine-*.whl`にはあることを確認)。
    この分離はまだ正式リリースには来ていない(PyPI上のpyside6-webengineは
    2026-09時点で存在しない=pip install pyside6-webengineは失敗する)ため、
    本パッケージのpyproject.tomlをこの時点でPySide6-WebEngine依存に
    変更することはできない(存在しないパッケージへの依存は
    `pip install pyside6-webusb`自体を壊す)。そのため今はここでの実行時
    診断としてのみ備え、正式リリースの動向を見て追従する
    (CHANGELOG参照)。"""
    try:
        import PySide6  # noqa: F401
    except Exception:
        return None, None
    missing = []
    try:
        from PySide6.QtWebEngineCore import QWebEngineScript  # noqa: F401
    except Exception:
        missing.append("QtWebEngineCore")
    try:
        from PySide6.QtWebEngineWidgets import QWebEngineView  # noqa: F401
    except Exception:
        missing.append("QtWebEngineWidgets")
    if not missing:
        return True, None
    return False, diagnostics_text(locale, "qtwebengine_missing", missing="/".join(missing))


def _qtwebview_status():
    """(QtWebViewをimportできるか, QtWebSocketsをimportできるか)。PySide6自体が無ければ(None, None)。"""
    try:
        import PySide6  # noqa: F401
    except Exception:
        return None, None
    try:
        import PySide6.QtWebView  # noqa: F401
        webview = True
    except Exception:
        webview = False
    try:
        import PySide6.QtWebSockets  # noqa: F401
        websockets = True
    except Exception:
        websockets = False
    return webview, websockets


def _frame_origin_isolation_status(locale):
    """(available: bool | None, note: str) を返す。

    availableは「QWebEngineFrameクラスがこの環境のPySide6に存在するか」の
    静的な可否のみを見る。実際にnavigationRequestedへ接続できるか
    (frame_origin.FrameOriginTracker.is_functional)は生きたQWebEnginePageが
    要るため、ここ(意図的にQApplicationを一切作らない診断ツール)では
    判定できない。Noneは判定不能(PySide6/QtWebEngineCore自体が無い)。

    🔍 実機検証(v0.0.5a1): PySide6 6.6.0/6.7.0にはQWebEngineFrameクラス
    自体が存在せず、6.8.0で初めて追加されたことを、3バージョンを実際に
    別々の venv へインストールしバイナリサーチして確認した。つまり
    PySide6-Addons>=6.5と宣言している現在のサポート範囲のうち6.5〜6.7では、
    frame_origin.pyによるcross-origin iframeのなりすまし対策は構造的に
    有効化できず、WebUSBBridge._current_origin()はpage.url()を見る
    後方互換パス(0.0.2b0より前の、より弱いオリジン判定)へ常に
    フォールバックする。これは既知の制約であってバグではないが、
    ホストアプリ開発者が気づけるよう明示的に報告する。"""
    try:
        import PySide6.QtWebEngineCore as _qtwec
    except Exception:
        return None, diagnostics_text(locale, "frame_isolation_unknown_note")
    if hasattr(_qtwec, "QWebEngineFrame"):
        return True, diagnostics_text(locale, "frame_isolation_available_note")
    return False, diagnostics_text(locale, "frame_isolation_unavailable_note")


def environment_report(locale=None) -> dict:
    """現在の実行環境の診断結果を辞書として返す。JSON化可能なプリミティブ型
    (str/bool/None/list)のみで構成する。

    "problems" は今すぐ対処が要る項目のみ(PySide6が無い/libusbバックエンドが
    無い、等)。Rustアクセラレーション未ビルドはproblemsに含めない
    ——それ自体は正常な状態(フォールバックが正しく機能している)であるため。

    locale: 🆕 v0.0.5b3。"problems"/"*_note" に入る文言の言語。"en"/"ja"/"zh"
        (pyside6_webusb.i18n.SUPPORTED_LOCALES)、OSロケールへ明示的に追従させる
        特別値"auto"、または省略(None、既定は"ja"——0.0.5.post6までの既存の
        出力と一言一句同じにするための固定値。i18n.DEFAULT_LOCALEのdocstring
        参照)。戻り値の"locale"キーに、実際に解決された値("en"/"ja"/"zh"の
        いずれか)を記録する——format_environment_report()がreportだけを渡された
        時にどの言語で描画すべきかを、この値から取得する。"""
    loc = resolve_locale(locale)
    pyside6_version, shiboken6_version, qt_runtime_version = _pyside6_versions()
    pyusb_version, pyusb_backend, pyusb_problem, pyusb_backend_note = _pyusb_backend_info(loc)
    rust_accelerated, rust_accel_version = _rust_accel_status()
    qtwebengine_importable, qtwebengine_note = _qtwebengine_status(loc)
    frame_isolation_available, frame_isolation_note = _frame_origin_isolation_status(loc)
    qtwebview_importable, qtwebsockets_importable = _qtwebview_status()
    os_name = detect_platform()
    transport = recommended_transport(
        os_name, have_webengine=qtwebengine_importable,
        have_webview=qtwebview_importable, have_websockets=qtwebsockets_importable)

    problems = []
    if pyside6_version is None:
        problems.append(diagnostics_text(loc, "pyside6_missing"))
    if qtwebengine_importable is False:
        problems.append(qtwebengine_note)
    if pyusb_problem is not None:
        problems.append(pyusb_problem)
    if qtwebengine_importable is False and qtwebview_importable and qtwebsockets_importable is False:
        problems.append(diagnostics_text(loc, "qtwebview_missing_note"))

    return {
        "pyside6_webusb_version": __version__,
        "locale": loc,
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "host_os": os_name,
        "capabilities": capability_summary(os_name),
        "setup_hints": setup_hints(os_name),
        "qtwebview_importable": qtwebview_importable,
        "qtwebsockets_importable": qtwebsockets_importable,
        "recommended_transport": transport,
        "pyside6_version": pyside6_version,
        "shiboken6_version": shiboken6_version,
        "qt_runtime_version": qt_runtime_version,
        "qtwebengine_importable": qtwebengine_importable,
        "pyusb_version": pyusb_version,
        "pyusb_backend": pyusb_backend,
        "pyusb_backend_note": pyusb_backend_note,
        "rust_accelerated": rust_accelerated,
        "rust_accel_version": rust_accel_version,
        # 🆕 v0.0.5a1: PySide6 6.8.0で追加されたQWebEngineFrameの静的な有無
        # (frame_origin.pyのフレーム単位オリジン分離が構造的に使えるか)。
        "frame_origin_isolation_available": frame_isolation_available,
        "frame_origin_isolation_note": frame_isolation_note,
        "problems": problems,
    }


def _transport_line(report, loc):
    label = diagnostics_text(loc, "label_transport")
    key = {"webchannel": "report_transport_webchannel", "websocket": "report_transport_websocket"}.get(
        report.get("recommended_transport"), "report_transport_none")
    line = f"{label}: {diagnostics_text(loc, key)}"
    wv = report.get("qtwebview_importable")
    ws = report.get("qtwebsockets_importable")
    if wv is not None or ws is not None:
        yes, no = diagnostics_text(loc, "report_available"), diagnostics_text(loc, "report_unavailable")
        line += (f"\n{diagnostics_text(loc, 'label_qtwebview')}: {yes if wv else no}, "
                 f"{diagnostics_text(loc, 'label_qtwebsockets')}: {yes if ws else no}")
    return line


def format_environment_report(report: dict = None, locale=None) -> str:
    """environment_report()の結果を、人間が読むためのテキストレポートに整形する。
    reportを省略した場合はその場でenvironment_report(locale=locale)を呼ぶ。

    locale: 🆕 v0.0.5b3。reportを渡した場合、この見出し等のラベル文言は
        report["locale"](=そのreportが実際に生成された時の言語)を優先する——
        "problems"/"*_note"の中身は生成時点で既にその言語で焼き込み済みなので、
        ここだけ別言語のlocaleを指定すると見出しと本文の言語がちぐはぐになって
        しまうため、意図的にreport側を優先する。この引数が主に効くのは
        reportを省略した(=ここでenvironment_report()を呼ぶ)場合と、
        "locale"キーを持たない古い形のreport辞書を渡された場合のみ。"""
    if report is None:
        report = environment_report(locale=locale)
    loc = report.get("locale") or resolve_locale(locale)

    not_found = diagnostics_text(loc, "report_not_found")
    pyside6_label = diagnostics_text(loc, "label_pyside6")
    pyside6_line = f"{pyside6_label}: {report['pyside6_version'] or not_found}"
    if report["shiboken6_version"]:
        pyside6_line += f" (shiboken6 {report['shiboken6_version']})"

    pyusb_label = diagnostics_text(loc, "label_pyusb")
    pyusb_line = f"{pyusb_label}: {report['pyusb_version'] or not_found}"
    pyusb_line += f" (backend: {report['pyusb_backend'] or not_found})"

    rust_label = diagnostics_text(loc, "label_rust_acceleration")
    if report["rust_accelerated"]:
        rust_line = f"{rust_label}: {diagnostics_text(loc, 'report_rust_enabled')}"
        if report["rust_accel_version"]:
            rust_line += f" ({report['rust_accel_version']})"
    else:
        rust_line = f"{rust_label}: {diagnostics_text(loc, 'report_rust_disabled')}"

    # 🆕 v0.0.5a1
    frame_label = diagnostics_text(loc, "label_frame_isolation")
    if report.get("frame_origin_isolation_available") is True:
        frame_line = f"{frame_label}: {diagnostics_text(loc, 'report_frame_available')}"
    elif report.get("frame_origin_isolation_available") is False:
        frame_line = f"{frame_label}: {diagnostics_text(loc, 'report_frame_unavailable')}"
    else:
        frame_line = f"{frame_label}: {diagnostics_text(loc, 'report_frame_unknown')}"

    # 🆕 v0.0.6: 以前は"PySide6:"/"Python:"/"Qt runtime:"/"pyusb:"/"Rust
    # acceleration:"/"Frame-level origin isolation:" の各ラベル部分が英語決め
    # 打ちで、locale="ja"/"zh"を指定してもここだけ訳されずに残っていた
    # (値やproblems/*_noteの中身は正しく訳されていたため気づきにくい不整合
    # だった)。i18n.DIAGNOSTICS_STRINGSの新しいlabel_*キー経由でラベル自体も
    # localeに追従させる。"PySide6"/"Python"/"pyusb"は元々どの言語でも綴りを
    # 変えない固有名詞なので値としては変化しないが、"Qt runtime"/"Rust
    # acceleration"/"Frame-level origin isolation"はja/zhで実際に翻訳される。
    lines = [
        f"pyside6-webusb {report['pyside6_webusb_version']}",
        f"{diagnostics_text(loc, 'label_python')}: {report['python_version']} "
        f"({report['python_implementation']}) on {report['platform']}",
        pyside6_line,
        f"{diagnostics_text(loc, 'label_qt_runtime')}: "
        f"{report['qt_runtime_version'] or diagnostics_text(loc, 'report_qt_runtime_unknown')}",
        pyusb_line,
        rust_line,
        frame_line,
        _transport_line(report, loc),
    ]
    caps = report.get("capabilities")
    if caps:
        lines.append(f"{diagnostics_text(loc, 'label_host_os')}: {report.get('host_os', '?')}")
        lines.append(diagnostics_text(loc, "report_capabilities_header"))
        for key in sorted(caps):
            lines.append(f"  {key}: {caps[key]}")
    hints = report.get("setup_hints")
    if hints:
        lines.append(diagnostics_text(loc, "report_setup_hints_header"))
        for h in hints:
            lines.append(f"  - {h}")
    lines.append("")
    if report["problems"]:
        lines.append(diagnostics_text(loc, "report_problems_header"))
        for p in report["problems"]:
            lines.append(f"  - {p}")
    else:
        lines.append(diagnostics_text(loc, "report_no_problems"))
    if report.get("frame_origin_isolation_available") is False and report.get("frame_origin_isolation_note"):
        lines.append("")
        lines.append(diagnostics_text(loc, "report_reference_prefix", note=report["frame_origin_isolation_note"]))
    if report.get("pyusb_backend_note"):
        lines.append("")
        lines.append(diagnostics_text(loc, "report_reference_prefix", note=report["pyusb_backend_note"]))
    return "\n".join(lines)
