# -*- coding: utf-8 -*-
"""実USBデバイスが無い環境でも pyside6_webusb.hardening のロジックを検証するための
モックベース単体テスト。pyusbのDevice/Configuration/Interface/Endpointの
「構造(イテレーション形状と属性名)」だけを模倣する。"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pyside6_webusb import hardening as h


class FakeEndpoint:
    def __init__(self, address, attributes, max_packet=64):
        self.bEndpointAddress = address
        self.bmAttributes = attributes
        self.wMaxPacketSize = max_packet


class FakeInterface:
    def __init__(self, number, alt, iclass, isub, iproto, endpoints, iInterface=0):
        self.bInterfaceNumber = number
        self.bAlternateSetting = alt
        self.bInterfaceClass = iclass
        self.bInterfaceSubClass = isub
        self.bInterfaceProtocol = iproto
        self._endpoints = endpoints
        self.iInterface = iInterface

    def __iter__(self):
        return iter(self._endpoints)


class FakeConfiguration:
    def __init__(self, value, interfaces, iConfiguration=0):
        self.bConfigurationValue = value
        self._interfaces = interfaces
        self.iConfiguration = iConfiguration

    def __iter__(self):
        return iter(self._interfaces)


class FakeDevice:
    def __init__(self, idVendor, idProduct, configurations,
                 deviceClass=0, deviceSubClass=0, deviceProtocol=0,
                 bcdUSB=0x0200, bcdDevice=0x0100,
                 iManufacturer=1, iProduct=2, iSerialNumber=3,
                 active_config_value=None):
        self.idVendor = idVendor
        self.idProduct = idProduct
        self._configurations = configurations
        self.bDeviceClass = deviceClass
        self.bDeviceSubClass = deviceSubClass
        self.bDeviceProtocol = deviceProtocol
        self.bcdUSB = bcdUSB
        self.bcdDevice = bcdDevice
        self.iManufacturer = iManufacturer
        self.iProduct = iProduct
        self.iSerialNumber = iSerialNumber
        self._active_config_value = active_config_value

    def __iter__(self):
        return iter(self._configurations)

    def get_active_configuration(self):
        # 実pyusbのDevice.get_active_configuration()を模倣。
        # - active_config_value=False を明示した場合だけ「取得できない実機」を
        #   模して例外を送出する(test_active_configuration_value_none_when_unavailable専用)。
        # - active_config_value を数値で指定した場合は、その値に一致する
        #   FakeConfigurationを実際に返す(interfaceを反復できる、本物同様のオブジェクト)。
        # - 何も指定しなければ、実機の典型例(configurationは1つだけ)を模して
        #   configurationsの先頭を返す。interface_class_for()等はこれに依存する。
        if self._active_config_value is False:
            raise RuntimeError("no active configuration (simulated)")
        if self._active_config_value is not None:
            for cfg in self._configurations:
                if getattr(cfg, "bConfigurationValue", None) == self._active_config_value:
                    return cfg
        if self._configurations:
            return self._configurations[0]
        raise RuntimeError("no active configuration (simulated)")


class FakeUsbUtil:
    ENDPOINT_IN = 0x80
    ENDPOINT_OUT = 0x00
    ENDPOINT_TYPE_CTRL = 0
    ENDPOINT_TYPE_ISO = 1
    ENDPOINT_TYPE_BULK = 2
    ENDPOINT_TYPE_INTR = 3

    STRINGS = {1: "Acme Corp", 2: "Acme Widget", 3: "SN-0001", 4: "Default Config", 5: "Data Interface"}

    def get_string(self, dev, index):
        return self.STRINGS.get(index)

    def endpoint_direction(self, address):
        return self.ENDPOINT_IN if (address & 0x80) else self.ENDPOINT_OUT

    def endpoint_type(self, attributes):
        return attributes & 0x03


def test_protected_interface_classes():
    assert h.is_protected_interface_class(0x03) is True   # HID
    assert h.is_protected_interface_class(0x08) is True   # Mass Storage
    assert h.is_protected_interface_class(0xE0) is True   # Wireless Controller
    assert h.is_protected_interface_class(0xFF) is False  # Vendor specific: OK
    assert h.is_protected_interface_class(None) is True   # 不明 -> 安全側
    print("test_protected_interface_classes: OK")


def test_blocklist():
    assert h.is_blocklisted_device(0x1050, 0x0407) is True   # YubiKey系
    assert h.is_blocklisted_device(0x2341, 0x8036) is False  # Arduino Leonardo (無関係)
    print("test_blocklist: OK")


def test_bcd_to_version():
    assert h.bcd_to_version(0x0210) == (2, 1, 0)
    assert h.bcd_to_version(0x0100) == (1, 0, 0)
    assert h.bcd_to_version(None) == (0, 0, 0)
    print("test_bcd_to_version: OK")


def test_descriptor_builder_arduino_like():
    util = FakeUsbUtil()
    # Arduino的なCDC複合デバイス: interface0=CDC control, interface1=CDC data(bulk in/out)
    ep_in = FakeEndpoint(0x81, 0x02)   # bulk in
    ep_out = FakeEndpoint(0x02, 0x02)  # bulk out
    intf0 = FakeInterface(0, 0, 0x02, 0x02, 0x01, [])           # CDC control (vendor-neutral)
    intf1 = FakeInterface(1, 0, 0xFF, 0x00, 0x00, [ep_in, ep_out])  # vendor-specific bulk
    cfg = FakeConfiguration(1, [intf0, intf1])
    dev = FakeDevice(0x2341, 0x8036, [cfg])

    info = h.build_device_descriptor(dev, util)
    assert info["vendorId"] == 0x2341
    assert info["serialNumber"] == "SN-0001"
    assert info["manufacturerName"] == "Acme Corp"
    assert (info["usbVersionMajor"], info["usbVersionMinor"], info["usbVersionSubminor"]) == (2, 0, 0)
    assert len(info["configurations"]) == 1
    interfaces = info["configurations"][0]["interfaces"]
    assert len(interfaces) == 2
    vendor_iface = [i for i in interfaces if i["interfaceNumber"] == 1][0]
    eps = vendor_iface["alternates"][0]["endpoints"]
    assert {"endpointNumber": 1, "direction": "in", "type": "bulk", "packetSize": 64} in eps
    assert {"endpointNumber": 2, "direction": "out", "type": "bulk", "packetSize": 64} in eps
    print("test_descriptor_builder_arduino_like: OK")


def test_hid_interface_flagged_protected():
    util = FakeUsbUtil()
    intf_hid = FakeInterface(0, 0, 0x03, 0x01, 0x01, [FakeEndpoint(0x81, 0x03)])  # HID keyboard-like
    cfg = FakeConfiguration(1, [intf_hid])
    dev = FakeDevice(0x1234, 0x5678, [cfg], deviceClass=0)
    info = h.build_device_descriptor(dev, util)
    iface = info["configurations"][0]["interfaces"][0]
    assert iface["alternates"][0]["interfaceProtected"] is True
    assert h.interface_class_for(dev, 0) == 0x03
    print("test_hid_interface_flagged_protected: OK")


def test_hub_interface_flagged_protected():
    """WebUSB仕様本文(index.bs の「Protected interface classes」表,
    #protected-interface-classes)を一次ソースから直接確認したところ、
    Audio/HID/Mass Storage/Smart Card/Video/Audio-Video/Wireless Controllerに加えて
    Hub(0x09)も保護対象クラスに含まれていた。旧実装はHubが抜けたまま7クラスしか
    登録されておらず、Hub機器のインターフェースをclaimInterfaceできてしまう状態
    だった。"""
    util = FakeUsbUtil()
    assert h.is_protected_interface_class(0x09) is True  # Hub
    intf_hub = FakeInterface(0, 0, 0x09, 0x00, 0x00, [FakeEndpoint(0x81, 0x03)])
    cfg = FakeConfiguration(1, [intf_hub])
    dev = FakeDevice(0x1234, 0x5678, [cfg], deviceClass=0)
    info = h.build_device_descriptor(dev, util)
    iface = info["configurations"][0]["interfaces"][0]
    assert iface["alternates"][0]["interfaceProtected"] is True
    print("test_hub_interface_flagged_protected: OK")


def test_configuration_and_interface_names():
    """spec: USBConfiguration.configurationName / USBAlternateInterface.interfaceName は
    それぞれconfiguration/interface descriptorのiConfiguration/iInterfaceが指す
    string descriptorの値(未定義の場合はNone)。旧実装はどちらも未実装で、
    生成されるdictにキー自体が存在しなかった。"""
    util = FakeUsbUtil()
    ep = FakeEndpoint(0x81, 0x02)
    intf_named = FakeInterface(0, 0, 0xFF, 0x00, 0x00, [ep], iInterface=5)
    intf_unnamed = FakeInterface(1, 0, 0xFF, 0x00, 0x00, [ep])  # iInterface省略 -> 0 -> None
    cfg = FakeConfiguration(1, [intf_named, intf_unnamed], iConfiguration=4)
    dev = FakeDevice(0x1234, 0x5678, [cfg])
    info = h.build_device_descriptor(dev, util)
    config_info = info["configurations"][0]
    assert config_info["configurationName"] == "Default Config"
    interfaces = config_info["interfaces"]
    named = [i for i in interfaces if i["interfaceNumber"] == 0][0]
    unnamed = [i for i in interfaces if i["interfaceNumber"] == 1][0]
    assert named["alternates"][0]["interfaceName"] == "Data Interface"
    assert unnamed["alternates"][0]["interfaceName"] is None, \
        "iInterface==0(文字列記述子なし)はNoneになるべき"
    print("test_configuration_and_interface_names: OK")


def test_control_type_endpoint_excluded_from_endpoints():
    """spec注記(USBAlternateInterfaceコンストラクタ手順): bmAttributesが
    Control Transfer Type(下位2bit==00)を示すendpoint記述子はendpoints一覧から
    除外されるべき("There shouldn't be any endpoint object belongs to Control
    Transfer Type")。旧実装は除外しておらず、実仕様のUSBEndpointType enum
    ("bulk"/"interrupt"/"isochronous")には存在しない"control"という値を
    返しうる状態だった。"""
    util = FakeUsbUtil()
    ep_ctrl = FakeEndpoint(0x00, 0x00)  # bmAttributes下位2bit=00 -> Control
    ep_bulk = FakeEndpoint(0x81, 0x02)  # bulk in
    intf = FakeInterface(0, 0, 0xFF, 0x00, 0x00, [ep_ctrl, ep_bulk])
    cfg = FakeConfiguration(1, [intf])
    dev = FakeDevice(0x1234, 0x5678, [cfg])
    info = h.build_device_descriptor(dev, util)
    eps = info["configurations"][0]["interfaces"][0]["alternates"][0]["endpoints"]
    assert len(eps) == 1, "Control転送タイプのendpointは一覧から除外されるべき"
    assert eps[0]["endpointNumber"] == 1
    assert all(e["type"] != "control" for e in eps)
    print("test_control_type_endpoint_excluded_from_endpoints: OK")


def test_interface_class_for_scoped_to_active_configuration():
    """interface_class_for()は「現在アクティブなconfiguration」内だけを見るべきで、
    デバイスが複数configurationを持つ場合に非アクティブ側の同番号インターフェースを
    誤って拾ってはいけない(以前は全configurationを横断探索していた)。
    configuration 1のインターフェース0はHID(保護対象)、configuration 2の
    インターフェース0はvendor-specific(非保護)という、あえて逆の結果になる
    2つのconfigurationを用意し、アクティブ側の値だけが反映されることを確認する。"""
    hid_intf = FakeInterface(0, 0, 0x03, 0x01, 0x01, [FakeEndpoint(0x81, 0x03)])  # 保護対象
    vendor_intf = FakeInterface(0, 0, 0xFF, 0x00, 0x00, [FakeEndpoint(0x81, 0x02)])  # 非保護
    cfg1 = FakeConfiguration(1, [hid_intf])
    cfg2 = FakeConfiguration(2, [vendor_intf])

    dev_cfg2_active = FakeDevice(0x1234, 0x5678, [cfg1, cfg2], active_config_value=2)
    assert h.interface_class_for(dev_cfg2_active, 0) == 0xFF, "アクティブなconfig2側(vendor-specific)が採用されるべき"
    assert h.is_protected_interface_class(h.interface_class_for(dev_cfg2_active, 0)) is False

    dev_cfg1_active = FakeDevice(0x1234, 0x5678, [cfg1, cfg2], active_config_value=1)
    assert h.interface_class_for(dev_cfg1_active, 0) == 0x03, "アクティブなconfig1側(HID)が採用されるべき"
    assert h.is_protected_interface_class(h.interface_class_for(dev_cfg1_active, 0)) is True
    print("test_interface_class_for_scoped_to_active_configuration: OK")


def test_unknown_interface_number_treated_as_protected():
    """interface_class_for()が対象のインターフェース番号を見つけられなかった場合
    (存在しないインターフェース番号が渡された等)、is_protected_interface_class()は
    安全側(=保護対象として拒否)に倒れるべき。旧実装はinterface_class_for()の
    「見つからない」センチネル値が-1で、int(-1)は例外を投げないため
    is_protected_interface_class()の安全側フォールバック(TypeError/ValueError捕捉)を
    素通りしてしまい、-1 not in PROTECTED_INTERFACE_CLASSES つまりFalse(保護対象で
    ない)と誤判定していた(claimInterfaceが実在しないインターフェース番号に対して
    fail-openしていた、実際にPythonで再現・確認済みのバグ)。"""
    util = FakeUsbUtil()
    intf = FakeInterface(0, 0, 0xFF, 0x00, 0x00, [FakeEndpoint(0x81, 0x02)])
    cfg = FakeConfiguration(1, [intf])
    dev = FakeDevice(0x1234, 0x5678, [cfg])
    assert h.interface_class_for(dev, 99) is None  # インターフェース0しか無いので99は存在しない
    assert h.is_protected_interface_class(h.interface_class_for(dev, 99)) is True
    print("test_unknown_interface_number_treated_as_protected: OK")


def test_hotplug_watcher_diff():
    """🐛 v0.0.5a3で挙動修正: 最初のpoll()は「起動前から挿さっていたデバイス」の
    基準記録だけを行い、connected/disconnectedともに空を返す(実ブラウザは
    起動時に既に挿さっているデバイスへconnectイベントを発火しない)。
    差分検出そのものは2回目以降のpoll()から従来どおり行われることを確認する。"""
    state = {"devices": {(0x2341, 0x8036)}}
    watcher = h.UsbHotplugWatcher(lambda: set(state["devices"]))
    # 初回pollは基準記録のみ: 起動前から挿さっていた(0x2341, 0x8036)は
    # 「今接続された」わけではないので、connectイベントとして報告されない。
    connected, disconnected = watcher.poll()
    assert connected == [] and disconnected == [], (connected, disconnected)
    state["devices"].add((0x1050, 0x0407))
    connected, disconnected = watcher.poll()
    assert connected == [(0x1050, 0x0407)] and disconnected == []
    state["devices"].discard((0x2341, 0x8036))
    connected, disconnected = watcher.poll()
    assert connected == [] and disconnected == [(0x2341, 0x8036)]
    print("test_hotplug_watcher_diff: OK")


def test_hotplug_watcher_first_poll_never_fires_spurious_connect_events():
    """🐛 バグ修正(v0.0.5a3): 旧実装はUsbHotplugWatcherの生成時点(=通常は
    アプリ起動時)に何台デバイスが挿さっていても、最初のpoll()で「現在の
    デバイス一覧 - 空集合」をそのまま差分として返していたため、起動直後の
    最初のタイマー発火(bridge.py: 1.5秒後)で、既に挿さっていた全デバイス
    ぶんのconnectイベントがJSへ一気に配送されてしまっていた。これは
    getDevices()で最初から見えているのと同じデバイスについて、さらに
    偽のconnectイベントが重複して届く実害のある不具合だった。
    大量のデバイスが最初から挿さっている状況を再現し、初回poll()が
    どのデバイス数であっても connected == [] であることを確認する。"""
    many_devices = {(0x0001, i) for i in range(1, 51)}
    watcher = h.UsbHotplugWatcher(lambda: set(many_devices))
    connected, disconnected = watcher.poll()
    assert connected == [] and disconnected == [], (
        f"起動前から挿さっていた{len(many_devices)}台ぶんの偽connectイベントが"
        f"発生した: connected={connected!r}"
    )
    # 基準が正しく記録されているので、次にもう1台挿すとそれだけが報告される。
    many_devices.add((0x0002, 0x0002))
    connected, disconnected = watcher.poll()
    assert connected == [(0x0002, 0x0002)] and disconnected == []
    print("test_hotplug_watcher_first_poll_never_fires_spurious_connect_events: OK")


# ==================== ここから: requestDevice()フィルタ照合 ====================
# 出典: https://wicg.github.io/webusb/#dom-usb-requestdevice の
# 'A USBDeviceFilter filter is valid' / 'A USB device device matches a
# device filter filter' / 'A USB interface interface matches an interface
# filter filter' を実装したもの。旧実装はrequestDevice(options)のfilters/
# exclusionFiltersを一切見ておらず、常に全デバイスをチューザーに表示していた。

def test_is_valid_usb_device_filter():
    assert h.is_valid_usb_device_filter({}) is True
    assert h.is_valid_usb_device_filter({"vendorId": 0x2341}) is True
    assert h.is_valid_usb_device_filter({"vendorId": 0x2341, "productId": 0x8036}) is True
    assert h.is_valid_usb_device_filter({"productId": 0x8036}) is False          # vendorId無しでproductIdだけ
    assert h.is_valid_usb_device_filter({"classCode": 3, "subclassCode": 1}) is True
    assert h.is_valid_usb_device_filter({"subclassCode": 1}) is False            # classCode無しでsubclassCodeだけ
    assert h.is_valid_usb_device_filter({"classCode": 3, "subclassCode": 1, "protocolCode": 2}) is True
    assert h.is_valid_usb_device_filter({"classCode": 3, "protocolCode": 2}) is False  # subclassCode無しでprotocolCodeだけ
    assert h.is_valid_usb_device_filter("not a dict") is False
    # 🆕 型および数値範囲の検証 (0.0.5.post5)
    assert h.is_valid_usb_device_filter({"vendorId": -1}) is False
    assert h.is_valid_usb_device_filter({"vendorId": 0x10000}) is False
    assert h.is_valid_usb_device_filter({"vendorId": True}) is False
    assert h.is_valid_usb_device_filter({"classCode": 256}) is False
    assert h.is_valid_usb_device_filter({"serialNumber": 123}) is False
    assert h.is_valid_usb_device_filter({"serialNumber": "SN-001"}) is True
    print("test_is_valid_usb_device_filter: OK")


def _arduino_like_device():
    util = FakeUsbUtil()
    ep_in = FakeEndpoint(0x81, 0x02)
    ep_out = FakeEndpoint(0x02, 0x02)
    intf0 = FakeInterface(0, 0, 0x02, 0x02, 0x01, [])
    intf1 = FakeInterface(1, 0, 0xFF, 0x00, 0x00, [ep_in, ep_out])
    cfg = FakeConfiguration(1, [intf0, intf1])
    dev = FakeDevice(0x2341, 0x8036, [cfg])
    return dev, util


def test_device_matches_filter_vendor_and_product_id():
    dev, util = _arduino_like_device()
    assert h.device_matches_usb_filter(dev, util, {"vendorId": 0x2341}) is True
    assert h.device_matches_usb_filter(dev, util, {"vendorId": 0x9999}) is False
    assert h.device_matches_usb_filter(dev, util, {"vendorId": 0x2341, "productId": 0x8036}) is True
    assert h.device_matches_usb_filter(dev, util, {"vendorId": 0x2341, "productId": 0x0001}) is False
    print("test_device_matches_filter_vendor_and_product_id: OK")


def test_device_matches_filter_serial_number():
    dev, util = _arduino_like_device()  # FakeUsbUtil.STRINGS[3] == "SN-0001"
    assert h.device_matches_usb_filter(dev, util, {"serialNumber": "SN-0001"}) is True
    assert h.device_matches_usb_filter(dev, util, {"serialNumber": "SN-9999"}) is False
    print("test_device_matches_filter_serial_number: OK")


def test_device_matches_filter_class_code_device_level():
    util = FakeUsbUtil()
    intf_hid = FakeInterface(0, 0, 0x03, 0x01, 0x01, [])
    cfg = FakeConfiguration(1, [intf_hid])
    # bDeviceClass=0x03自体をHIDとして申告している(複合デバイスではない単純な機器)
    dev = FakeDevice(0x1234, 0x5678, [cfg], deviceClass=0x03)
    assert h.device_matches_usb_filter(dev, util, {"classCode": 0x03}) is True
    assert h.device_matches_usb_filter(dev, util, {"classCode": 0x08}) is False
    print("test_device_matches_filter_class_code_device_level: OK")


def test_device_matches_filter_class_code_via_interface():
    # 複合デバイス: bDeviceClass=0xFF(vendor-specific)を名乗りつつ、
    # インターフェース1つがHID(0x03)を申告しているケース。
    # 仕様どおりなら「いずれかのインターフェースが一致すればデバイス全体もmatch」。
    dev, util = _arduino_like_device()  # bDeviceClass=0, インターフェース1が0xFF
    assert h.device_matches_usb_filter(dev, util, {"classCode": 0xFF}) is True  # interface1経由でmatch
    assert h.device_matches_usb_filter(dev, util, {"classCode": 0x02}) is True  # interface0(CDC control)経由でmatch
    assert h.device_matches_usb_filter(dev, util, {"classCode": 0x08}) is False  # どこにも無い
    # サブクラス/プロトコルまで含めた絞り込みもインターフェース単位で見る
    assert h.device_matches_usb_filter(dev, util, {"classCode": 0xFF, "subclassCode": 0x00, "protocolCode": 0x00}) is True
    assert h.device_matches_usb_filter(dev, util, {"classCode": 0xFF, "subclassCode": 0x99}) is False
    print("test_device_matches_filter_class_code_via_interface: OK")


def test_device_matches_any_usb_filter_empty_list_matches_nothing():
    dev, util = _arduino_like_device()
    # 仕様どおり: filters=[](空配列)は「一致するものなし」。
    # 「全デバイスを見せたい」場合はfilters:[{}](空オブジェクト)が正しい書き方。
    assert h.device_matches_any_usb_filter(dev, util, []) is False
    assert h.device_matches_any_usb_filter(dev, util, [{}]) is True
    assert h.device_matches_any_usb_filter(dev, util, [{"vendorId": 0x9999}, {"vendorId": 0x2341}]) is True
    assert h.device_matches_any_usb_filter(dev, util, [{"vendorId": 0x9999}]) is False
    print("test_device_matches_any_usb_filter_empty_list_matches_nothing: OK")


# ==================== ここから: STALL検出(USBTransferStatus) ====================

def test_is_stall_error():
    class FakeUSBErrorWithErrno(Exception):
        errno = 32
    class FakeUSBErrorNoErrno(Exception):
        pass
    assert h.is_stall_error(FakeUSBErrorWithErrno("some backend text")) is True
    assert h.is_stall_error(FakeUSBErrorNoErrno("[Errno 32] Pipe error")) is True
    assert h.is_stall_error(FakeUSBErrorNoErrno("Resource busy")) is False
    assert h.is_stall_error(FakeUSBErrorNoErrno("device STALLed the endpoint")) is True
    print("test_is_stall_error: OK")


# ==================== ここから: babble検出(USBTransferStatus, v0.0.4a0) ====================

def test_is_babble_error():
    """is_stall_errorと対になる、'babble'(デバイスが要求より多くのデータを
    返した場合の転送ステータス)検出のテスト。errno=75(EOVERFLOW)は
    usb.backend.libusb1.LIBUSB_ERROR_OVERFLOWから実際にUSBErrorを構築して
    確認済み(bridge.pyのis_babble_error docstring参照)。"""
    class FakeUSBErrorWithErrno(Exception):
        errno = 75
    class FakeUSBErrorNoErrno(Exception):
        pass
    assert h.is_babble_error(FakeUSBErrorWithErrno("some backend text")) is True
    assert h.is_babble_error(FakeUSBErrorNoErrno("[Errno 75] Overflow")) is True
    assert h.is_babble_error(FakeUSBErrorNoErrno("Resource busy")) is False
    assert h.is_babble_error(FakeUSBErrorNoErrno("device sent more data than requested (babble)")) is True
    # stallとbabbleは別のerrno/文言のはずなので、お互いを誤検知しないことも確認する
    assert h.is_babble_error(FakeUSBErrorNoErrno("[Errno 32] Pipe error")) is False
    assert h.is_stall_error(FakeUSBErrorNoErrno("[Errno 75] Overflow")) is False
    print("test_is_babble_error: OK")


# ==================== ここから: 大容量転送向けタイムアウトスケーリング(v0.0.4a0) ====================

def test_scaled_transfer_timeout_ms():
    """WebADB等の大容量ペイロードでも正当な転送が完了前に打ち切られないよう、
    転送予定バイト数に応じてタイムアウトをスケールさせる関数のテスト。"""
    # 小さい転送は最低5秒を下回らない
    assert h.scaled_transfer_timeout_ms(0) == 5000
    assert h.scaled_transfer_timeout_ms(50) == 5000
    # サイズに応じて増える(100KB/s相当の見積もりで計算)
    assert h.scaled_transfer_timeout_ms(1_000_000) == 15000
    # どれだけ大きくても上限(120秒)で頭打ちになり、無期限にはならない
    assert h.scaled_transfer_timeout_ms(1_000_000_000) == 120000
    # 単調増加であること(サイズが大きいほどタイムアウトも長いか同じ)
    assert h.scaled_transfer_timeout_ms(500_000) <= h.scaled_transfer_timeout_ms(2_000_000)
    # 負値やおかしな入力でも例外を出さず、最低値にフォールバックする
    assert h.scaled_transfer_timeout_ms(-100) == 5000
    print("test_scaled_transfer_timeout_ms: OK")


# ==================== ここから: activeConfigurationValue ====================

def test_active_configuration_value_reported_when_available():
    util = FakeUsbUtil()
    cfg1 = FakeConfiguration(1, [])
    cfg2 = FakeConfiguration(2, [])
    dev = FakeDevice(0x1234, 0x5678, [cfg1, cfg2], active_config_value=2)
    info = h.build_device_descriptor(dev, util, include_configurations=False)
    assert info["activeConfigurationValue"] == 2
    print("test_active_configuration_value_reported_when_available: OK")


def test_active_configuration_value_none_when_unavailable():
    util = FakeUsbUtil()
    cfg1 = FakeConfiguration(1, [])
    dev = FakeDevice(0x1234, 0x5678, [cfg1], active_config_value=False)  # 取得不能な実機を模す
    info = h.build_device_descriptor(dev, util, include_configurations=False)
    assert info["activeConfigurationValue"] is None
    print("test_active_configuration_value_none_when_unavailable: OK")


if __name__ == "__main__":
    test_protected_interface_classes()
    test_blocklist()
    test_bcd_to_version()
    test_descriptor_builder_arduino_like()
    test_hid_interface_flagged_protected()
    test_hub_interface_flagged_protected()
    test_configuration_and_interface_names()
    test_control_type_endpoint_excluded_from_endpoints()
    test_unknown_interface_number_treated_as_protected()
    test_interface_class_for_scoped_to_active_configuration()
    test_hotplug_watcher_diff()
    test_hotplug_watcher_first_poll_never_fires_spurious_connect_events()
    test_is_valid_usb_device_filter()
    test_device_matches_filter_vendor_and_product_id()
    test_device_matches_filter_serial_number()
    test_device_matches_filter_class_code_device_level()
    test_device_matches_filter_class_code_via_interface()
    test_device_matches_any_usb_filter_empty_list_matches_nothing()
    test_is_stall_error()
    test_is_babble_error()
    test_scaled_transfer_timeout_ms()
    test_active_configuration_value_reported_when_available()
    test_active_configuration_value_none_when_unavailable()
    print("ALL WEBUSB HARDENING TESTS PASSED")
